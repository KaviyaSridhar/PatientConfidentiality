const mongoose=require('mongoose');
const unique_validator = require('mongoose-unique-validator');
const pfiles_schema = mongoose.Schema({
  'inputRid':{type : mongoose.Schema.Types.ObjectId, ref : 'mprecords', require : true},
  'inputFilename' : {type:String, require:true,unique:true},
  'inputURL' : {type:String, require:true,unique:true},
  'created' : {type:Date,default:Date.now()}

});


pfiles_schema.plugin(unique_validator);

module.exports = mongoose.model('mpfiles',pfiles_schema);
