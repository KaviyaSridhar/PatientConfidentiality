const mongoose=require('mongoose');

const unique_validator = require('mongoose-unique-validator');


const receptionist_schema = mongoose.Schema({

  'inputFname' : {type:String,require:true},
  'inputLname' : {type:String,require:true},
  'inputEmail': {type:String,require:true},
  'inputPass' : {type:String,require:true},
  'inputPhone' : {type:String,require:true},
  'inputAddress' :{type:String,require:true},

  'created' : {type:Date,default:Date.now()}

});



receptionist_schema.plugin(unique_validator);

module.exports = mongoose.model('mreceptionists',receptionist_schema);
