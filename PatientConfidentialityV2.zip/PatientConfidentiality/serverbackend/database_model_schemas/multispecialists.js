const mongoose=require('mongoose');

const unique_validator = require('mongoose-unique-validator');

const multispecialists_schema = mongoose.Schema({

  'userID' : {type:String, required : true},
  'inputSpecialistType': {type : mongoose.Types.ObjectId, ref : 'mstypes', require : true},

});

multispecialists_schema.plugin(unique_validator);

module.exports = mongoose.model('mmultistypes',multispecialists_schema);
