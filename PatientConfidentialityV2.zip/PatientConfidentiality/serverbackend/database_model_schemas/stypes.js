const mongoose=require('mongoose');

const unique_validator = require('mongoose-unique-validator');

const stypes_schema = mongoose.Schema({

  'stype' : {type:String,require:true},
});

stypes_schema.plugin(unique_validator);

module.exports = mongoose.model('stypes',stypes_schema);
