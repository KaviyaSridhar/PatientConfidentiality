const mongoose=require('mongoose');


const precords_schema = mongoose.Schema({
  'inputPuid':{type : mongoose.Schema.Types.ObjectId, ref : 'mpatients', require : true},
  'inputConsultedHospital':{type:String,require:true},
  'inputConsultedDoctor':{type:String,require:true},
  'inputDescription':{type:String,require:true},
  'inputStype':{type:String,require:true,default:'CONSULTATION'},
  'created' : {type:Date,default:Date.now()}
});



module.exports = mongoose.model('mprecords',precords_schema);
