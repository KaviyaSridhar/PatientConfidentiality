const mongoose=require('mongoose');

const unique_validator = require('mongoose-unique-validator');


const users_schema = mongoose.Schema({

  'inputFname' : {type:String,require:true},
  'inputLname' : {type:String,require:true},
  'inputEmail': {type:String,require:true,unique:true},
  'inputUname' : {type:String,require:true,unique:true},
  'inputPass' : {type:String,require:true},
  'inputRole': {type:Number,require:true,default:'0'},
  'created' : {type:Date,default:Date.now()}

});



users_schema.plugin(unique_validator);

module.exports = mongoose.model('musers',users_schema);
