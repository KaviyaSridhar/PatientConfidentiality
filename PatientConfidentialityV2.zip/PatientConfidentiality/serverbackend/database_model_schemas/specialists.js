const mongoose=require('mongoose');

const unique_validator = require('mongoose-unique-validator');

const specialists_schema = mongoose.Schema({
  'inputFname' : {type:String,require:true},
  'inputLname' : {type:String,require:true},
  'inputUname' : {type:String,require:true},
  'inputPass'  : {type:String,require:true},
  'inputPhone' : {type:String,require:true},
  'inputEmail' : {type:String,require:true,unique:true},
  'inputGender' : {type:String,require:true},
  'inputStype' : {type : mongoose.Schema.Types.ObjectId, ref : 'stypes', require : true},
  'inputQualification' : {type:String,require:true},
  'inputLatitude' : {type:String,require:true},
  'inputLongitude' : {type:String,require:true},
  'created' : {type:Date,default:Date.now()}



});

specialists_schema.plugin(unique_validator);

module.exports = mongoose.model('mspecialists',specialists_schema);
