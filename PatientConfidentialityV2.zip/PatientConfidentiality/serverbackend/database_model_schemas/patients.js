const mongoose=require('mongoose');

const unique_validator = require('mongoose-unique-validator');

const patients_schema = mongoose.Schema({
  'inputPuid':{type:String,require:true,unique:true},
  'inputAid' : {type:String, require:true,unique:true},
  'inputFname' : {type:String,require:true},
  'inputLname' : {type:String,require:true},
  'inputPhone' : {type:String,require:true},
  'inputEmail': {type:String,require:true},
  'inputAge' : {type:String,require:true},
  'inputGender': {type:String,require:true},
  'inputAddress' :{type:String,require:true},

  'created' : {type:Date,default:Date.now()}

});


patients_schema.plugin(unique_validator);

module.exports = mongoose.model('mpatients',patients_schema);
