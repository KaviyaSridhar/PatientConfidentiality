const express = require('express');
var path = require('path');

const mongoose = require('mongoose');

const body_parser = require('body-parser');

const doctorroutes = require('./routes/doctors');

const styperoutes = require('./routes/stypes');

const patientroutes = require('./routes/patients');

const specialistroutes = require('./routes/specialists');

const receptionistroutes = require('./routes/receptionists');

const userroutes = require('./routes/users');

const precordstroutes =require('./routes/precords');

const app = express(); //kind of client which will used for connecting to server

const mstypes = require('./database_model_schemas/stypes');

app.use("/",express.static(path.join(__dirname,"angularpart")));

//mongodb+srv://yogi:abcd.1234@cluster0-adwni.mongodb.net/doctorsdb?retryWrites=true

//mongodb+srv://aishwarya:aishwarya@cluster0-lec4o.mongodb.net/doctorsdb?retryWrites=true&w=majority
mongoose.connect('mongodb+srv://kaviya:yjopIAowbyzseDgo@cluster0-usbaa.mongodb.net/doctorsdb?retryWrites=true&w=majority')
        .then(()=>{
          console.log('CONNECTED TO DATABASES');
          stypes_array=[
            'XRAY SPECIALIST',
            'MRI SPECIALIST',
            'GYNECOLOGIST',
            'BONE SPECIALIST',
            'PEDIATRICS',
          ];
          
          stypes_array.forEach(element => { 
            mstypes.findOne({stype:element})
                   .then(result=>{
                     if(result){
                       console.log(element+" exists");
                     }else{
                      const new_stypes = new mstypes({
                        'stype' : element
                      });
                      new_stypes.save()
                                .then(result=>{
                      
                                });
                     }
                   })
          }); 
        })
        .catch(()=>{
          console.log('ERROR CANNOT CONNECTED TO DATABASE');
        });




app.use((req,res,next)=>{
  res.setHeader('Access-Control-Allow-Origin','*');
  res.setHeader('Access-Control-Allow-Headers','Origin,X-Requested-With,Content-Type,Accept,Authorization');
  res.setHeader('Access-Control-Allow-Methods','GET,PUT,POST,DELETE,OPTION');
  next();
});




// specify the folder
app.use("/uploads",express.static(path.join("uploads")));

app.use(body_parser.json());

app.use(body_parser.urlencoded({extended:false}));

app.use("/api/doctors",doctorroutes);

app.use("/api/stypes",styperoutes);

app.use("/api/patients",patientroutes);

app.use("/api/specialists",specialistroutes);

app.use("/api/receptionists",receptionistroutes);

app.use("/api/patients/precords",precordstroutes);



app.use("/api/users",userroutes);

app.use((req,res,next)=>{
  res.sendFile(path.join(__dirname,"angularpart","index.html"));
})

module.exports = app;
