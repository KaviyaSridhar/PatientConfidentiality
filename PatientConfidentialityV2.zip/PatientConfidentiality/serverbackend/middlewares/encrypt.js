const crypto = require('crypto');

function encrypt(text) {

  var cipher = crypto.createCipher('aes-256-ecb', 'mypassword');
  var mystr = cipher.update(text, 'utf8', 'hex') + cipher.final('hex');
  return mystr;
}

function decrypt(text) {

  var cipher = crypto.createDecipher('aes-256-ecb', 'mypassword');
  var decryptdata = cipher.update(text, 'hex', 'utf8') + cipher.final('utf8');
  return decryptdata;
}

module.exports = { decrypt, encrypt };
