const jwt=require('jsonwebtoken');
module.exports= (req,res,next) =>{
   try {
    const token = req.headers.authorization.split(" ")[1];
    const decodeToken=jwt.verify(token,"DoctorConfidence");
    req.userData={ username:decodeToken.username,
                   userid:decodeToken.userid,
                   stype:decodeToken.stype,
                   role:decodeToken.role
                  };
    console.log(req.userData);
    next();
   }
   catch ( error) {
     res.status(401).json({
       message :'Auth Failed'
     })
   }



}
