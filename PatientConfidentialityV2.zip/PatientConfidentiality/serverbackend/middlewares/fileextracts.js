const multer = require('multer');
const mpatients = require("../database_model_schemas/patients");
const fs = require('fs');


var storage = multer.diskStorage({
  // destination
  destination: function (req, file, cb) {
    dir = "uploads/"+req.body.pid;
            if (!fs.existsSync(dir)){
              fs.mkdirSync(dir);
            }
    cb(null, dir);
  },
  filename: function (req, file, cb) {
    var filename_array = file.originalname.split('.');
    filename = filename_array[0].toLocaleLowerCase().split(' ').join('-');

    const ext = filename_array[1];
    cb(null,filename+Date.now()+'.'+ext);
  }
});
var upload = multer({ storage: storage });

module.exports = upload.array("uploads[]", 12);
