const express= require('express');

const receptionist_routes = express.Router();

const receptionist_controller = require('../controllers/receptionists');

receptionist_routes.post("",receptionist_controller.addreceptionist);
receptionist_routes.get("",receptionist_controller.getreceptionistlist);
receptionist_routes.delete("/:id",receptionist_controller.deletereceptionist);


module.exports = receptionist_routes;
