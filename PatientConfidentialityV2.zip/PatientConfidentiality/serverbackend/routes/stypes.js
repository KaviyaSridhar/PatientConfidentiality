const express= require('express');

const stype_routes = express.Router();

const stype_controller = require('../controllers/stypes');

stype_routes.get("",stype_controller.getallstype);


module.exports = stype_routes;
