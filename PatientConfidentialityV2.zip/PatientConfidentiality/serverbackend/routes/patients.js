const express= require('express');

const patient_routes = express.Router();

const patient_controller = require('../controllers/patients');

patient_routes.post("",patient_controller.addpatient);
patient_routes.get("",patient_controller.getpatientlist);
patient_routes.get("/search/:id",patient_controller.searchpatient);
patient_routes.get("/search/doctors/:id",patient_controller.searchpatientfordoctors);
patient_routes.delete("/:id",patient_controller.deletepatient);
patient_routes.get("/:pid",patient_controller.getSinglePatientDetails);


module.exports = patient_routes;
