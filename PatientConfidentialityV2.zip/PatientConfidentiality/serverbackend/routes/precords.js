const express= require('express');

const precords_routes = express.Router();

const fileextracts = require('../middlewares/fileextracts');

const precords_controller = require('../controllers/precords');

const checkauth = require('../middlewares/check-auth');

precords_routes.post("",fileextracts,precords_controller.addprecords);

precords_routes.post("/specialist",checkauth,fileextracts,precords_controller.addspecialistprecords);

module.exports = precords_routes;
