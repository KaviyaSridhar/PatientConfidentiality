const express= require('express');

const specialist_routes = express.Router();

const specialist_controller = require('../controllers/specialists');

specialist_routes.post("",specialist_controller.addspecialist);
specialist_routes.get("",specialist_controller.getspecialistlist);
specialist_routes.delete("/:id",specialist_controller.deletespecialist);


module.exports = specialist_routes;
