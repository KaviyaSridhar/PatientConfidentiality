const express= require('express');

const user_routes = express.Router();

const user_controller = require('../controllers/users');

user_routes.post("/login",user_controller.userLogin);
user_routes.post("",user_controller.adduser);


module.exports = user_routes;
