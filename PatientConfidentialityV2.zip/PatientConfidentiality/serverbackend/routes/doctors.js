const express= require('express');

const doctor_routes = express.Router();

const doctor_controller = require('../controllers/doctors');

doctor_routes.post("",doctor_controller.adddoctor);
doctor_routes.get("",doctor_controller.getdoctorlist);
doctor_routes.delete("/:id",doctor_controller.deletedoctor);


module.exports = doctor_routes;
