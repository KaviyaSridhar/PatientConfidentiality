const precords = require('../database_model_schemas/precords');
const pfiles = require('../database_model_schemas/pfiles');
const aesproccessor = require("../middlewares/encrypt");

exports.addprecords = (req, res, next) => {
  console.log(req.body);
  console.log(req.files);

  new_precords = new precords({
  'inputPuid':req.body.pid,
  'inputConsultedHospital':aesproccessor.encrypt(req.body.inputChospital),
  'inputConsultedDoctor':aesproccessor.encrypt(req.body.inputCdoctor),
  'inputDescription':aesproccessor.encrypt(req.body.inputDescription)

  });

  new_precords.save()
              .then(result=>{
                const url = req.protocol + "://" +req.get('host');
                record_id = result._id;
                req.files.forEach(element => {
                  new_file = new pfiles({
                    'inputRid':record_id,
                    'inputFilename' :element.filename,
                    'inputURL' : url + '/uploads/'+req.body.pid+'/'+element.filename

                  });
                  new_file.save()
                          .then(result=>{

                          })
                });
                res.status(200).json({
                  message:'Record Inserted',

                })
              })

}

exports.addspecialistprecords = (req, res, next) => {
  console.log(req.body);
  console.log(req.files);

  new_precords = new precords({
  'inputPuid':req.body.pid,
  'inputConsultedHospital':aesproccessor.encrypt(req.body.inputChospital),
  'inputConsultedDoctor':aesproccessor.encrypt(req.body.inputCdoctor),
  'inputDescription':aesproccessor.encrypt(req.body.inputDescription),
  'inputStype':req.userData.stype,
  });

  console.log(new_precords);

  new_precords.save()
              .then(result=>{
                const url = req.protocol + "://" +req.get('host');
                record_id = result._id;
                req.files.forEach(element => {
                  new_file = new pfiles({
                    'inputRid':record_id,
                    'inputFilename' :element.filename,
                    'inputURL' : url + '/uploads/'+req.body.pid+'/'+element.filename
                  });
                  new_file.save()
                          .then(result=>{

                          })
                });
                res.status(200).json({
                  message:'Record Inserted',

                })
              })

}
