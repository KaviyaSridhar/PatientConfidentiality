const mreceptionists = require('../database_model_schemas/receptionists');
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const aesproccessor = require("../middlewares/encrypt");

exports.addreceptionist = (req,res,next) => {
  formdata = req.body;
  console.log(req.body.inputPass);
  bcrypt.hash(req.body.inputPass, 10)
        .then(hashedvalue => {
          const new_receptionist = new mreceptionists({
            'inputFname' : aesproccessor.encrypt(req.body.inputFname),
            'inputLname' : aesproccessor.encrypt(req.body.inputLname),
            'inputEmail' : aesproccessor.encrypt(req.body.inputEmail),
            'inputPass'  : hashedvalue,
            'inputPhone' : aesproccessor.encrypt(req.body.inputPhone),
            'inputAddress':aesproccessor.encrypt(req.body.inputAddress),

          });

          new_receptionist.save()
          .then((result)=>{
            res.status(201).json({
              message :  'Receptionist Added Successfully',
              _id:result._id
            })
          })
          .catch(error=>{
           console.log(error.message);
           var e_mesg = Buffer.from(error.message);
           if(e_mesg.indexOf('unique')>=0) {
            error.message = 'Receptionist is Already Registered';
            res.status(404).json({
              message :  'Receptionist is Already Registered',
              error : error
            })
           } else {
            res.status(404).json({
              message :  'Error in Insertion',
              error : error
            })
           }

         })
        });

}

exports.getreceptionistlist = (req,res,next) =>{
  mreceptionists.find()
           .then((rlistdata)=>{
             newrlistdata = rlistdata.map(eachlist=>{
               return {
                 _id:eachlist._id,
                inputFname:aesproccessor.decrypt(eachlist.inputFname),
                inputLname:aesproccessor.decrypt(eachlist.inputLname),
                inputEmail:aesproccessor.decrypt(eachlist.inputEmail),
                inputPhone:aesproccessor.decrypt(eachlist.inputPhone),
                inputAddress:aesproccessor.decrypt(eachlist.inputAddress)
               }
             })
             res.status(200).json({
               message : 'Data Fetched',
               rlist : newrlistdata
             })
           });
}


exports.deletereceptionist = (req,res,next) => {
  console.log(req.params.id);
  mreceptionists.deleteOne({_id:req.params.id})
          .then((result)=> {
            if(result.n>0) {
              res.status(200).json({
                'message' : 'Data Deleted Successfully'
              })
            } else {
              res.status(404).json({
                'message' : 'Error in Deletion'
              })
            }
          })

}

