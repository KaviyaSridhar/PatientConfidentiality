const mstypes = require('../database_model_schemas/stypes');

exports.getallstype = (req,res,next) => {

  mstypes.find()
  .then((slistdata)=>{
    res.status(200).json({
      message : 'Data Fetched',
      slist : slistdata
    })
  });

}
