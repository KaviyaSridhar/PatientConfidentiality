const mpatients = require("../database_model_schemas/patients");
const mpfiles = require("../database_model_schemas/pfiles");
const aesproccessor = require("../middlewares/encrypt");

exports.addpatient = (req, res, next) => {
  formdata = req.body;

  const new_patient = new mpatients({
    inputPuid: req.body.inputPuid,
    inputFname: aesproccessor.encrypt(req.body.inputFname),
    inputLname: aesproccessor.encrypt(req.body.inputLname),
    inputAid: aesproccessor.encrypt(req.body.inputAid),
    inputAge: aesproccessor.encrypt(req.body.inputAge),

    inputPhone: aesproccessor.encrypt(req.body.inputPhone),
    inputEmail: aesproccessor.encrypt(req.body.inputEmail),
    inputGender: aesproccessor.encrypt(req.body.inputGender),
    inputAddress: aesproccessor.encrypt(req.body.inputAddress)
  });

  new_patient
    .save()
    .then(result => {
      res.status(201).json({
        message: "Patient Added Successfully",
        _id: result._id
      });
    })

    .catch(error => {
      console.log(error.message);
      var e_mesg = Buffer.from(error.message);
      if (e_mesg.indexOf("unique") >= 0) {
        error.message = "Patient is Already Registered";
        res.status(404).json({
          message: "Patient is Already Registered",
          error: error
        });
      } else {
        res.status(404).json({
          message: "Error in Insertion",
          error: error
        });
      }
    });
};

exports.getpatientlist = (req, res, next) => {
  mpatients.find().then(plistdata => {
    newplistdata=plistdata.map(eachlist =>{
      return{
        _id:eachlist._id,
        inputPuid:eachlist.inputPuid,
        inputFname:aesproccessor.decrypt(eachlist.inputFname),
        inputLname:aesproccessor.decrypt(eachlist.inputLname),
        inputAid:aesproccessor.decrypt(eachlist.inputAid),
        inputAge:aesproccessor.decrypt(eachlist.inputAge),
        inputPhone:aesproccessor.decrypt(eachlist.inputPhone),
        inputEmail:aesproccessor.decrypt(eachlist.inputEmail),
        inputGender:aesproccessor.decrypt(eachlist.inputGender),
        inputAddress:aesproccessor.decrypt(eachlist.inputAddress)

      };
    })
    res.status(200).json({
      message: "Data Fetched",
      plist: newplistdata
    });
  });
};

exports.deletepatient = (req, res, next) => {
  console.log(req.params.id);
  mpatients.deleteOne({ _id: req.params.id }).then(result => {
    if (result.n > 0) {
      res.status(200).json({
        message: "Data Deleted Successfully"
      });
    } else {
      res.status(404).json({
        message: "Error in Deletion"
      });
    }
  });
};

exports.getSinglePatientDetails = (req, res, next) => {
  pid = aesproccessor.encrypt(req.params.pid);
  mpatients.findOne({ _id: pid }).then(result => {
    newplistdata=result.map(eachlist =>{
      return{
        _id:eachlist._id,
        inputPuid:eachlist.inputPuid,
        inputFname:aesproccessor.decrypt(eachlist.inputFname),
        inputLname:aesproccessor.decrypt(eachlist.inputLname),
        inputAid:aesproccessor.decrypt(eachlist.inputAid),
        inputAge:aesproccessor.decrypt(eachlist.inputAge),
        inputPhone:aesproccessor.decrypt(eachlist.inputPhone),
        inputEmail:aesproccessor.decrypt(eachlist.inputEmail),
        inputGender:aesproccessor.decrypt(eachlist.inputGender),
        inputAddress:aesproccessor.decrypt(eachlist.inputAddress)

      };
    })
    res.status(200).json({
      message: "Data Fetched",
      pdata: newplistdata
    });
  });
};

exports.searchpatient  = (req, res, next) => {
  pid = req.params.id;
  console.log(pid);
  mpatients.find({ $or:[ {'inputPuid':pid}, {'inputAid':pid} ]})
           .then(result => {
             newplist = result.map(eachlist=>{
               return{
                _id:eachlist._id,
                inputPuid:eachlist.inputPuid,
                inputFname:aesproccessor.decrypt(eachlist.inputFname),
                inputLname:aesproccessor.decrypt(eachlist.inputLname),
                inputPhone:aesproccessor.decrypt(eachlist.inputPhone)
               }
             })
    res.status(200).json({
      message: "Data Fetched",
      pdata:newplist
    });
  });
};

exports.searchpatientfordoctors = (req, res, next) => {
  puid = req.params.id;
  aid= puid;
  final_precords=[];
  console.log(puid);
  mpatients.find({ $or:[ {'inputPuid':puid}, {'inputAid':aid} ]})
           .then(patient_result=>{
             console.log("THE RESULT IS :");
             console.log(patient_result);
             patient_id=patient_result[0]._id;
             console.log('the pid is'+patient_id);
            mpatients.aggregate([
              {
                $lookup: {
                    from: "mprecords", // collection name in db
                    localField: "_id",
                    foreignField: "inputPuid",
                    as: "mprecords"
                }
              },
              {
                $lookup: {
                    from: "mpfiles", // collection name in db
                    localField: "mprecords._id",
                    foreignField: "inputRid",
                    as: "mpfiles"
                }
              },
              {
                 $match: { "_id": { $eq: patient_id } }
              },

            ])
             .then(result => {
               console.log("FInal Result is");
               console.log(result);
               console.log(result[0].mprecords);

               demprecords = result[0].mprecords.map(eachlist=>{
                 return {
                   _id:eachlist._id,
                   inputStype :eachlist.inputStype,
                   inputPuid : eachlist.inputPuid,
                   inputConsultedHospital:aesproccessor.decrypt(eachlist.inputConsultedHospital),
                   inputConsultedDoctor:aesproccessor.decrypt(eachlist.inputConsultedDoctor),
                   inputDescription:aesproccessor.decrypt(eachlist.inputDescription),
                   created:eachlist.created

                 }
               });


               newplist = result.map(eachlist=>{
                 return{
                   _id:eachlist._id,
                   inputPuid:eachlist.inputPuid,
                   inputFname:aesproccessor.decrypt(eachlist.inputFname),
                   inputLname:aesproccessor.decrypt(eachlist.inputLname),
                   inputEmail:aesproccessor.decrypt(eachlist.inputEmail),
                   inputAid:aesproccessor.decrypt(eachlist.inputAid),
                   inputAge:aesproccessor.decrypt(eachlist.inputAge),
                   inputPhone:aesproccessor.decrypt(eachlist.inputPhone),
                   inputGender:aesproccessor.decrypt(eachlist.inputGender),
                   inputAddress:aesproccessor.decrypt(eachlist.inputAddress)
                 }

               })

               newplist[0].mprecords = demprecords;
               newplist[0].mpfiles = result[0].mpfiles;
                res.status(200).json({
                         message: "Data Fetched",
                         pdata: newplist
                 });
            });
           })

};
