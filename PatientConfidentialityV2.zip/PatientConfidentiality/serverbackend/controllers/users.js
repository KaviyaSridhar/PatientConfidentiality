const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const musers = require("../database_model_schemas/users");
const mdoctors = require("../database_model_schemas/doctors");
const mspecialists = require("../database_model_schemas/specialists");
const mreceptionists = require("../database_model_schemas/receptionists");
const aesproccessor = require("../middlewares/encrypt");


exports.adduser = (req, res, next) => {
  formdata = req.body;
  bcrypt.hash(req.body.inputPass, 10).then(hashedvalue => {
    const new_user = new musers({
      'inputFname' : req.body.inputFname,
      'inputLname' : req.body.inputLname,
      'inputUname' : req.body.inputUname,
      'inputPass'  : hashedvalue,
      'inputEmail' : req.body.inputEmail,
      'inputRole': req.body.inputRole,

    });

    new_user.save()
               .then((result)=>{
                 res.status(201).json({
                   message :  'user Added Successfully',
                   _id:result._id
                 })
               })
               .catch(error=>{
                console.log(error.message);
                var e_mesg = Buffer.from(error.message);
                if(e_mesg.indexOf('unique')>=0) {
                 error.message = 'User is Already Registered';
                 res.status(404).json({
                   message :  'user is Already Registered',
                   error : error
                 })
                } else {
                 res.status(404).json({
                   message :  'Error in Insertion',
                   error : error
                 })
                }

              })
  });
};

exports.userLogin = (req,res,next) => {
  let fetched_user;
  usertype = req.body.ltype;
  console.log(req.body);
  if(usertype === 'Admin') {
    console.log("Insdie Admin Check");
    musers.findOne({inputUname:req.body.username})
    .then(user => {
      console.log("Username Exists");
      if(!user) {
       return res.status(401).json({
         message:'Autentication Failed'
       });
      }
      fetched_user = user;
      console.log(fetched_user)
      return bcrypt.compare(req.body.password,fetched_user.inputPass);
    })
    .then((result)=> {
      console.log("Inside bcrypt then");
      if(!result) {
        console.log("Not matching bcrypt then if");
       return res.status(401).json({
         message:'Autentication Failed'
       });
      }
      const token = jwt.sign({username: fetched_user.inputUname,
                              userid: fetched_user._id,
                              role:0},
                             "DoctorConfidence",
                             {expiresIn: '1h'}
                             );
      res.status(200).json({
        token:token,
        expiresIn:3600,
        userid: fetched_user._id,
        user_role:0
      });
    })
    .catch(error=>{
      console.log(error);

    })
  }

  if(usertype === 'Doctor') {
    mdoctors.findOne({inputUname: aesproccessor.encrypt(req.body.username)})
    .then(user => {
      if(!user) {
       return res.status(401).json({
         message:'Autentication Failed'
       });
      }
      fetched_user = user;
      return bcrypt.compare(req.body.password,fetched_user.inputPass);
    })
    .then((result)=> {
      if(!result) {

       return res.status(401).json({
         message:'Autentication Failed'
       });
      }
      const token = jwt.sign({username: fetched_user.username,
                              userid: fetched_user._id,
                              role:1},
                              "DoctorConfidence",
                             {expiresIn: '1h'}
                             );
      res.status(200).json({
        token:token,
        expiresIn:3600,
        userid: fetched_user._id,
        user_role:1
      });
    })
    .catch(error=>{
     res.status(401).json({
       message:'Invalid Autentication Credentials'
     });
    })
  }

  if(usertype === 'Specialist') {
    mspecialists.findOne({inputUname:aesproccessor.encrypt(req.body.username)})
    .populate({path : 'inputStype', select : 'stype -_id'})
    .then(user => {
      if(!user) {
       return res.status(401).json({
         message:'Autentication Failed'
       });
      }
      fetched_user = user;
      return bcrypt.compare(req.body.password,fetched_user.inputPass);
    })
    .then((result)=> {
      if(!result) {

       return res.status(401).json({
         message:'Autentication Failed'
       });
      }
      const token = jwt.sign({username: fetched_user.username,
                              userid: fetched_user._id,
                              stype:fetched_user.inputStype.stype,
                              role:2},
                              "DoctorConfidence",
                             {expiresIn: '1h'}
                             );
      res.status(200).json({
        token:token,
        expiresIn:3600,
        userid: fetched_user._id,
        user_role:2
      });
    })
    .catch(error=>{
     res.status(401).json({
       message:'Invalid Autentication Credentials'
     });
    })
  }

  if(usertype === 'Recieptionist') {
    console.log('INSIDE RECEPTIONIST');
    mreceptionists.findOne({inputEmail:aesproccessor.encrypt(req.body.username)})
    .then(user => {
      if(!user) {
       return res.status(401).json({
         message:'Autentication Failed'
       });
      }
      console.log('INSIDE RECEPTIONIST');
      fetched_user = user;
      return bcrypt.compare(req.body.password,fetched_user.inputPass);
    })
    .then((result)=> {
      if(!result) {

       return res.status(401).json({
         message:'Autentication Failed'
       });
      }
      const token = jwt.sign({username: fetched_user.username,
                              userid: fetched_user._id,
                              role:3},
                              "DoctorConfidence",
                             {expiresIn: '1h'}
                             );
      res.status(200).json({
        token:token,
        expiresIn:3600,
        userid: fetched_user._id,
        user_role:3
      });
    })
    .catch(error=>{
     res.status(401).json({
       message:'Invalid Autentication Credentials'
     });
    })
  }





 }

