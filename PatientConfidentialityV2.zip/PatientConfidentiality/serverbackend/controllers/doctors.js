const mdoctors = require("../database_model_schemas/doctors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const aesproccessor = require("../middlewares/encrypt");

exports.adddoctor = (req, res, next) => {
  formdata = req.body;


  bcrypt.hash(req.body.inputPass, 10).then(hashedvalue => {
    const new_doctor = new mdoctors({
      'inputFname' : aesproccessor.encrypt(req.body.inputFname),
      'inputLname' : aesproccessor.encrypt(req.body.inputLname),
      'inputUname' : aesproccessor.encrypt(req.body.inputUname),
      'inputPass'  : hashedvalue,
      'inputPhone' : aesproccessor.encrypt(req.body.inputPhone),
      'inputEmail' : aesproccessor.encrypt(req.body.inputEmail),
      'inputGender': aesproccessor.encrypt(req.body.inputGender),
      'inputQualification' :aesproccessor.encrypt(req.body.inputQualification),
      'inputLatitude' :req.body.inputLatitude,
      'inputLongitude' :req.body.inputLongitude,
    });

    new_doctor.save()
               .then((result)=>{
                 res.status(201).json({
                   message :  'Doctor Added Successfully',
                   _id:result._id
                 })
               })
               .catch(error=>{
                console.log(error.message);
                var e_mesg = Buffer.from(error.message);
                if(e_mesg.indexOf('unique')>=0) {
                 error.message = 'Doctor is Already Registered';
                 res.status(404).json({
                   message :  'Doctor is Already Registered',
                   error : error
                 })
                } else {
                 res.status(404).json({
                   message :  'Error in Insertion',
                   error : error
                 })
                }

              })
  });
};

exports.getdoctorlist = (req, res, next) => {
  console.log('came here');
  mdoctors.find().then(dlistdata => {
    console.log(dlistdata);
    newdlistdata=dlistdata.map(eachlist=>{

      return {
        _id:eachlist._id,
         inputFname:aesproccessor.decrypt(eachlist.inputFname),
         inputLname:aesproccessor.decrypt(eachlist.inputLname),
         inputUname:aesproccessor.decrypt(eachlist.inputUname),
         inputLatitude:eachlist.inputLatitude,
         inputLongitude:eachlist.inputLongitude,
         inputPhone:aesproccessor.decrypt(eachlist.inputPhone),
         inputEmail:aesproccessor.decrypt(eachlist.inputEmail),
         inputGender:aesproccessor.decrypt(eachlist.inputGender),
         inputQualification:aesproccessor.decrypt(eachlist.inputQualification)
      };
    })
    res.status(200).json({
      message: "Data Fetched",
      dlist: newdlistdata

    });

  });

};

exports.deletedoctor = (req, res, next) => {
  console.log(req.params.id);
  mdoctors.deleteOne({ _id: req.params.id }).then(result => {
    if (result.n > 0) {
      res.status(200).json({
        message: "Data Deleted Successfully"
      });
    } else {
      res.status(404).json({
        message: "Error in Deletion"
      });
    }
  });
};
