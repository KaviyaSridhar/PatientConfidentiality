var latitude=15.815046;
var longitude=74.487187;
window.onload = function() {
                 var marker;
                 var infowindow;
                 var latlng = new google.maps.LatLng(latitude,longitude);
                 var map = new google.maps.Map(document.getElementById('map'),{
                 center: latlng,
                 zoom: 10,
                mapTypeId: google.maps.MapTypeId.ROADMAP
             });

 var marker = new google.maps.Marker({
      position: latlng,
      map: map,
      title: 'Current Complaint Location',
      draggable: true
  });

 google.maps.event.addListener(marker, 'dragend', function(a) {
     // console.log(a);
      var element_lat = document.getElementById("inputLatitude");
      element_lat.value = a.latLng.lat().toFixed(4);
      var element_long = document.getElementById("inputLongitude");
      element_long.value = a.latLng.lng().toFixed(4);
      
  });
};		