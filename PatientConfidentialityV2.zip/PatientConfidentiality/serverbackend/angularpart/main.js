(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-header></app-header>\n<app-top-navigation></app-top-navigation>\n<app-slides></app-slides>\n<div class=\"content\">\n    <div class=\"container\">\n      <div class=\"row\">\n          <app-leftmenu></app-leftmenu>\n          <div class=\"col-md-9\">\n              <app-main-content></app-main-content>\n          </div>\n      </div>\n    </div>\n</div>\n\n<app-footer></app-footer>\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/login/login.component.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/login/login.component.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"box-right\">\n  <h2>Admin Login Section</h2>\n</div>\n<form [formGroup]=\"myform\"\n      (submit)=\"onLogin()\">\n\n  <div class=\"form-group\">\n    <label for=\"inputPhone\" class=\"req\">Username</label>\n    <input type=\"text\"\n           class=\"form-control\"\n           id=\"inputUsername\"\n           placeholder=\"Specify Username\"\n           name=\"inputUsername\"\n           formControlName='inputUsername'\n            >\n    <app-show-errors [control]=\"myform.controls.inputUsername\"></app-show-errors>\n  </div>\n  <div class=\"form-group\">\n    <label for=\"inputPassword\" class=\"req\">Password</label>\n    <input type=\"password\"\n           class=\"form-control\"\n           id=\"inputPassword\"\n           placeholder=\"Specify Password\"\n           name=\"inputPassword\"\n           formControlName='inputPassword'\n            >\n    <app-show-errors [control]=\"myform.controls.inputPassword\"></app-show-errors>\n  </div>\n  <div class=\"form-group\">\n    <label for=\"inputStype\" class=\"req\"> Login Type</label>\n    <select class=\"form-control\"\n                id=\"inputStype\"\n                name=\"inputStype\"\n                formControlName=\"inputStype\"\n                >\n\n                <option value=\"Admin\">Admin</option>\n                <option value=\"Doctor\">Doctor</option>\n                <option value=\"Specialist\">Specialist</option>\n                <option value=\"Recieptionist\">Recieptionist</option>\n\n\n         </select>\n    <app-show-errors [control]=\"myform.controls.inputStype\"></app-show-errors>\n  </div>\n  <button type=\"submit\" [disabled]=\"myform.invalid\" class=\"btn btn-primary btn-space\">Login</button>\n  <button type=\"reset\" class=\"btn btn-primary\">Reset</button>\n\n</form>\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/doctors/doctor-create/doctor-create.component.html":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/doctors/doctor-create/doctor-create.component.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"box-right\">\n    <h2>Add New Doctor Details</h2>\n  </div>\n  <form [formGroup]=\"myform\"\n  (submit)=\"onSubmit()\"\n  novalidate>\n      <div class=\"form-group\">\n          <label for=\"inputFname\" class=\"req\">FirstName</label>\n          <input type=\"text\"\n                 class=\"form-control\"\n                 id=\"inputFname\"\n                 placeholder=\"Specify FirstName\"\n                 name=\"inputFname\"\n                 formControlName='inputFname'\n                  >\n        <app-show-errors [control]=\"myform.controls.inputFname\"></app-show-errors>\n      </div>\n      <div class=\"form-group\">\n        <label for=\"inputLname\" class=\"req\">LastName</label>\n        <input type=\"text\"\n               class=\"form-control\"\n               id=\"inputLname\"\n               placeholder=\"Specify LastName\"\n               name=\"inputLname\"\n               formControlName='inputLname'\n                >\n      <app-show-errors [control]=\"myform.controls.inputLname\"></app-show-errors>\n      </div>\n      <div class=\"form-group\">\n          <label for=\"inputUname\" class=\"req\">UserName</label>\n          <input type=\"text\"\n                 class=\"form-control\"\n                 id=\"inputUname\"\n                 placeholder=\"Specify UserName\"\n                 name=\"inputUname\"\n                 formControlName='inputUname'\n                  >\n        <app-show-errors [control]=\"myform.controls.inputUname\"></app-show-errors>\n        </div>\n        <div class=\"form-group\">\n            <label for=\"inputPass\" class=\"req\">Password</label>\n            <input type=\"password\"\n                   class=\"form-control\"\n                   id=\"inputPass\"\n                   placeholder=\"Specify Password\"\n                   name=\"inputPass\"\n                   formControlName='inputPass'\n                    >\n            <app-show-errors [control]=\"myform.controls.inputPass\"></app-show-errors>\n            </div>\n      <div class=\"form-group\">\n        <label for=\"inputPhone\" class=\"req\">Mobile Number</label>\n        <input type=\"text\"\n               class=\"form-control\"\n               id=\"inputPhone\"\n               placeholder=\"Specify Mobile Number\"\n               name=\"inputPhone\"\n               formControlName='inputPhone'\n                >\n        <app-show-errors [control]=\"myform.controls.inputPhone\"></app-show-errors>\n      </div>\n      <div class=\"form-group\">\n        <label for=\"inputEmail\" class=\"req\">Email ID</label>\n        <input type=\"text\"\n               class=\"form-control\"\n               id=\"inputEmail\"\n               placeholder=\"Specify Email ID\"\n               name=\"inputEmail\"\n               formControlName='inputEmail'\n                >\n        <app-show-errors [control]=\"myform.controls.inputEmail\"></app-show-errors>\n      </div>\n\n      <div class=\"form-group\">\n          <label for=\"inputGender\" class=\"req\"> Gender</label>\n          <select class=\"form-control\"\n                      id=\"inputGender\"\n                      name=\"inputGender\"\n                      formControlName=\"inputGender\"\n                      >\n\n                    <option value=\"0\">Male</option>\n                    <option value=\"1\">Female</option>\n\n\n               </select>\n          <app-show-errors [control]=\"myform.controls.inputGender\"></app-show-errors>\n        </div>\n        <div class=\"form-group\">\n            <label for=\"inputQualification\" class=\"req\">Qualification</label>\n            <input type=\"text\"\n                   class=\"form-control\"\n                   id=\"inputQualification\"\n                   placeholder=\"Specify Qualification\"\n                   name=\"inputQualification\"\n                   formControlName='inputQualification'\n                    >\n            <app-show-errors [control]=\"myform.controls.inputQualification\"></app-show-errors>\n          </div>\n          <div class=\"form-group\">\n            <label for=\"inputMap\">Mark The Location Of Hospital</label>\n            <google-map \n               height=\"400px\" \n               width=\"100%\" \n               [zoom]=\"zoom\"\n               [center]=\"center\"\n               [options]=\"options\"\n               (mapClick)=\"click($event)\">\n               <map-marker\n                *ngFor=\"let marker of markers\"\n                [position]=\"marker.position\"\n                [title]=\"marker.title\"\n                [options]=\"marker.options\"\n              >\n              </map-marker>\n              </google-map>\n          </div>\n          <div class=\"form-group\">\n            <label for=\"inputLatitude\">Latitude</label>\n            <input type=\"text\" formControlName='inputLatitude' class=\"form-control\" id=\"inputLatitude\" >\n          </div>\n          <div class=\"form-group\">\n            <label for=\"inputLongitude\">Longitude</label>\n            <input type=\"text\" formControlName='inputLongitude' class=\"form-control\" id=\"inputLongitude\" >\n          </div>\n          <button type=\"submit\" [disabled]=\"myform.invalid\" class=\"btn btn-primary btn-space\">Submit Form</button>\n          <button type=\"reset\" class=\"btn btn-primary\">Reset</button>\n  </form>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/doctors/doctor-list/doctor-list.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/doctors/doctor-list/doctor-list.component.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h2>COMPLETE DOCTOR LIST</h2><br/>\n\t\t  <div class=\"col-md-7\" >\n\t\t\t\t<table class=\"table table-bordered table-striped table-hover\" *ngIf=\"DoctorList.length>=1\">\n\t\t\t\t\t<tr>\n            <th>First Name</th>\n            <th>Last Name</th>\n            <th>Username</th>\n             <th>Mobile Number</th>\n            <th>Email-ID</th>\n            <th>Gender</th>\n            <th>Qualification</th>\n\n\n            <th>Action</th>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr *ngFor=\"let eachdata of DoctorList\">\n                        <td>{{eachdata.inputFname}}</td>\n                        <td>{{eachdata.inputLname}}</td>\n                        <td>{{eachdata.inputUname}}</td>\n                        <td>{{eachdata.inputPhone}}</td>\n                        <td>{{eachdata.inputEmail}}</td>\n                        <td>{{eachdata.inputGender == '0' ? 'Male' : 'Female'}}</td>\n                        <td>{{eachdata.inputQualification}}</td>\n                        <td>\n                           <button class=\"btn btn-danger btn-space\" (click)=\"deleteDoctor(eachdata._id)\"><i class=\"fa fa-eye\"></i> Delete</button>\n\t\t\t\t\t\t\t\t\t\t\t\t</td>\n              </tr>\n        </table>\n        <h4 *ngIf=\"DoctorList.length<1\" >Sorry No Doctor Exists</h4>\n      </div>\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/doctors/pages/about-project/about-project.component.html":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/doctors/pages/about-project/about-project.component.html ***!
  \****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>\n  The research of the infrastructure and current medical data management systems in various hospitals has led to the design of an electronic medical record keeping system to acquire, process, store and share health information in a fully secure and automated computer network-based system. The modules in the system have automated data acquisition from Ultrasound, Digital Radiography, CT scanner, MRI and Laboratory stations, and manage other related activities in the hospital. Database servers currently store personal information along with text data, image data and will store video data in the future. The system will allow the doctors to login and review online patient medical records at home. It meets the needs for healthcare in developing countries with low investment cost, ease of implementation, and convenience for doctors and medical staff. Apart from the storage the project focuses on keeping the patients data confidential. For this purpose the AES 256 algorithm has been used .It shows the encrypted data to other users and the actual data is visible to only doctor . Thus in this way the project meets two important features that is storing entire data at one place and the second is to maintain data confidentiality .The cloud platform used in this project is AWS and mongodb database for storage. The reason behind using AWS cloud is it is most secure largest community of customers and partners, fastest pace of innovation, most proven and operational expertise.\n</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/doctors/pages/about-us/about-us.component.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/doctors/pages/about-us/about-us.component.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>\n  Electronic medical records are, in a lot of ways, i think the aspect of the technology that is going to revolutionize the way we deliver care.\nAnd its not just that we will be able to collect information, its that everyone involved in the healthcare enterprise will be able to use that information more effectively.\nThe current medical records system is this: room after room after room in a hospital filled with paper files.\n</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/doctors/pages/contact-us/contact-us.component.html":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/doctors/pages/contact-us/contact-us.component.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"col-md-6\">\n  <div class='inwrapper '>\n    <address >\n      <i class='fa fa-map-marker'></i>&nbsp;<strong>Jain College Of Engineering</strong><br />\n      Tippusultan Nagar, Hunchyanatti Cross,<br />\n      Machhe, Belgaum, Karnataka 590014\n      </address>\n      <div class=''><i class='fa fa-fax'></i>&nbsp;FAX: 91-831-2441909</div>\n      <div><i class='fa fa-phone'></i>&nbsp;Call: 0831 241 1192</div>\n  </div>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/doctors/pages/mapview/mapview.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/doctors/pages/mapview/mapview.component.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"row\">\n    <div class=\"col-md-12\">\n        <label for=\"inputMap\">Mark The Location Of Hospital</label>\n        <google-map \n           height=\"600px\" \n           width=\"100%\" \n           [zoom]=\"zoom\"\n           [center]=\"center\"\n           [options]=\"options\"\n           (mapClick)=\"click($event)\">\n           <map-marker\n            *ngFor=\"let marker of markers\"\n            [position]=\"marker.position\"\n            [title]=\"marker.title\"\n            [options]=\"marker.options\"\n          >\n          </map-marker>\n          </google-map>\n    </div>\n  \n  </div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/footer/footer.component.html":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/footer/footer.component.html ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"footer\">\n  <div class=\"container\">\n\n    <hr/>\n    <div class=\"pull-left\">\n      <p>&copy; 2019 All Rights Reserved</p>\n    </div>\n    <div class=\"pull-right\"><small class=\"\">Designed & Developed by <a href=\"https://www.doctorassociation.au\">www.doctorassociation.au</a></small></div>\n  </div>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/header/address/address.component.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/header/address/address.component.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"col-md-4\">\n  <div class='inwrapper text-right'>\n    <address >\n      <i class='fa fa-map-marker'></i>&nbsp;<strong>RMIT College of MS</strong><br />\n      Brisbane, Melboure<br />\n      Australia\n      </address>\n      <div class=''><i class='fa fa-fax'></i>&nbsp;FAX: 01-831-2441909</div>\n      <div><i class='fa fa-phone'></i>&nbsp;Call: 0831 241 1192</div>\n  </div>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/header/header.component.html":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/header/header.component.html ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header\">\n  <div class=\"container\">\n    <div class=\"row\">\n      <app-logo></app-logo>\n      <app-address></app-address>\n    </div>\n\n  </div>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/header/logo/logo.component.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/header/logo/logo.component.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"col-md-8 logo\">\n  <h1>PATIENT <strong><i class=\"fa fa-lock\" aria-hidden=\"true\"></i>&nbsp;CONFIDENTIALITY</strong></h1>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/leftmenu/leftmenu.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/leftmenu/leftmenu.component.html ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<div  *ngIf=\"isAuthenticated\" class=\"col-md-3 left_block\" >\n  <h2>Quick Links</h2>\n  <div class=\"panel-group\" id=\"accordion\">\n\n    <!--Main Assocaition Menus-->\n    <div *ngIf=\"isAuthenticated && user_role==0\" class=\"panel panel-default\">\n    <div class=\"panel-heading\">\n      <h4 class=\"panel-title\">\n      <a data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseOne\">\n       Main Association\n      </a>\n      </h4>\n    </div>\n    <div id=\"collapseOne\" class=\"panel-collapse collapse in\">\n\n        <ul class='list-group '>\n          <li class='list-group-item'>\n            <a routerLink='/doctors'>Add Doctors</a>\n          </li>\n\n          <!-- <li class='list-group-item'>\n            <a routerLink='/patients'>Add Patients</a>\n          </li>\n          <li class='list-group-item'>\n              <a routerLink='/users'>Add Users</a>\n          </li>\n\n         <li class='list-group-item'>\n            <a routerLink='/branches'>List Doctors</a>\n          </li>-->\n          <li class='list-group-item'>\n            <a routerLink=\"/specialists\">Add Specialist</a>\n          </li>\n          <!--<li class='list-group-item'>\n            <a routerLink=\"/semesters\">List Specialist</a>\n          </li>-->\n\n        </ul>\n\n    </div>\n    </div>\n\n    <div *ngIf=\"isAuthenticated && user_role==0\" class=\"panel panel-default\">\n      <div class=\"panel-heading\">\n        <h4 class=\"panel-title\">\n        <a data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseFive\">\n        List All Section\n        </a>\n        </h4>\n      </div>\n      <div id=\"collapseFive\" class=\"panel-collapse collapse\">\n        <ul class='list-group '>\n          <li class='list-group-item'>\n            <a routerLink=\"/doctors-list\">List All Doctors</a>\n          </li>\n          <li class='list-group-item'>\n            <a routerLink=\"/patients-list\">List All Patients</a>\n          </li>\n\n          <li class='list-group-item'>\n            <a routerLink=\"/receptionists-list\">List All Receptionists</a>\n          </li>\n\n          <li class='list-group-item'>\n            <a routerLink=\"/specialists-list\">List All Specialist</a>\n          </li>\n\n\n        </ul>\n      </div>\n\n\n      </div>\n\n\n    <!--End Main Assocaition Menus-->\n\n    <!--Doctors Menus-->\n    <div *ngIf=\"isAuthenticated && user_role==1\" class=\"panel panel-default\">\n    <div class=\"panel-heading\">\n      <h4 class=\"panel-title\">\n      <a data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseTwo\">\n      Doctor Section\n      </a>\n      </h4>\n    </div>\n    <div id=\"collapseTwo\" class=\"panel-collapse collapse\">\n      <ul class='list-group '>\n        <li class='list-group-item'>\n          <a routerLink=\"/receptionists\">Add Receptionist</a>\n        </li>\n        <li class='list-group-item'>\n          <a routerLink=\"/doctor-patient-list\">View Patient Details</a>\n        </li>\n\n      </ul>\n    </div>\n\n\n    </div>\n    <!--END Doctors Menus-->\n\n    <!-- Specialist Menus-->\n      <div *ngIf=\"isAuthenticated && user_role==2\" class=\"panel panel-default\">\n        <div class=\"panel-heading\">\n          <h4 class=\"panel-title\">\n          <a data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseFour\">\n          Specialist Section\n          </a>\n          </h4>\n        </div>\n        <div id=\"collapseFour\" class=\"panel-collapse collapse\">\n          <ul class='list-group '>\n            <li class='list-group-item'>\n              <a routerLink=\"/specialist-precords\">Add Patient Records</a>\n            </li>\n           <!-- <li class='list-group-item'>\n              <a routerLink=\"/subjects-list\">List Patient Records</a>\n            </li>-->\n\n          </ul>\n        </div>\n\n\n        </div>\n    <!-- End Specialist Menus-->\n\n\n\n   <!--Receieptinist Menus-->\n   <div *ngIf=\"isAuthenticated && user_role==3\" class=\"panel panel-default\">\n    <div class=\"panel-heading\">\n      <h4 class=\"panel-title\">\n      <a data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseThree\">\n      Receptionist Section\n      </a>\n      </h4>\n    </div>\n    <div id=\"collapseThree\" class=\"panel-collapse collapse\">\n      <ul class='list-group '>\n        <li class='list-group-item'>\n          <a routerLink=\"/precords\">Add Patient Records</a>\n        </li>\n        <li class='list-group-item'>\n          <a routerLink=\"/patients\">Add Patient</a>\n        </li>\n        <!--<li class='list-group-item'>\n          <a routerLink=\"/subjects-list\">List Patient Records</a>\n        </li>-->\n\n      </ul>\n    </div>\n\n\n    </div>\n    <!-- END Receieptinist Menus-->\n\n\n\n  </div>\n\n</div>\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/main-content/main-content.component.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/main-content/main-content.component.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n            <flash-messages></flash-messages>\n\n            <router-outlet></router-outlet>\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/patients/doctor-patient-list/doctor-patient-list.component.html":
/*!***********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/patients/doctor-patient-list/doctor-patient-list.component.html ***!
  \***********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>\n  DOCTORS RECORDS SECTION\n</p>\n\n\n<form (submit)=\"onSearch()\"\n[formGroup]=\"myform\"\nnovalidate>\n  <div class=\"form-group\">\n    <label for=\"inputPuid\" class=\"req\">Enter Patient ID/Adhar ID</label>\n    <input type=\"text\"\n           class=\"form-control\"\n           id=\"inputPuid\"\n           placeholder=\"Specify Patient ID/Adhar ID\"\n           name=\"inputPuid\"\n           formControlName='inputPuid'\n            >\n  <!--<app-show-errors [control]=\"myform.controls.inputPuid\"></app-show-errors>-->\n</div>\n<button type=\"submit\" [disabled]=\"myform.invalid\" class=\"btn btn-primary btn-space\">Search</button>\n</form>\n\n<div *ngIf=\"patient_data!=null\">\n  <h2>Patient Details</h2><br/>\n\n\n\n  <table class=\"table table-bordered table-striped table-hover\" >\n    <tr>\n      <th>Patient UID</th>\n      <th>First Name</th>\n      <th>Last Name</th>\n      <th>Mobile Number</th>\n      <th>Gender</th>\n    </tr>\n    <tr>\n      <td>{{patient_data.inputPuid}}</td>\n      <td>{{patient_data.inputFname}}</td>\n      <td>{{patient_data.inputLname}}</td>\n      <td>{{patient_data.inputPhone}}</td>\n      <td>{{patient_data.inputGender==0?'Male':'Female'}}</td>\n\n    </tr>\n    </table>\n</div>\n<br/>\n\n\n<div *ngIf=\"patient_data!=null\">\n<div *ngFor=\"let eachrecord of patient_data.mprecords\">\n    <table class=\"table table-bordered table-striped table-hover\" *ngIf=\"eachrecord.inputStype==='CONSULTATION'\">\n        <tr>\n          <td colspan=\"2\"><b>Consultation Details</b></td>\n        </tr>\n        <tr>\n            <td>Hospital</td>\n            <td>{{eachrecord.inputConsultedHospital}}</td>\n        </tr>\n\n        <tr>\n            <td>Doctor</td>\n            <td>{{eachrecord.inputConsultedDoctor}}</td>\n        </tr>\n        <tr>\n            <td>Consultation Detailed Description</td>\n            <td><textarea rows=\"4\" cols=\"80\" readonly placeholder=\"Details\">{{eachrecord.inputDescription}}</textarea></td>\n        </tr>\n\n        <tr>\n            <td>Consultation Files</td>\n            <td>\n                <ul>\n                  <li *ngFor=\"let eachfile of eachrecord.files\"><a href=\"{{eachfile.inputUrl}}\">{{eachfile.inputFilename}}</a></li>\n\n                </ul>\n            </td>\n        </tr>\n\n        <tr>\n            <td>Visited Date</td>\n            <td>{{eachrecord.created}}</td>\n        </tr>\n\n    </table>\n\n\n    <table class=\"table table-bordered specialist table-striped table-hover\" *ngIf=\"eachrecord.inputStype!='CONSULTATION'\">\n            <tr>\n                <td style=\"color:blue;\" ><b>Specialist Details</b></td>\n                <td>{{eachrecord.inputStype}}</td>\n            </tr>\n\n            <tr>\n                <td>Hospital</td>\n                <td>{{eachrecord.inputConsultedDoctor}}</td>\n            </tr>\n\n            <tr>\n                <td>Doctor</td>\n                <td>{{eachrecord.inputConsultedDoctor}}</td>\n            </tr>\n            <tr>\n                <td>Consultation Detailed Description</td>\n                <td><textarea rows=\"4\" cols=\"80\" readonly placeholder=\"Details\">{{eachrecord.inputDescription}}</textarea></td>\n            </tr>\n\n            <tr>\n                <td>Patient Files</td>\n                <td>\n                    <ul>\n                        <li *ngFor=\"let eachfile of eachrecord.files\"><a href=\"{{eachfile.inputUrl}}\">{{eachfile.inputFilename}}</a></li>\n\n                    </ul>\n                </td>\n            </tr>\n\n            <tr>\n                <td>Visited Date</td>\n                <td>{{eachrecord.created}}</td>\n            </tr>\n\n        </table>\n\n</div>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/patients/patient-create/patient-create.component.html":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/patients/patient-create/patient-create.component.html ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"box-right\">\n  <h2>Add New Patient Details</h2>\n</div>\n<form [formGroup]=\"myform\"\n    (submit)=\"onSubmit()\"\n      novalidate>\n      <div class=\"form-group\">\n        <label for=\"inputPuid\" class=\"req\">Patient ID</label>\n        <input type=\"text\"\n               class=\"form-control\"\n               id=\"inputPuid\"\n               placeholder=\"Specify Patient ID\"\n               name=\"inputPuid\"\n               formControlName='inputPuid'\n                >\n      <app-show-errors [control]=\"myform.controls.inputPuid\"></app-show-errors>\n    </div>\n    <div class=\"form-group\">\n      <label for=\"inputFname\" class=\"req\">FirstName</label>\n      <input type=\"text\"\n             class=\"form-control\"\n             id=\"inputFname\"\n             placeholder=\"Specify FirstName\"\n             name=\"inputFname\"\n             formControlName='inputFname'\n              >\n    <app-show-errors [control]=\"myform.controls.inputFname\"></app-show-errors>\n  </div>\n  <div class=\"form-group\">\n    <label for=\"inputLname\" class=\"req\">LastName</label>\n    <input type=\"text\"\n           class=\"form-control\"\n           id=\"inputLname\"\n           placeholder=\"Specify LastName\"\n           name=\"inputLname\"\n           formControlName='inputLname'\n            >\n  <app-show-errors [control]=\"myform.controls.inputLname\"></app-show-errors>\n  </div>\n\n  <div class=\"form-group\">\n    <label for=\"inputAid\" class=\"req\">Person Unique ID</label>\n    <input type=\"text\"\n           class=\"form-control\"\n           id=\"inputAid\"\n           placeholder=\"Specify Person Unique ID\"\n           name=\"inputAid\"\n           formControlName='inputAid'\n            >\n  <app-show-errors [control]=\"myform.controls.inputAid\"></app-show-errors>\n</div>\n\n  <div class=\"form-group\">\n    <label for=\"inputPhone\" class=\"req\">Mobile Number</label>\n    <input type=\"text\"\n           class=\"form-control\"\n           id=\"inputPhone\"\n           placeholder=\"Specify Mobile Number\"\n           name=\"inputPhone\"\n           formControlName='inputPhone'\n            >\n    <app-show-errors [control]=\"myform.controls.inputPhone\"></app-show-errors>\n  </div>\n  <div class=\"form-group\">\n    <label for=\"inputEmail\" class=\"req\">Email ID</label>\n    <input type=\"text\"\n           class=\"form-control\"\n           id=\"inputEmail\"\n           placeholder=\"Specify Email ID\"\n           name=\"inputEmail\"\n           formControlName='inputEmail'\n            >\n  <app-show-errors [control]=\"myform.controls.inputEmail\"></app-show-errors>\n  </div>\n  <div class=\"form-group\">\n    <label for=\"inputAge\" class=\"req\">Age</label>\n    <input type=\"text\"\n           class=\"form-control\"\n           id=\"inputAge\"\n           placeholder=\"Specify Age\"\n           name=\"inputAge\"\n           formControlName='inputAge'\n            >\n    <app-show-errors [control]=\"myform.controls.inputAge\"></app-show-errors>\n  </div>\n  <div class=\"form-group\">\n    <label for=\"inputGender\" class=\"req\"> Gender</label>\n    <select class=\"form-control\"\n                id=\"inputGender\"\n                name=\"inputGender\"\n                formControlName=\"inputGender\"\n                >\n\n              <option value=\"0\">Male</option>\n              <option value=\"1\">Female</option>\n\n\n         </select>\n    <app-show-errors [control]=\"myform.controls.inputGender\"></app-show-errors>\n  </div>\n  <div class=\"form-group\">\n    <label for=\"inputAddress\" class=\"req\">Address</label>\n    <input type=\"text\"\n           class=\"form-control\"\n           id=\"inputAddress\"\n           placeholder=\"Specify Address\"\n           name=\"inputAddress\"\n           formControlName='inputAddress'\n            >\n    <app-show-errors [control]=\"myform.controls.inputAddress\"></app-show-errors>\n  </div>\n  <button type=\"submit\" [disabled]=\"myform.invalid\" class=\"btn btn-primary btn-space\">Submit Form</button>\n  <button type=\"reset\" class=\"btn btn-primary\">Reset</button>\n</form>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/patients/patient-details/patient-details.component.html":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/patients/patient-details/patient-details.component.html ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h2>PATIENT DETAIL</h2><br/>\n\t\t  <div class=\"col-md-7\" >\n\t\t\t\t<table class=\"table table-bordered table-striped table-hover\" *ngIf=\"isLoading==false\">\n\t\t\t\t\t<tr>\n            <th>patient ID</th>\n            <th>First Name</th>\n            <th>Last Name</th>\n            <th>Adhar ID</th>\n             <th>Mobile Number</th>\n            <th>Email-ID</th>\n            <th>Age</th>\n            <th>Gender</th>\n            <th>Address</th>\n\n\n\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr>\n                        <td>{{patientdetails.inputPuid}}</td>\n                        <td>{{patientdetails.inputFname}}</td>\n                        <td>{{patientdetails.inputLname}}</td>\n                        <td>{{patientdetails.inputAid}}</td>\n                        <td>{{patientdetails.inputPhone}}</td>\n                        <td>{{patientdetails.inputEmail}}</td>\n                        <td>{{patientdetails.inputAge}}</td>\n                        <td>{{patientdetails.inputGender === '0' ? 'Male' : 'Female'}}</td>\n                        <td>{{patientdetails.inputAddress}}</td>\n              </tr>\n        </table>\n\n      </div>\n\n\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/patients/patient-list/patient-list.component.html":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/patients/patient-list/patient-list.component.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h2>COMPLETE PATIENT LIST</h2><br/>\n\t\t  <div class=\"col-md-7\" >\n\t\t\t\t<table class=\"table table-bordered table-striped table-hover\" *ngIf=\"PatientList.length>=1\">\n\t\t\t\t\t<tr>\n            <th>patient ID</th>\n            <th>First Name</th>\n            <th>Last Name</th>\n            <th>Adhar ID</th>\n             <th>Mobile Number</th>\n            <th>Email-ID</th>\n            <th>Age</th>\n            <th>Gender</th>\n            <th>Address</th>\n\n\n            <th>Action</th>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr *ngFor=\"let eachdata of PatientList\">\n                        <td>{{eachdata.inputPuid}}</td>\n                        <td>{{eachdata.inputFname}}</td>\n                        <td>{{eachdata.inputLname}}</td>\n                        <td>{{eachdata.inputAid}}</td>\n                        <td>{{eachdata.inputPhone}}</td>\n                        <td>{{eachdata.inputEmail}}</td>\n                        <td>{{eachdata.inputAge}}</td>\n                        <td>{{eachdata.inputGender === '0' ? 'Male' : 'Female'}}</td>\n                        <td>{{eachdata.inputAddress}}</td>\n\n                        <td>\n                           <!-- <button class=\"btn btn-primary btn-space\" routerLink=\"/patientdetails/{{eachdata._id}}\"><i class=\"fa fa-eye\"></i> View</button>-->\n                           <button class=\"btn btn-danger btn-space\" (click)=\"deletePatient(eachdata._id)\"><i class=\"fa fa-eye\"></i> Delete</button>\n\n\n\n                        </td>\n              </tr>\n        </table>\n        <h4 *ngIf=\"PatientList.length<1\" >Sorry No Patient Exists</h4>\n      </div>\n\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/precords/precord-create/precord-create.component.html":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/precords/precord-create/precord-create.component.html ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n\n<form (submit)=\"onSearch()\"\n[formGroup]=\"myform\"\nnovalidate>\n  <div class=\"form-group\">\n    <label for=\"inputPuid\" class=\"req\">Enter Patient ID/Adhar ID</label>\n    <input type=\"text\"\n           class=\"form-control\"\n           id=\"inputPuid\"\n           placeholder=\"Specify Patient ID/Adhar ID\"\n           name=\"inputPuid\"\n           formControlName='inputPuid'\n            >\n  <!--<app-show-errors [control]=\"myform.controls.inputPuid\"></app-show-errors>-->\n</div>\n<button type=\"submit\" [disabled]=\"myform.invalid\" class=\"btn btn-primary btn-space\">Search</button>\n</form>\n\n<div *ngIf=\"patient_data!=null\">\n  <h2>Patient Details</h2><br/>\n\n\n\n  <table class=\"table table-bordered table-striped table-hover\" >\n    <tr>\n      <th>Patient UID</th>\n      <th>First Name</th>\n      <th>Last Name</th>\n      <th>Mobile Number</th>\n      <th>Gender</th>\n    </tr>\n    <tr>\n      <td>{{patient_data.inputPuid}}</td>\n      <td>{{patient_data.inputFname}}</td>\n      <td>{{patient_data.inputLname}}</td>\n      <td>{{patient_data.inputPhone}}</td>\n      <td>{{patient_data.inputGender==0?'Male':'Female'}}</td>\n\n    </tr>\n    </table>\n</div>\n\n<div *ngIf=\"patient_data!=null\">\n  <h2>Add Patient Records </h2><br />\n\n  <form (submit)=\"onFormSubmit()\"\n  [formGroup]=\"myform1\"\n  novalidate>\n    <div class=\"form-group\">\n      <label for=\"inputChospital\" class=\"req\">Consulted Hospital/Diagnostic Center Name</label>\n      <input type=\"text\" class=\"form-control\" id=\"inputChospital\" placeholder=\"Specify Consulted Hospital Name\"\n        name=\"inputChospital\" formControlName='inputChospital'>\n\n    </div>\n    <div class=\"form-group\">\n      <label for=\"inputCdoctor\" class=\"req\">Consulted Doctors Name</label>\n      <input type=\"text\" class=\"form-control\" id=\"inputCdoctor\" placeholder=\"Specify Consulted Doctors Name\"\n        name=\"inputCdoctor\" formControlName='inputCdoctor'>\n\n    </div>\n\n    <div class=\"form-group\">\n      <label for=\"inputDescription\" class=\"req\">Description</label>\n      <textarea type=\"text\" class=\"form-control\" id=\"inputDescription\" placeholder=\"Specify Description\"\n        name=\"inputDescription\" formControlName='inputDescription'></textarea>\n\n    </div>\n    <div>\n      <button type=\"button\"  class=\"btn btn-primary btn-space\" (click)=\"uploadfile.click()\">Upload File</button>\n      <input type=\"file\" style=\"visibility:hidden\" #uploadfile (change)=\"fileChangeEvent($event)\" multiple>\n    </div>\n\n    <button type=\"submit\" [disabled]=\"myform1.invalid\" class=\"btn btn-primary btn-space\">Submit</button>\n  </form>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/precords/spec-prerecord-create/spec-prerecord-create.component.html":
/*!***************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/precords/spec-prerecord-create/spec-prerecord-create.component.html ***!
  \***************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>\n  SPECIALIST RECORDS SECTION\n</p>\n\n\n<form (submit)=\"onSearch()\"\n[formGroup]=\"myform\"\nnovalidate>\n  <div class=\"form-group\">\n    <label for=\"inputPuid\" class=\"req\">Enter Patient ID/Adhar ID</label>\n    <input type=\"text\"\n           class=\"form-control\"\n           id=\"inputPuid\"\n           placeholder=\"Specify Patient ID/Adhar ID\"\n           name=\"inputPuid\"\n           formControlName='inputPuid'\n            >\n  <!--<app-show-errors [control]=\"myform.controls.inputPuid\"></app-show-errors>-->\n</div>\n<button type=\"submit\" [disabled]=\"myform.invalid\" class=\"btn btn-primary btn-space\">Search</button>\n</form>\n\n<div *ngIf=\"patient_data!=null\">\n  <h2>Patient Details</h2><br/>\n\n\n\n  <table class=\"table table-bordered table-striped table-hover\" >\n    <tr>\n      <th>Patient UID</th>\n      <th>First Name</th>\n      <th>Last Name</th>\n      <th>Mobile Number</th>\n      <th>Gender</th>\n    </tr>\n    <tr>\n      <td>{{patient_data.inputPuid}}</td>\n      <td>{{patient_data.inputFname}}</td>\n      <td>{{patient_data.inputLname}}</td>\n      <td>{{patient_data.inputPhone}}</td>\n      <td>{{patient_data.inputGender==0?'Male':'Female'}}</td>\n\n    </tr>\n    </table>\n</div>\n\n<div *ngIf=\"patient_data!=null\">\n  <h2>Add Patient Records </h2><br />\n\n  <form (submit)=\"onFormSubmit()\"\n  [formGroup]=\"myform1\"\n  novalidate>\n    <div class=\"form-group\">\n      <label for=\"inputChospital\" class=\"req\">Consulted Hospital/Diagnostic Center Name</label>\n      <input type=\"text\" class=\"form-control\" id=\"inputChospital\" placeholder=\"Specify Consulted Hospital Name\"\n        name=\"inputChospital\" formControlName='inputChospital'>\n\n    </div>\n    <div class=\"form-group\">\n      <label for=\"inputCdoctor\" class=\"req\">Consulted Doctors Name</label>\n      <input type=\"text\" class=\"form-control\" id=\"inputCdoctor\" placeholder=\"Specify Consulted Doctors Name\"\n        name=\"inputCdoctor\" formControlName='inputCdoctor'>\n\n    </div>\n\n    <div class=\"form-group\">\n      <label for=\"inputDescription\" class=\"req\">Description</label>\n      <textarea type=\"text\" class=\"form-control\" id=\"inputDescription\" placeholder=\"Specify Description\"\n        name=\"inputDescription\" formControlName='inputDescription'></textarea>\n\n    </div>\n    <div>\n      <button type=\"button\"  class=\"btn btn-primary btn-space\" (click)=\"uploadfile.click()\">Upload File</button>\n      <input type=\"file\" style=\"visibility:hidden\" #uploadfile (change)=\"fileChangeEvent($event)\" multiple>\n    </div>\n\n    <button type=\"submit\" [disabled]=\"myform1.invalid\" class=\"btn btn-primary btn-space\">Submit</button>\n  </form>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/receptionists/receptionist-create/receptionist-create.component.html":
/*!****************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/receptionists/receptionist-create/receptionist-create.component.html ***!
  \****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"box-right\">\n  <h2>Add New Receptionist</h2>\n</div>\n\n<form [formGroup]=\"myform\"\n(submit)=\"onSubmit()\"\n  novalidate>\n  <div class=\"form-group\">\n    <label for=\"inputFname\" class=\"req\">FirstName</label>\n    <input type=\"text\"\n           class=\"form-control\"\n           id=\"inputFname\"\n           placeholder=\"Specify FirstName\"\n           name=\"inputFname\"\n           formControlName='inputFname'\n            >\n  <app-show-errors [control]=\"myform.controls.inputFname\"></app-show-errors>\n</div>\n<div class=\"form-group\">\n  <label for=\"inputLname\" class=\"req\">LastName</label>\n  <input type=\"text\"\n         class=\"form-control\"\n         id=\"inputLname\"\n         placeholder=\"Specify LastName\"\n         name=\"inputLname\"\n         formControlName='inputLname'\n          >\n<app-show-errors [control]=\"myform.controls.inputLname\"></app-show-errors>\n</div>\n<div class=\"form-group\">\n    <label for=\"inputEmail\" class=\"req\">Email ID</label>\n    <input type=\"text\"\n           class=\"form-control\"\n           id=\"inputEmail\"\n           placeholder=\"Specify Email ID\"\n           name=\"inputEmail\"\n           formControlName='inputEmail'\n            >\n    <app-show-errors [control]=\"myform.controls.inputEmail\"></app-show-errors>\n  </div>\n<div class=\"form-group\">\n<label for=\"inputPass\" class=\"req\">Password</label>\n<input type=\"password\"\n       class=\"form-control\"\n       id=\"inputPass\"\n       placeholder=\"Specify Password\"\n       name=\"inputPass\"\n       formControlName='inputPass'\n        >\n<app-show-errors [control]=\"myform.controls.inputPass\"></app-show-errors>\n</div>\n\n<div class=\"form-group\">\n  <label for=\"inputPhone\" class=\"req\">Mobile-No</label>\n  <input type=\"text\"\n         class=\"form-control\"\n         id=\"inputPhone\"\n         placeholder=\"Specify Mobile-No\"\n         name=\"inputPhone\"\n         formControlName='inputPhone'\n          >\n  <app-show-errors [control]=\"myform.controls.inputPhone\"></app-show-errors>\n  </div>\n\n\n<div class=\"form-group\">\n  <label for=\"inputAddress\" class=\"req\">Address</label>\n  <input type=\"text\"\n         class=\"form-control\"\n         id=\"inputAddress\"\n         placeholder=\"Specify Address\"\n         name=\"inputAddress\"\n         formControlName='inputAddress'\n          >\n  <app-show-errors [control]=\"myform.controls.inputAddress\"></app-show-errors>\n</div>\n<button type=\"submit\" [disabled]=\"myform.invalid\" class=\"btn btn-primary btn-space\">Submit Form</button>\n<button type=\"reset\" class=\"btn btn-primary\">Reset</button>\n\n</form>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/receptionists/receptionist-list/receptionist-list.component.html":
/*!************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/receptionists/receptionist-list/receptionist-list.component.html ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h2>COMPLETE RECEPTIONIST LIST</h2><br/>\n\t\t  <div class=\"col-md-7\" >\n\t\t\t\t<table class=\"table table-bordered table-striped table-hover\" *ngIf=\"ReceptionistList.length>=1\">\n\t\t\t\t\t<tr>\n\n            <th>First Name</th>\n            <th>Last Name</th>\n\n            <th>Email-ID</th>\n            <th>Mobile Number</th>\n            <th>Address</th>\n\n\n            <th>Action</th>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr *ngFor=\"let eachdata of ReceptionistList\">\n\n                        <td>{{eachdata.inputFname}}</td>\n                        <td>{{eachdata.inputLname}}</td>\n\n                        <td>{{eachdata.inputEmail}}</td>\n                        <td>{{eachdata.inputPhone}}</td>\n                        <td>{{eachdata.inputAddress}}</td>\n\n\n                        <td>\n                           <button class=\"btn btn-danger btn-space\" (click)=\"deleteReceptionist(eachdata._id)\"><i class=\"fa fa-eye\"></i> Delete</button>\n\t\t\t\t\t\t\t\t\t\t\t\t</td>\n              </tr>\n        </table>\n        <h4 *ngIf=\"ReceptionistList.length<1\" >Sorry No Receptionist Exists</h4>\n      </div>\n\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/slides/slides.component.html":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/slides/slides.component.html ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<div id=\"myCarousel\" class=\"carousel slide\" data-interval=\"3000\" data-ride=\"carousel\">\n\n      <ol class=\"carousel-indicators\">\n          <li data-target=\"#myCarousel\" data-slide-to=\"0\" class=\"active\"></li>\n          <li data-target=\"#myCarousel\" data-slide-to=\"1\"></li>\n          <li data-target=\"#myCarousel\" data-slide-to=\"2\"></li>\n\n      </ol>\n\n      <div class=\"carousel-inner\">\n          <div class=\"active item\">\n               <img src=\"assets/images/image1.jpg\">\n               <div class=\"carousel-caption\">\n                  <h3>Doctor Patient Confidentiality</h3>\n                  <p>The doctor–patient relationship is a central part of health care and the practice of medicine.</p>\n                </div>\n          </div>\n          <div class=\"item\">\n              <img src=\"assets/images/image2.jpg\">\n              <div class=\"carousel-caption\">\n                  <h3>Protect Patient Information</h3>\n                  <p>Protecting the Privacy and Security of Your Health Information</p>\n                </div>\n          </div>\n          <div class=\"item\">\n             <img src=\"assets/images/image3.jpg\">\n             <div class=\"carousel-caption\">\n                <h3>Storage Of Medical Records</h3>\n                <p>Enhanced Patient Care With Medical Records Management.</p>\n              </div>\n          </div>\n      </div>\n\n      <a class=\"carousel-control left\" href=\"#myCarousel\" data-slide=\"prev\">\n          <span class=\"glyphicon glyphicon-chevron-left\"></span>\n      </a>\n      <a class=\"carousel-control right\" href=\"#myCarousel\" data-slide=\"next\">\n          <span class=\"glyphicon glyphicon-chevron-right\"></span>\n      </a>\n</div>\n\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/specialists/specialist-create/specialist-create.component.html":
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/specialists/specialist-create/specialist-create.component.html ***!
  \**********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"box-right\">\n    <h2>Add New Specialist Details</h2>\n  </div>\n  <form [formGroup]=\"myform\"\n  (submit)=\"onSubmit()\"\n  novalidate>\n      <div class=\"form-group\">\n          <label for=\"inputFname\" class=\"req\">FirstName</label>\n          <input type=\"text\"\n                 class=\"form-control\"\n                 id=\"inputFname\"\n                 placeholder=\"Specify FirstName\"\n                 name=\"inputFname\"\n                 formControlName='inputFname'\n                  >\n        <app-show-errors [control]=\"myform.controls.inputFname\"></app-show-errors>\n      </div>\n      <div class=\"form-group\">\n        <label for=\"inputLname\" class=\"req\">LastName</label>\n        <input type=\"text\"\n               class=\"form-control\"\n               id=\"inputLname\"\n               placeholder=\"Specify LastName\"\n               name=\"inputLname\"\n               formControlName='inputLname'\n                >\n      <app-show-errors [control]=\"myform.controls.inputLname\"></app-show-errors>\n      </div>\n      <div class=\"form-group\">\n          <label for=\"inputUname\" class=\"req\">UserName</label>\n          <input type=\"text\"\n                 class=\"form-control\"\n                 id=\"inputUname\"\n                 placeholder=\"Specify UserName\"\n                 name=\"inputUname\"\n                 formControlName='inputUname'\n                  >\n        <app-show-errors [control]=\"myform.controls.inputUname\"></app-show-errors>\n        </div>\n        <div class=\"form-group\">\n            <label for=\"inputPass\" class=\"req\">Password</label>\n            <input type=\"password\"\n                   class=\"form-control\"\n                   id=\"inputPass\"\n                   placeholder=\"Specify Password\"\n                   name=\"inputPass\"\n                   formControlName='inputPass'\n                    >\n            <app-show-errors [control]=\"myform.controls.inputPass\"></app-show-errors>\n            </div>\n      <div class=\"form-group\">\n        <label for=\"inputPhone\" class=\"req\">Mobile Number</label>\n        <input type=\"text\"\n               class=\"form-control\"\n               id=\"inputPhone\"\n               placeholder=\"Specify Mobile Number\"\n               name=\"inputPhone\"\n               formControlName='inputPhone'\n                >\n        <app-show-errors [control]=\"myform.controls.inputPhone\"></app-show-errors>\n      </div>\n      <div class=\"form-group\">\n        <label for=\"inputEmail\" class=\"req\">Email ID</label>\n        <input type=\"text\"\n               class=\"form-control\"\n               id=\"inputEmail\"\n               placeholder=\"Specify Email ID\"\n               name=\"inputEmail\"\n               formControlName='inputEmail'\n                >\n        <app-show-errors [control]=\"myform.controls.inputEmail\"></app-show-errors>\n      </div>\n\n      <div class=\"form-group\">\n          <label for=\"inputGender\" class=\"req\"> Gender</label>\n          <select class=\"form-control\"\n                      id=\"inputGender\"\n                      name=\"inputGender\"\n                      formControlName=\"inputGender\"\n                      >\n\n                    <option value=\"0\">Male</option>\n                    <option value=\"1\">Female</option>\n\n\n               </select>\n          <app-show-errors [control]=\"myform.controls.inputGender\"></app-show-errors>\n        </div>\n\n        <div class=\"form-group\">\n            <label for=\"inputStype\" class=\"req\"> Specialist Type</label>\n            <select class=\"form-control\"\n                        id=\"inputStype\"\n                        name=\"inputStype\"\n                        formControlName=\"inputStype\"\n                        >\n\n                        <option *ngFor=\"let stype of slist\" value=\"{{stype._id}}\">{{stype.stype}}</option>\n\n\n\n                 </select>\n            <app-show-errors [control]=\"myform.controls.inputStype\"></app-show-errors>\n          </div>\n\n        <div class=\"form-group\">\n            <label for=\"inputQualification\" class=\"req\">Qualification</label>\n            <input type=\"text\"\n                   class=\"form-control\"\n                   id=\"inputQualification\"\n                   placeholder=\"Specify Qualification\"\n                   name=\"inputQualification\"\n                   formControlName='inputQualification'\n                    >\n            <app-show-errors [control]=\"myform.controls.inputQualification\"></app-show-errors>\n          </div>\n          <div class=\"form-group\">\n            <label for=\"inputMap\">Mark The Location Of Hospital</label>\n            <google-map \n               height=\"400px\" \n               width=\"100%\" \n               [zoom]=\"zoom\"\n               [center]=\"center\"\n               [options]=\"options\"\n               (mapClick)=\"click($event)\">\n               <map-marker\n                *ngFor=\"let marker of markers\"\n                [position]=\"marker.position\"\n                [title]=\"marker.title\"\n                [options]=\"marker.options\"\n              >\n              </map-marker>\n              </google-map>\n          </div>\n          <div class=\"form-group\">\n            <label for=\"inputLatitude\">Latitude</label>\n            <input type=\"text\" formControlName='inputLatitude' class=\"form-control\" id=\"inputLatitude\" >\n          </div>\n          <div class=\"form-group\">\n            <label for=\"inputLongitude\">Longitude</label>\n            <input type=\"text\" formControlName='inputLongitude' class=\"form-control\" id=\"inputLongitude\" >\n          </div>\n          <button type=\"submit\" [disabled]=\"myform.invalid\" class=\"btn btn-primary btn-space\">Submit Form</button>\n          <button type=\"reset\" class=\"btn btn-primary\">Reset</button>\n  </form>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/specialists/specialist-list/specialist-list.component.html":
/*!******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/specialists/specialist-list/specialist-list.component.html ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h2>COMPLETE SPECIALIST LIST</h2><br/>\n\t\t  <div class=\"col-md-7\" >\n\t\t\t\t<table class=\"table table-bordered table-striped table-hover\" *ngIf=\"SpecialisttList.length>=1\">\n\t\t\t\t\t<tr>\n\n            <th>First Name</th>\n            <th>Last Name</th>\n            <th>Mobile Number</th>\n            <th>Email-ID</th>\n          \n            <th>Qualification</th>\n\n\n            <th>Action</th>\n\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr *ngFor=\"let eachdata of SpecialisttList\">\n\n                        <td>{{eachdata.inputFname}}</td>\n                        <td>{{eachdata.inputLname}}</td>\n                        <td>{{eachdata.inputPhone}}</td>\n                        <td>{{eachdata.inputEmail}}</td>\n                       <!--<td>{{eachdata.inputGender == '0' ? 'Male' : 'Female'}}</td>\n                        <td>{{eachdata.inputStype}}</td>--> \n                        <td>{{eachdata.inputQualification}}</td>\n\n\n                        <td>\n                           <button class=\"btn btn-danger btn-space\" (click)=\"deleteSpecialist(eachdata._id)\"><i class=\"fa fa-eye\"></i> Delete</button>\n\n                        </td>\n\n              </tr>\n        </table>\n        <h4 *ngIf=\"SpecialisttList.length<1\" >Sorry No Receptionist Exists</h4>\n      </div>\n\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/top-menus/top-menus.component.html":
/*!******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/top-menus/top-menus.component.html ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>\n  top-menus works!\n</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/top-navigation/top-navigation.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/top-navigation/top-navigation.component.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"navigation\">\n  <div class=\"container\">\n    <ul class='sf-menu'>\n        <li ><a routerLink=\"\">Home</a></li>\n        <li ><a routerLink=\"/about-project\">About Project</a></li>\n        <li><a routerLink=\"/about-us\">About Us</a></li>\n        <li><a routerLink=\"/contact-us\">Contact Us</a></li>\n        <li><a routerLink=\"/mapview\">Map View</a></li>\n        <li *ngIf=\"!isAuthenticated\"><a routerLink=\"/login\">Login</a></li>\n        <li *ngIf=\"isAuthenticated\"><a href=\"\" (click)=\"onLogout()\">Logout</a></li>\n    </ul>\n  </div>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/users/user-create/user-create.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/users/user-create/user-create.component.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"box-right\">\n  <h2>Add New Users</h2>\n</div>\n<form [formGroup]=\"myform\"\n(submit)=\"onSubmit()\"\n  novalidate >\n    <div class=\"form-group\">\n        <label for=\"inputFname\" class=\"req\">FirstName</label>\n        <input type=\"text\"\n               class=\"form-control\"\n               id=\"inputFname\"\n               placeholder=\"Specify FirstName\"\n               name=\"inputFname\"\n               formControlName=\"inputFname\"\n                >\n      <!--<app-show-errors [control]=\"myform.controls.inputPuid\"></app-show-errors>-->\n    </div>\n    <div class=\"form-group\">\n      <label for=\"inputLname\" class=\"req\">LastName</label>\n      <input type=\"text\"\n             class=\"form-control\"\n             id=\"inputLname\"\n             placeholder=\"Specify LastName\"\n             name=\"inputLname\"\n             formControlName=\"inputLname\"\n              >\n    <!--<app-show-errors [control]=\"myform.controls.inputPuid\"></app-show-errors>-->\n    </div>\n    <div class=\"form-group\">\n        <label for=\"inputEmail\" class=\"req\">Email ID</label>\n        <input type=\"text\"\n               class=\"form-control\"\n               id=\"inputEmail\"\n               placeholder=\"Specify Email ID\"\n               name=\"inputEmail\"\n               formControlName=\"inputEmail\"\n                >\n        <!--<app-show-errors [control]=\"myform.controls.inputEmail\"></app-show-errors>-->\n      </div>\n      <div class=\"form-group\">\n        <label for=\"inputUname\" class=\"req\">Username</label>\n        <input type=\"text\" class=\"form-control\" id=\"inputUname\" placeholder=\"Specify Username\" name=\"inputPass\"\n          formControlName=\"inputUname\">\n        <!--<app-show-errors [control]=\"myform.controls.inputPuid\"></app-show-errors>-->\n      </div>\n  <div class=\"form-group\">\n    <label for=\"inputPass\" class=\"req\">Password</label>\n    <input type=\"password\"\n           class=\"form-control\"\n           id=\"inputPass\"\n           placeholder=\"Specify Password\"\n           name=\"inputPass\"\n           formControlName=\"inputPass\"\n            >\n  <!--<app-show-errors [control]=\"myform.controls.inputPuid\"></app-show-errors>-->\n  </div>\n<button type=\"submit\" [disabled]=\"myform.invalid\" class=\"btn btn-primary btn-space\">Submit Form</button>\n<button type=\"reset\" class=\"btn btn-primary\">Reset</button>\n</form>\n");

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _patients_patient_create_patient_create_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./patients/patient-create/patient-create.component */ "./src/app/patients/patient-create/patient-create.component.ts");
/* harmony import */ var _users_user_create_user_create_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./users/user-create/user-create.component */ "./src/app/users/user-create/user-create.component.ts");
/* harmony import */ var _receptionists_receptionist_create_receptionist_create_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./receptionists/receptionist-create/receptionist-create.component */ "./src/app/receptionists/receptionist-create/receptionist-create.component.ts");
/* harmony import */ var _precords_precord_create_precord_create_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./precords/precord-create/precord-create.component */ "./src/app/precords/precord-create/precord-create.component.ts");
/* harmony import */ var _doctors_doctor_create_doctor_create_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./doctors/doctor-create/doctor-create.component */ "./src/app/doctors/doctor-create/doctor-create.component.ts");
/* harmony import */ var _specialists_specialist_create_specialist_create_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./specialists/specialist-create/specialist-create.component */ "./src/app/specialists/specialist-create/specialist-create.component.ts");
/* harmony import */ var _doctors_doctor_list_doctor_list_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./doctors/doctor-list/doctor-list.component */ "./src/app/doctors/doctor-list/doctor-list.component.ts");
/* harmony import */ var _patients_patient_list_patient_list_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./patients/patient-list/patient-list.component */ "./src/app/patients/patient-list/patient-list.component.ts");
/* harmony import */ var _receptionists_receptionist_list_receptionist_list_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./receptionists/receptionist-list/receptionist-list.component */ "./src/app/receptionists/receptionist-list/receptionist-list.component.ts");
/* harmony import */ var _specialists_specialist_list_specialist_list_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./specialists/specialist-list/specialist-list.component */ "./src/app/specialists/specialist-list/specialist-list.component.ts");
/* harmony import */ var _patients_patient_details_patient_details_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./patients/patient-details/patient-details.component */ "./src/app/patients/patient-details/patient-details.component.ts");
/* harmony import */ var _auth_login_login_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./auth/login/login.component */ "./src/app/auth/login/login.component.ts");
/* harmony import */ var _precords_spec_prerecord_create_spec_prerecord_create_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./precords/spec-prerecord-create/spec-prerecord-create.component */ "./src/app/precords/spec-prerecord-create/spec-prerecord-create.component.ts");
/* harmony import */ var _patients_doctor_patient_list_doctor_patient_list_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./patients/doctor-patient-list/doctor-patient-list.component */ "./src/app/patients/doctor-patient-list/doctor-patient-list.component.ts");
/* harmony import */ var _doctors_pages_about_project_about_project_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./doctors/pages/about-project/about-project.component */ "./src/app/doctors/pages/about-project/about-project.component.ts");
/* harmony import */ var _doctors_pages_about_us_about_us_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./doctors/pages/about-us/about-us.component */ "./src/app/doctors/pages/about-us/about-us.component.ts");
/* harmony import */ var _doctors_pages_contact_us_contact_us_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./doctors/pages/contact-us/contact-us.component */ "./src/app/doctors/pages/contact-us/contact-us.component.ts");
/* harmony import */ var _doctors_pages_mapview_mapview_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./doctors/pages/mapview/mapview.component */ "./src/app/doctors/pages/mapview/mapview.component.ts");





















var routes = [
    { path: 'patients', component: _patients_patient_create_patient_create_component__WEBPACK_IMPORTED_MODULE_3__["PatientCreateComponent"] },
    { path: 'users', component: _users_user_create_user_create_component__WEBPACK_IMPORTED_MODULE_4__["UserCreateComponent"] },
    { path: 'receptionists', component: _receptionists_receptionist_create_receptionist_create_component__WEBPACK_IMPORTED_MODULE_5__["ReceptionistCreateComponent"] },
    { path: 'precords', component: _precords_precord_create_precord_create_component__WEBPACK_IMPORTED_MODULE_6__["PrecordCreateComponent"] },
    { path: 'doctors', component: _doctors_doctor_create_doctor_create_component__WEBPACK_IMPORTED_MODULE_7__["DoctorCreateComponent"] },
    { path: 'specialists', component: _specialists_specialist_create_specialist_create_component__WEBPACK_IMPORTED_MODULE_8__["SpecialistCreateComponent"] },
    { path: 'doctors-list', component: _doctors_doctor_list_doctor_list_component__WEBPACK_IMPORTED_MODULE_9__["DoctorListComponent"] },
    { path: 'patients-list', component: _patients_patient_list_patient_list_component__WEBPACK_IMPORTED_MODULE_10__["PatientListComponent"] },
    { path: 'receptionists-list', component: _receptionists_receptionist_list_receptionist_list_component__WEBPACK_IMPORTED_MODULE_11__["ReceptionistListComponent"] },
    { path: 'specialists-list', component: _specialists_specialist_list_specialist_list_component__WEBPACK_IMPORTED_MODULE_12__["SpecialistListComponent"] },
    { path: 'patientdetails/:pid', component: _patients_patient_details_patient_details_component__WEBPACK_IMPORTED_MODULE_13__["PatientDetailsComponent"] },
    { path: 'login', component: _auth_login_login_component__WEBPACK_IMPORTED_MODULE_14__["LoginComponent"] },
    { path: 'specialist-precords', component: _precords_spec_prerecord_create_spec_prerecord_create_component__WEBPACK_IMPORTED_MODULE_15__["SpecPrerecordCreateComponent"] },
    { path: 'doctor-patient-list', component: _patients_doctor_patient_list_doctor_patient_list_component__WEBPACK_IMPORTED_MODULE_16__["DoctorPatientListComponent"] },
    { path: 'about-project', component: _doctors_pages_about_project_about_project_component__WEBPACK_IMPORTED_MODULE_17__["AboutProjectComponent"] },
    { path: 'about-us', component: _doctors_pages_about_us_about_us_component__WEBPACK_IMPORTED_MODULE_18__["AboutUsComponent"] },
    { path: 'mapview', component: _doctors_pages_mapview_mapview_component__WEBPACK_IMPORTED_MODULE_20__["MapviewComponent"] },
    { path: 'contact-us', component: _doctors_pages_contact_us_contact_us_component__WEBPACK_IMPORTED_MODULE_19__["ContactUsComponent"] }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./auth/auth.service */ "./src/app/auth/auth.service.ts");



var AppComponent = /** @class */ (function () {
    function AppComponent(authservice) {
        this.authservice = authservice;
        this.title = 'patientconfidentiality';
    }
    AppComponent.prototype.ngOnInit = function () {
        //this.authservice.AutoAuthUser();
    };
    AppComponent.ctorParameters = function () { return [
        { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] }
    ]; };
    AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./header/header.component */ "./src/app/header/header.component.ts");
/* harmony import */ var _header_address_address_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./header/address/address.component */ "./src/app/header/address/address.component.ts");
/* harmony import */ var _header_logo_logo_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./header/logo/logo.component */ "./src/app/header/logo/logo.component.ts");
/* harmony import */ var _top_navigation_top_navigation_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./top-navigation/top-navigation.component */ "./src/app/top-navigation/top-navigation.component.ts");
/* harmony import */ var _leftmenu_leftmenu_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./leftmenu/leftmenu.component */ "./src/app/leftmenu/leftmenu.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var _slides_slides_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./slides/slides.component */ "./src/app/slides/slides.component.ts");
/* harmony import */ var _main_content_main_content_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./main-content/main-content.component */ "./src/app/main-content/main-content.component.ts");
/* harmony import */ var _footer_footer_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./footer/footer.component */ "./src/app/footer/footer.component.ts");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! angular2-flash-messages */ "./node_modules/angular2-flash-messages/__ivy_ngcc__/module/index.js");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(angular2_flash_messages__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _patients_patient_create_patient_create_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./patients/patient-create/patient-create.component */ "./src/app/patients/patient-create/patient-create.component.ts");
/* harmony import */ var _users_user_create_user_create_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./users/user-create/user-create.component */ "./src/app/users/user-create/user-create.component.ts");
/* harmony import */ var _receptionists_receptionist_create_receptionist_create_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./receptionists/receptionist-create/receptionist-create.component */ "./src/app/receptionists/receptionist-create/receptionist-create.component.ts");
/* harmony import */ var _precords_precord_create_precord_create_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./precords/precord-create/precord-create.component */ "./src/app/precords/precord-create/precord-create.component.ts");
/* harmony import */ var _doctors_doctor_create_doctor_create_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./doctors/doctor-create/doctor-create.component */ "./src/app/doctors/doctor-create/doctor-create.component.ts");
/* harmony import */ var _specialists_specialist_create_specialist_create_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./specialists/specialist-create/specialist-create.component */ "./src/app/specialists/specialist-create/specialist-create.component.ts");
/* harmony import */ var _top_menus_top_menus_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./top-menus/top-menus.component */ "./src/app/top-menus/top-menus.component.ts");
/* harmony import */ var _errors_show_errors_show_errors_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./errors/show-errors/show-errors.component */ "./src/app/errors/show-errors/show-errors.component.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/http.js");
/* harmony import */ var _doctors_doctor_list_doctor_list_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./doctors/doctor-list/doctor-list.component */ "./src/app/doctors/doctor-list/doctor-list.component.ts");
/* harmony import */ var _patients_patient_list_patient_list_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./patients/patient-list/patient-list.component */ "./src/app/patients/patient-list/patient-list.component.ts");
/* harmony import */ var _receptionists_receptionist_list_receptionist_list_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./receptionists/receptionist-list/receptionist-list.component */ "./src/app/receptionists/receptionist-list/receptionist-list.component.ts");
/* harmony import */ var _specialists_specialist_list_specialist_list_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./specialists/specialist-list/specialist-list.component */ "./src/app/specialists/specialist-list/specialist-list.component.ts");
/* harmony import */ var _patients_patient_details_patient_details_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./patients/patient-details/patient-details.component */ "./src/app/patients/patient-details/patient-details.component.ts");
/* harmony import */ var _auth_login_login_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./auth/login/login.component */ "./src/app/auth/login/login.component.ts");
/* harmony import */ var _auth_auth_interceptor__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./auth/auth-interceptor */ "./src/app/auth/auth-interceptor.ts");
/* harmony import */ var _precords_spec_prerecord_create_spec_prerecord_create_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./precords/spec-prerecord-create/spec-prerecord-create.component */ "./src/app/precords/spec-prerecord-create/spec-prerecord-create.component.ts");
/* harmony import */ var _patients_doctor_patient_list_doctor_patient_list_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./patients/doctor-patient-list/doctor-patient-list.component */ "./src/app/patients/doctor-patient-list/doctor-patient-list.component.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/common.js");
/* harmony import */ var _doctors_pages_about_us_about_us_component__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./doctors/pages/about-us/about-us.component */ "./src/app/doctors/pages/about-us/about-us.component.ts");
/* harmony import */ var _doctors_pages_contact_us_contact_us_component__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./doctors/pages/contact-us/contact-us.component */ "./src/app/doctors/pages/contact-us/contact-us.component.ts");
/* harmony import */ var _doctors_pages_about_project_about_project_component__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./doctors/pages/about-project/about-project.component */ "./src/app/doctors/pages/about-project/about-project.component.ts");
/* harmony import */ var _angular_google_maps__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @angular/google-maps */ "./node_modules/@angular/google-maps/__ivy_ngcc__/fesm5/google-maps.js");
/* harmony import */ var _doctors_pages_mapview_mapview_component__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./doctors/pages/mapview/mapview.component */ "./src/app/doctors/pages/mapview/mapview.component.ts");







































var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"],
                _header_header_component__WEBPACK_IMPORTED_MODULE_5__["HeaderComponent"],
                _header_address_address_component__WEBPACK_IMPORTED_MODULE_6__["AddressComponent"],
                _header_logo_logo_component__WEBPACK_IMPORTED_MODULE_7__["LogoComponent"],
                _top_navigation_top_navigation_component__WEBPACK_IMPORTED_MODULE_8__["TopNavigationComponent"],
                _leftmenu_leftmenu_component__WEBPACK_IMPORTED_MODULE_9__["LeftmenuComponent"],
                _slides_slides_component__WEBPACK_IMPORTED_MODULE_11__["SlidesComponent"],
                _main_content_main_content_component__WEBPACK_IMPORTED_MODULE_12__["MainContentComponent"],
                _footer_footer_component__WEBPACK_IMPORTED_MODULE_13__["FooterComponent"],
                _patients_patient_create_patient_create_component__WEBPACK_IMPORTED_MODULE_15__["PatientCreateComponent"],
                _users_user_create_user_create_component__WEBPACK_IMPORTED_MODULE_16__["UserCreateComponent"],
                _receptionists_receptionist_create_receptionist_create_component__WEBPACK_IMPORTED_MODULE_17__["ReceptionistCreateComponent"],
                _precords_precord_create_precord_create_component__WEBPACK_IMPORTED_MODULE_18__["PrecordCreateComponent"],
                _doctors_doctor_create_doctor_create_component__WEBPACK_IMPORTED_MODULE_19__["DoctorCreateComponent"],
                _specialists_specialist_create_specialist_create_component__WEBPACK_IMPORTED_MODULE_20__["SpecialistCreateComponent"],
                _top_menus_top_menus_component__WEBPACK_IMPORTED_MODULE_21__["TopMenusComponent"],
                _errors_show_errors_show_errors_component__WEBPACK_IMPORTED_MODULE_22__["ShowErrorsComponent"],
                _doctors_doctor_list_doctor_list_component__WEBPACK_IMPORTED_MODULE_24__["DoctorListComponent"],
                _patients_patient_list_patient_list_component__WEBPACK_IMPORTED_MODULE_25__["PatientListComponent"],
                _receptionists_receptionist_list_receptionist_list_component__WEBPACK_IMPORTED_MODULE_26__["ReceptionistListComponent"],
                _specialists_specialist_list_specialist_list_component__WEBPACK_IMPORTED_MODULE_27__["SpecialistListComponent"],
                _patients_patient_details_patient_details_component__WEBPACK_IMPORTED_MODULE_28__["PatientDetailsComponent"],
                _auth_login_login_component__WEBPACK_IMPORTED_MODULE_29__["LoginComponent"],
                _precords_spec_prerecord_create_spec_prerecord_create_component__WEBPACK_IMPORTED_MODULE_31__["SpecPrerecordCreateComponent"],
                _patients_doctor_patient_list_doctor_patient_list_component__WEBPACK_IMPORTED_MODULE_32__["DoctorPatientListComponent"],
                _doctors_pages_about_us_about_us_component__WEBPACK_IMPORTED_MODULE_34__["AboutUsComponent"],
                _doctors_pages_contact_us_contact_us_component__WEBPACK_IMPORTED_MODULE_35__["ContactUsComponent"],
                _doctors_pages_about_project_about_project_component__WEBPACK_IMPORTED_MODULE_36__["AboutProjectComponent"],
                _doctors_pages_mapview_mapview_component__WEBPACK_IMPORTED_MODULE_38__["MapviewComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_3__["AppRoutingModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_10__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ReactiveFormsModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_23__["HttpClientModule"],
                _angular_google_maps__WEBPACK_IMPORTED_MODULE_37__["GoogleMapsModule"],
                angular2_flash_messages__WEBPACK_IMPORTED_MODULE_14__["FlashMessagesModule"].forRoot(),
            ],
            providers: [{ provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_23__["HTTP_INTERCEPTORS"], useClass: _auth_auth_interceptor__WEBPACK_IMPORTED_MODULE_30__["AuthInterceptor"], multi: true },
                { provide: _angular_common__WEBPACK_IMPORTED_MODULE_33__["LocationStrategy"], useClass: _angular_common__WEBPACK_IMPORTED_MODULE_33__["PathLocationStrategy"] }],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/auth/auth-interceptor.ts":
/*!******************************************!*\
  !*** ./src/app/auth/auth-interceptor.ts ***!
  \******************************************/
/*! exports provided: AuthInterceptor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthInterceptor", function() { return AuthInterceptor; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./auth.service */ "./src/app/auth/auth.service.ts");



var AuthInterceptor = /** @class */ (function () {
    function AuthInterceptor(authservice) {
        this.authservice = authservice;
    }
    AuthInterceptor.prototype.intercept = function (req, next) {
        var authToken = this.authservice.getToken();
        var authReq = req.clone({
            headers: req.headers.set('Authorization', 'Bearer ' + authToken)
        });
        //console.log(authReq);
        return next.handle(authReq);
    };
    AuthInterceptor.ctorParameters = function () { return [
        { type: _auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] }
    ]; };
    AuthInterceptor = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]])
    ], AuthInterceptor);
    return AuthInterceptor;
}());



/***/ }),

/***/ "./src/app/auth/auth.service.ts":
/*!**************************************!*\
  !*** ./src/app/auth/auth.service.ts ***!
  \**************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/http.js");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! angular2-flash-messages */ "./node_modules/angular2-flash-messages/__ivy_ngcc__/module/index.js");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");







var AuthService = /** @class */ (function () {
    function AuthService(httpc, _flashMessagesService, router) {
        this.httpc = httpc;
        this._flashMessagesService = _flashMessagesService;
        this.router = router;
        this.isAuthenticated = false;
        this.AuthStatusEmitter = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
    }
    AuthService.prototype.getAuthStatus = function () {
        return this.isAuthenticated;
    };
    AuthService.prototype.getToken = function () {
        return this.token;
    };
    AuthService.prototype.getUserId = function () {
        return this.userid;
    };
    AuthService.prototype.getAuthStatusListener = function () {
        return this.AuthStatusEmitter.asObservable();
    };
    AuthService.prototype.addnewuser = function (formdata) {
        var _this = this;
        this.httpc.post(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].url + '/users', formdata)
            .subscribe(function (result) {
            _this._flashMessagesService.show('User Added Successfully', { cssClass: 'alert-success', timeout: 5000 });
        });
    };
    AuthService.prototype.userlogin = function (username, password, ltype) {
        var _this = this;
        var authdata = {
            username: username,
            password: password,
            ltype: ltype
        };
        this.httpc.post(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].url + '/users/login', authdata)
            .subscribe(function (result) {
            console.log(result);
            _this._flashMessagesService.show('User Login Successfull', { cssClass: 'alert-success', timeout: 5000 });
            if (result) {
                _this.token = result.token;
                _this.user_role = result.user_role;
                var timervalue = result.expiresIn;
                _this.setAuthotimer(timervalue);
                _this.isAuthenticated = true;
                var current_date = new Date();
                var exp_date = new Date(current_date.getTime() + timervalue * 1000);
                _this.userid = result.userid;
                _this.saveAuthDataLocal(_this.token, exp_date, _this.userid, _this.user_role);
                _this.AuthStatusEmitter.next({
                    loginstatus: true,
                    user_role: _this.user_role
                });
                _this.router.navigate(['/']);
            }
        }, function (error) {
            _this.AuthStatusEmitter.next({
                loginstatus: false,
                user_role: -1
            });
        });
    };
    AuthService.prototype.AutoAuthUser = function () {
        var AuthLocalData = this.getAuthData();
        var now = new Date();
        if (AuthLocalData) {
            var expiresIn = AuthLocalData.expIntime.getTime() - now.getTime();
            if (expiresIn > 0) {
                this.token = AuthLocalData.token;
                this.isAuthenticated = true;
                console.log("THE IS AUTHIS " + this.isAuthenticated);
                this.user_role = parseInt(AuthLocalData.user_role);
                this.setAuthotimer(expiresIn / 1000);
                this.AuthStatusEmitter.next({
                    loginstatus: true,
                    user_role: this.user_role
                });
            }
        }
    };
    AuthService.prototype.saveAuthDataLocal = function (token, expiresInDate, userid, user_role) {
        localStorage.setItem('token', token);
        localStorage.setItem('userid', userid);
        localStorage.setItem('user_role', user_role.toString());
        localStorage.setItem('expirationDate', expiresInDate.toISOString());
    };
    AuthService.prototype.getAuthData = function () {
        var token = localStorage.getItem('token');
        var expIntime = localStorage.getItem('expirationDate');
        var userid = localStorage.getItem('userid');
        var user_role = localStorage.getItem('user_role');
        if (!token || !expIntime) {
            return;
        }
        return {
            token: token,
            expIntime: new Date(expIntime),
            userid: userid,
            user_role: user_role
        };
    };
    AuthService.prototype.clearAuthData = function () {
        localStorage.removeItem('token');
        localStorage.removeItem('userid');
        localStorage.removeItem('expirationDate');
        localStorage.removeItem('user_role');
    };
    AuthService.prototype.setAuthotimer = function (duration) {
        var _this = this;
        setTimeout(function () {
            _this.logout();
        }, duration * 1000);
    };
    AuthService.prototype.logout = function () {
        this.isAuthenticated = false;
        this.token = null;
        this.userid = null;
        this.AuthStatusEmitter.next({
            loginstatus: false,
            user_role: -1
        });
        clearTimeout(this.tokenexptimer);
        this.clearAuthData();
        this.router.navigate(['/login']);
    };
    AuthService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
        { type: angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__["FlashMessagesService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }
    ]; };
    AuthService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__["FlashMessagesService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]])
    ], AuthService);
    return AuthService;
}());



/***/ }),

/***/ "./src/app/auth/login/login.component.css":
/*!************************************************!*\
  !*** ./src/app/auth/login/login.component.css ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2F1dGgvbG9naW4vbG9naW4uY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/auth/login/login.component.ts":
/*!***********************************************!*\
  !*** ./src/app/auth/login/login.component.ts ***!
  \***********************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth/auth.service.ts");




var LoginComponent = /** @class */ (function () {
    function LoginComponent(fb, authservice) {
        this.fb = fb;
        this.authservice = authservice;
    }
    LoginComponent.prototype.ngOnInit = function () {
        this.myform = this.fb.group({
            'inputUsername': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputPassword': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputStype': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
        });
    };
    LoginComponent.prototype.onLogin = function () {
        if (this.myform.invalid) {
            return;
        }
        this.authservice.userlogin(this.myform.value.inputUsername, this.myform.value.inputPassword, this.myform.value.inputStype);
    };
    LoginComponent.ctorParameters = function () { return [
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
        { type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] }
    ]; };
    LoginComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-login',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./login.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/login/login.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./login.component.css */ "./src/app/auth/login/login.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]])
    ], LoginComponent);
    return LoginComponent;
}());



/***/ }),

/***/ "./src/app/doctors/doctor-create/doctor-create.component.css":
/*!*******************************************************************!*\
  !*** ./src/app/doctors/doctor-create/doctor-create.component.css ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("agm-map{ height: 400px;\r\n    width: 100%;\r\n    border: 1px solid #000; }\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZG9jdG9ycy9kb2N0b3ItY3JlYXRlL2RvY3Rvci1jcmVhdGUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLGFBQWE7SUFDbEIsV0FBVztJQUNYLHNCQUFzQixFQUFFIiwiZmlsZSI6InNyYy9hcHAvZG9jdG9ycy9kb2N0b3ItY3JlYXRlL2RvY3Rvci1jcmVhdGUuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbImFnbS1tYXB7IGhlaWdodDogNDAwcHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICMwMDA7IH0iXX0= */");

/***/ }),

/***/ "./src/app/doctors/doctor-create/doctor-create.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/doctors/doctor-create/doctor-create.component.ts ***!
  \******************************************************************/
/*! exports provided: DoctorCreateComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DoctorCreateComponent", function() { return DoctorCreateComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var _doctor_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../doctor.service */ "./src/app/doctors/doctor.service.ts");
/* harmony import */ var _errors_custom_validator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../errors/custom-validator */ "./src/app/errors/custom-validator.ts");
/* harmony import */ var _angular_google_maps__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/google-maps */ "./node_modules/@angular/google-maps/__ivy_ngcc__/fesm5/google-maps.js");






var DoctorCreateComponent = /** @class */ (function () {
    function DoctorCreateComponent(elementRef, fb, dservice) {
        this.elementRef = elementRef;
        this.fb = fb;
        this.dservice = dservice;
        this.markers = [];
        this.zoom = 17;
        this.options = {
            mapTypeId: 'hybrid',
            zoomControl: true,
            scrollwheel: false,
            disableDoubleClickZoom: true,
            maxZoom: 15,
            minZoom: 4,
        };
    }
    DoctorCreateComponent.prototype.addMarker = function () {
        this.markers.push({
            position: {
                lat: this.center.lat + ((Math.random() - 0.5) * 2) / 10,
                lng: this.center.lng + ((Math.random() - 0.5) * 2) / 10,
            },
            label: {
                color: 'red',
                text: 'Marker label ' + (this.markers.length + 1),
            },
            title: 'Marker title ' + (this.markers.length + 1),
            options: { animation: google.maps.Animation.BOUNCE },
        });
    };
    DoctorCreateComponent.prototype.ngOnInit = function () {
        var _this = this;
        navigator.geolocation.getCurrentPosition(function (position) {
            _this.center = {
                lat: -37.814703,
                lng: 144.965723
            };
        });
        this.myform = this.fb.group({
            'inputFname': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputLname': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(1)]),
            'inputUname': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(5)]),
            'inputPass': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(5)]),
            'inputPhone': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(10), _errors_custom_validator__WEBPACK_IMPORTED_MODULE_4__["CustomValidators"].apptelephoneNumbers]),
            'inputEmail': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email]),
            'inputGender': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputQualification': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputLatitude': this.fb.control(''),
            'inputLongitude': this.fb.control('')
        });
    };
    DoctorCreateComponent.prototype.click = function (event) {
        this.markers = [];
        console.log(event.latLng.lat().toFixed(4));
        console.log(event.latLng.lng().toFixed(4));
        this.myform.patchValue({ 'inputLatitude': event.latLng.lat().toFixed(4) });
        this.myform.get('inputLatitude').updateValueAndValidity();
        this.myform.patchValue({ 'inputLongitude': event.latLng.lng().toFixed(4) });
        this.myform.get('inputLongitude').updateValueAndValidity();
        this.markers.push({
            position: event.latLng,
            label: {
                color: 'red',
            },
            title: 'Your Location ' + (this.markers.length + 1),
            options: { animation: google.maps.Animation.BOUNCE },
        });
        //this.addMarker();
    };
    DoctorCreateComponent.prototype.onSubmit = function () {
        console.log(this.myform.value);
        this.dservice.addnewDoctor(this.myform.value);
        this.myform.reset();
    };
    DoctorCreateComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"] },
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
        { type: _doctor_service__WEBPACK_IMPORTED_MODULE_3__["DoctorService"] }
    ]; };
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_google_maps__WEBPACK_IMPORTED_MODULE_5__["GoogleMap"], { static: false }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", _angular_google_maps__WEBPACK_IMPORTED_MODULE_5__["GoogleMap"])
    ], DoctorCreateComponent.prototype, "map", void 0);
    DoctorCreateComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-doctor-create',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./doctor-create.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/doctors/doctor-create/doctor-create.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./doctor-create.component.css */ "./src/app/doctors/doctor-create/doctor-create.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _doctor_service__WEBPACK_IMPORTED_MODULE_3__["DoctorService"]])
    ], DoctorCreateComponent);
    return DoctorCreateComponent;
}());



/***/ }),

/***/ "./src/app/doctors/doctor-list/doctor-list.component.css":
/*!***************************************************************!*\
  !*** ./src/app/doctors/doctor-list/doctor-list.component.css ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2RvY3RvcnMvZG9jdG9yLWxpc3QvZG9jdG9yLWxpc3QuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/doctors/doctor-list/doctor-list.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/doctors/doctor-list/doctor-list.component.ts ***!
  \**************************************************************/
/*! exports provided: DoctorListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DoctorListComponent", function() { return DoctorListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! angular2-flash-messages */ "./node_modules/angular2-flash-messages/__ivy_ngcc__/module/index.js");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(angular2_flash_messages__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _doctor_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../doctor.service */ "./src/app/doctors/doctor.service.ts");




var DoctorListComponent = /** @class */ (function () {
    // tslint:disable-next-line:variable-name
    function DoctorListComponent(dservice, _flashMessagesService) {
        this.dservice = dservice;
        this._flashMessagesService = _flashMessagesService;
        this.DoctorList = [];
    }
    DoctorListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.dservice.getDoctorList();
        this.DListSubcriber = this.dservice.doctorListObservable()
            .subscribe(function (listdata) {
            _this.DoctorList = listdata;
        });
    };
    DoctorListComponent.prototype.deleteDoctor = function (iid) {
        var _this = this;
        if (confirm('Are You Sure Do U want to Delete Submission')) {
            this.dservice.deleteDoctor(iid)
                .subscribe(function (result) {
                _this.dservice.getDoctorList();
                _this._flashMessagesService.show('Doctor Deleted !', { cssClass: 'alert-success', timeout: 5000 });
            });
        }
    };
    DoctorListComponent.ctorParameters = function () { return [
        { type: _doctor_service__WEBPACK_IMPORTED_MODULE_3__["DoctorService"] },
        { type: angular2_flash_messages__WEBPACK_IMPORTED_MODULE_2__["FlashMessagesService"] }
    ]; };
    DoctorListComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-doctor-list',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./doctor-list.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/doctors/doctor-list/doctor-list.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./doctor-list.component.css */ "./src/app/doctors/doctor-list/doctor-list.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_doctor_service__WEBPACK_IMPORTED_MODULE_3__["DoctorService"], angular2_flash_messages__WEBPACK_IMPORTED_MODULE_2__["FlashMessagesService"]])
    ], DoctorListComponent);
    return DoctorListComponent;
}());



/***/ }),

/***/ "./src/app/doctors/doctor.service.ts":
/*!*******************************************!*\
  !*** ./src/app/doctors/doctor.service.ts ***!
  \*******************************************/
/*! exports provided: DoctorService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DoctorService", function() { return DoctorService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/http.js");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! angular2-flash-messages */ "./node_modules/angular2-flash-messages/__ivy_ngcc__/module/index.js");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");






var DoctorService = /** @class */ (function () {
    // tslint:disable-next-line:variable-name
    function DoctorService(httpc, _flashMessagesService) {
        this.httpc = httpc;
        this._flashMessagesService = _flashMessagesService;
        // tslint:disable-next-line:variable-name
        this.doctor_list = [];
        // tslint:disable-next-line:variable-name
        this.doctor_fetched_event_emitter = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
    }
    DoctorService.prototype.addnewDoctor = function (formdata) {
        var _this = this;
        this.httpc.post(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + '/doctors', formdata)
            .subscribe(function (result) {
            _this._flashMessagesService.show('Doctor Added Successfully', { cssClass: 'alert-success', timeout: 5000 });
        });
    };
    DoctorService.prototype.doctorListObservable = function () {
        return this.doctor_fetched_event_emitter.asObservable();
    };
    DoctorService.prototype.getDoctorList = function () {
        var _this = this;
        this.httpc.get(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + '/doctors')
            .subscribe(function (resultdata) {
            _this.doctor_list = resultdata.dlist;
            _this.doctor_fetched_event_emitter.next(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__spreadArrays"])(_this.doctor_list));
        });
    };
    DoctorService.prototype.getDoctorListForMap = function () {
        return this.httpc.get(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + '/doctors');
    };
    DoctorService.prototype.deleteDoctor = function (id) {
        return this.httpc.delete(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + '/doctors/' + id);
    };
    DoctorService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
        { type: angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__["FlashMessagesService"] }
    ]; };
    DoctorService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__["FlashMessagesService"]])
    ], DoctorService);
    return DoctorService;
}());



/***/ }),

/***/ "./src/app/doctors/pages/about-project/about-project.component.css":
/*!*************************************************************************!*\
  !*** ./src/app/doctors/pages/about-project/about-project.component.css ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2RvY3RvcnMvcGFnZXMvYWJvdXQtcHJvamVjdC9hYm91dC1wcm9qZWN0LmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/doctors/pages/about-project/about-project.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/doctors/pages/about-project/about-project.component.ts ***!
  \************************************************************************/
/*! exports provided: AboutProjectComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutProjectComponent", function() { return AboutProjectComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");


var AboutProjectComponent = /** @class */ (function () {
    function AboutProjectComponent() {
    }
    AboutProjectComponent.prototype.ngOnInit = function () {
    };
    AboutProjectComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-about-project',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./about-project.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/doctors/pages/about-project/about-project.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./about-project.component.css */ "./src/app/doctors/pages/about-project/about-project.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [])
    ], AboutProjectComponent);
    return AboutProjectComponent;
}());



/***/ }),

/***/ "./src/app/doctors/pages/about-us/about-us.component.css":
/*!***************************************************************!*\
  !*** ./src/app/doctors/pages/about-us/about-us.component.css ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2RvY3RvcnMvcGFnZXMvYWJvdXQtdXMvYWJvdXQtdXMuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/doctors/pages/about-us/about-us.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/doctors/pages/about-us/about-us.component.ts ***!
  \**************************************************************/
/*! exports provided: AboutUsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutUsComponent", function() { return AboutUsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");


var AboutUsComponent = /** @class */ (function () {
    function AboutUsComponent() {
    }
    AboutUsComponent.prototype.ngOnInit = function () {
    };
    AboutUsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-about-us',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./about-us.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/doctors/pages/about-us/about-us.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./about-us.component.css */ "./src/app/doctors/pages/about-us/about-us.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [])
    ], AboutUsComponent);
    return AboutUsComponent;
}());



/***/ }),

/***/ "./src/app/doctors/pages/contact-us/contact-us.component.css":
/*!*******************************************************************!*\
  !*** ./src/app/doctors/pages/contact-us/contact-us.component.css ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2RvY3RvcnMvcGFnZXMvY29udGFjdC11cy9jb250YWN0LXVzLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/doctors/pages/contact-us/contact-us.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/doctors/pages/contact-us/contact-us.component.ts ***!
  \******************************************************************/
/*! exports provided: ContactUsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactUsComponent", function() { return ContactUsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");


var ContactUsComponent = /** @class */ (function () {
    function ContactUsComponent() {
    }
    ContactUsComponent.prototype.ngOnInit = function () {
    };
    ContactUsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-contact-us',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./contact-us.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/doctors/pages/contact-us/contact-us.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./contact-us.component.css */ "./src/app/doctors/pages/contact-us/contact-us.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [])
    ], ContactUsComponent);
    return ContactUsComponent;
}());



/***/ }),

/***/ "./src/app/doctors/pages/mapview/mapview.component.css":
/*!*************************************************************!*\
  !*** ./src/app/doctors/pages/mapview/mapview.component.css ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2RvY3RvcnMvcGFnZXMvbWFwdmlldy9tYXB2aWV3LmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/doctors/pages/mapview/mapview.component.ts":
/*!************************************************************!*\
  !*** ./src/app/doctors/pages/mapview/mapview.component.ts ***!
  \************************************************************/
/*! exports provided: MapviewComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MapviewComponent", function() { return MapviewComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_google_maps__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/google-maps */ "./node_modules/@angular/google-maps/__ivy_ngcc__/fesm5/google-maps.js");
/* harmony import */ var src_app_specialists_specialist_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/specialists/specialist.service */ "./src/app/specialists/specialist.service.ts");
/* harmony import */ var _doctor_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../doctor.service */ "./src/app/doctors/doctor.service.ts");





var MapviewComponent = /** @class */ (function () {
    function MapviewComponent(elementRef, dservice, spservice) {
        this.elementRef = elementRef;
        this.dservice = dservice;
        this.spservice = spservice;
        this.doc_list = [];
        this.specalist_list = [];
        this.markers = [];
        this.zoom = 4;
        this.options = {
            mapTypeId: 'hybrid',
            zoomControl: true,
            scrollwheel: false,
            disableDoubleClickZoom: true,
        };
    }
    MapviewComponent.prototype.ngOnInit = function () {
        var _this = this;
        navigator.geolocation.getCurrentPosition(function (position) {
            _this.center = {
                lat: -37.814703,
                lng: 144.965723
            };
        });
        this.dservice.getDoctorListForMap()
            .subscribe(function (resultdata) {
            _this.doc_list = resultdata.dlist;
            _this.spservice.getSpecialistListForMap()
                .subscribe(function (resultdata) {
                _this.markers = [];
                _this.specalist_list = resultdata.slist;
                _this.specalist_list.forEach(function (element) {
                    var latlon = new google.maps.LatLng(element.inputLatitude, element.inputLongitude);
                    _this.markers.push({
                        position: latlon,
                        label: {
                            color: 'red',
                        },
                        title: element.inputFname + " " + element.inputLname + " (" + element.inputQualification + ")",
                        options: { animation: google.maps.Animation.BOUNCE },
                    });
                    console.log(element);
                });
                _this.doc_list.forEach(function (element) {
                    var latlon = new google.maps.LatLng(element.inputLatitude, element.inputLongitude);
                    _this.markers.push({
                        position: latlon,
                        label: {
                            color: 'red',
                        },
                        title: element.inputFname + " " + element.inputLname + " (" + element.inputQualification + ")",
                        options: { animation: google.maps.Animation.BOUNCE },
                    });
                    console.log(element);
                });
            });
        });
    };
    MapviewComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"] },
        { type: _doctor_service__WEBPACK_IMPORTED_MODULE_4__["DoctorService"] },
        { type: src_app_specialists_specialist_service__WEBPACK_IMPORTED_MODULE_3__["SpecialistService"] }
    ]; };
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_google_maps__WEBPACK_IMPORTED_MODULE_2__["GoogleMap"], { static: false }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", _angular_google_maps__WEBPACK_IMPORTED_MODULE_2__["GoogleMap"])
    ], MapviewComponent.prototype, "map", void 0);
    MapviewComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-mapview',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./mapview.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/doctors/pages/mapview/mapview.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./mapview.component.css */ "./src/app/doctors/pages/mapview/mapview.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"],
            _doctor_service__WEBPACK_IMPORTED_MODULE_4__["DoctorService"], src_app_specialists_specialist_service__WEBPACK_IMPORTED_MODULE_3__["SpecialistService"]])
    ], MapviewComponent);
    return MapviewComponent;
}());



/***/ }),

/***/ "./src/app/errors/custom-validator.ts":
/*!********************************************!*\
  !*** ./src/app/errors/custom-validator.ts ***!
  \********************************************/
/*! exports provided: CustomValidators */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomValidators", function() { return CustomValidators; });
var CustomValidators = /** @class */ (function () {
    function CustomValidators() {
    }
    CustomValidators.apptelephoneNumbers = function (c) {
        var isValidPhoneNumber = /^[7-9]{1}[0-9]{9}$/.test(c.value);
        var message = {
            telephoneNumber: {
                message: 'The phone number must contain only numbers'
            }
        };
        return isValidPhoneNumber ? null : message;
    };
    CustomValidators.numberValidate = function (c) {
        var numValue = Number(c.value);
        var isValid = !isNaN(numValue);
        var message = {
            number: {
                message: 'Enter a Valid Number'
            }
        };
        return isValid ? null : message;
    };
    CustomValidators.filevalidate = function (c) {
        var isValid = c.value != null && c.value.length !== 0;
        var message = {
            reqfile: {
                message: 'Please Select a File'
            }
        };
        return isValid ? null : message;
    };
    CustomValidators.filetypevalidate = function (control) {
        var message = {
            pdfWord: {
                message: 'Invalid Document Type Provided'
            }
        };
        var isValid = false;
        var file = control.value;
        if (control.value == null) {
            return isValid ? null : message;
        }
        // console.log(file);
        // console.log(typeof(file));
        var ext = '';
        if (typeof file === 'string') {
            ext = file.split('.').pop();
        }
        else {
            ext = file.name.split('.').pop();
        }
        var type = file.type;
        if (ext === 'pdf' || ext === 'docx' || ext === 'doc') {
            // if ( type === 'application/pdf' || ext === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ) {
            isValid = true;
        }
        return isValid ? null : message;
    };
    return CustomValidators;
}());



/***/ }),

/***/ "./src/app/errors/show-errors/show-errors.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/errors/show-errors/show-errors.component.ts ***!
  \*************************************************************/
/*! exports provided: ShowErrorsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShowErrorsComponent", function() { return ShowErrorsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");


var ShowErrorsComponent = /** @class */ (function () {
    function ShowErrorsComponent() {
    }
    ShowErrorsComponent_1 = ShowErrorsComponent;
    ShowErrorsComponent.prototype.shouldShowErrors = function () {
        return this.control &&
            this.control.errors &&
            (this.control.dirty || this.control.touched);
    };
    ShowErrorsComponent.prototype.listOfErrors = function () {
        var _this = this;
        return Object.keys(this.control.errors)
            .map(function (field) { return _this.getMessage(field, _this.control.errors[field]); });
    };
    ShowErrorsComponent.prototype.getMessage = function (type, params) {
        return ShowErrorsComponent_1.errorMessages[type](params);
    };
    var ShowErrorsComponent_1;
    ShowErrorsComponent.errorMessages = {
        'required': function () { return 'This field is required'; },
        'email': function () { return 'Invalid Email Id Provided'; },
        'minlength': function (params) { return 'The min number of characters is ' + params.requiredLength; },
        'maxlength': function (params) { return 'The max allowed number of characters is ' + params.requiredLength; },
        'pattern': function (params) { return 'The required pattern is: ' + params.requiredPattern; },
        'years': function (params) { return params.message; },
        'countryCity': function (params) { return params.message; },
        'uniqueName': function (params) { return params.message; },
        'telephoneNumbers': function (params) { return params.message; },
        'telephoneNumber': function (params) { return params.message; },
        'pdfWord': function (params) { return params.message; },
        'number': function (params) { return params.message; },
        'reqfile': function (params) { return params.message; }
    };
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Object)
    ], ShowErrorsComponent.prototype, "control", void 0);
    ShowErrorsComponent = ShowErrorsComponent_1 = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-show-errors',
            template: "\n             <div class=\"alert alert-danger\" *ngIf=\"shouldShowErrors()\">\n             <ul *ngIf=\"shouldShowErrors()\">\n               <li *ngFor=\"let error of listOfErrors()\">{{error}}</li>\n             </ul>\n             </div>"
        })
    ], ShowErrorsComponent);
    return ShowErrorsComponent;
}());



/***/ }),

/***/ "./src/app/footer/footer.component.css":
/*!*********************************************!*\
  !*** ./src/app/footer/footer.component.css ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Zvb3Rlci9mb290ZXIuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/footer/footer.component.ts":
/*!********************************************!*\
  !*** ./src/app/footer/footer.component.ts ***!
  \********************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");


var FooterComponent = /** @class */ (function () {
    function FooterComponent() {
    }
    FooterComponent.prototype.ngOnInit = function () {
    };
    FooterComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-footer',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./footer.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/footer/footer.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./footer.component.css */ "./src/app/footer/footer.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [])
    ], FooterComponent);
    return FooterComponent;
}());



/***/ }),

/***/ "./src/app/header/address/address.component.css":
/*!******************************************************!*\
  !*** ./src/app/header/address/address.component.css ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".inwrapper{padding:1em 0;}\r\n.inwrapper address{display:inline-block;}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaGVhZGVyL2FkZHJlc3MvYWRkcmVzcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFdBQVcsYUFBYSxDQUFDO0FBQ3pCLG1CQUFtQixvQkFBb0IsQ0FBQyIsImZpbGUiOiJzcmMvYXBwL2hlYWRlci9hZGRyZXNzL2FkZHJlc3MuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5pbndyYXBwZXJ7cGFkZGluZzoxZW0gMDt9XHJcbi5pbndyYXBwZXIgYWRkcmVzc3tkaXNwbGF5OmlubGluZS1ibG9jazt9XHJcbiJdfQ== */");

/***/ }),

/***/ "./src/app/header/address/address.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/header/address/address.component.ts ***!
  \*****************************************************/
/*! exports provided: AddressComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddressComponent", function() { return AddressComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");


var AddressComponent = /** @class */ (function () {
    function AddressComponent() {
    }
    AddressComponent.prototype.ngOnInit = function () {
    };
    AddressComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-address',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./address.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/header/address/address.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./address.component.css */ "./src/app/header/address/address.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [])
    ], AddressComponent);
    return AddressComponent;
}());



/***/ }),

/***/ "./src/app/header/header.component.css":
/*!*********************************************!*\
  !*** ./src/app/header/header.component.css ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".content h2 > strong{color:#00FFAA}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaGVhZGVyL2hlYWRlci5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLHFCQUFxQixhQUFhIiwiZmlsZSI6InNyYy9hcHAvaGVhZGVyL2hlYWRlci5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRlbnQgaDIgPiBzdHJvbmd7Y29sb3I6IzAwRkZBQX1cclxuIl19 */");

/***/ }),

/***/ "./src/app/header/header.component.ts":
/*!********************************************!*\
  !*** ./src/app/header/header.component.ts ***!
  \********************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");


var HeaderComponent = /** @class */ (function () {
    function HeaderComponent() {
    }
    HeaderComponent.prototype.ngOnInit = function () {
    };
    HeaderComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-header',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./header.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/header/header.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./header.component.css */ "./src/app/header/header.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [])
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/header/logo/logo.component.css":
/*!************************************************!*\
  !*** ./src/app/header/logo/logo.component.css ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".logo h1{font-size: 50px;\r\n  color: #333;\r\n  margin: 0;\r\n  line-height: 134px;}\r\n\r\n\r\n  .logo h1 > strong{font-weight:600;color:#D4C3C8}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaGVhZGVyL2xvZ28vbG9nby5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsZUFBZTtFQUN0QixXQUFXO0VBQ1gsU0FBUztFQUNULGtCQUFrQixDQUFDOzs7RUFHbkIsa0JBQWtCLGVBQWUsQ0FBQyxhQUFhIiwiZmlsZSI6InNyYy9hcHAvaGVhZGVyL2xvZ28vbG9nby5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmxvZ28gaDF7Zm9udC1zaXplOiA1MHB4O1xyXG4gIGNvbG9yOiAjMzMzO1xyXG4gIG1hcmdpbjogMDtcclxuICBsaW5lLWhlaWdodDogMTM0cHg7fVxyXG5cclxuXHJcbiAgLmxvZ28gaDEgPiBzdHJvbmd7Zm9udC13ZWlnaHQ6NjAwO2NvbG9yOiNENEMzQzh9XHJcbiJdfQ== */");

/***/ }),

/***/ "./src/app/header/logo/logo.component.ts":
/*!***********************************************!*\
  !*** ./src/app/header/logo/logo.component.ts ***!
  \***********************************************/
/*! exports provided: LogoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogoComponent", function() { return LogoComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");


var LogoComponent = /** @class */ (function () {
    function LogoComponent() {
    }
    LogoComponent.prototype.ngOnInit = function () {
    };
    LogoComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-logo',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./logo.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/header/logo/logo.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./logo.component.css */ "./src/app/header/logo/logo.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [])
    ], LogoComponent);
    return LogoComponent;
}());



/***/ }),

/***/ "./src/app/leftmenu/leftmenu.component.css":
/*!*************************************************!*\
  !*** ./src/app/leftmenu/leftmenu.component.css ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".left_block h2{font-weight:400;}\r\n\r\n.panel-group .panel-heading .panel-title {border-width: 1px 1px;}\r\n\r\n.panel-group .list-group .list-group-item {\tborder-radius: 0;\t\tborder-right: none; border-width: 1px 1px;}\r\n\r\n.panel-group .list-group .list-group-item a{color:#222; }\r\n\r\n.panel-group .list-group .list-group-item:last-child {\tborder-bottom: none;}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbGVmdG1lbnUvbGVmdG1lbnUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxlQUFlLGVBQWUsQ0FBQzs7QUFFL0IsMENBQTBDLHFCQUFxQixDQUFDOztBQUVoRSw0Q0FBNEMsZ0JBQWdCLEdBQUcsa0JBQWtCLEVBQUUscUJBQXFCLENBQUM7O0FBQ3pHLDRDQUE0QyxVQUFVLEVBQUU7O0FBQ3hELHVEQUF1RCxtQkFBbUIsQ0FBQyIsImZpbGUiOiJzcmMvYXBwL2xlZnRtZW51L2xlZnRtZW51LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubGVmdF9ibG9jayBoMntmb250LXdlaWdodDo0MDA7fVxyXG5cclxuLnBhbmVsLWdyb3VwIC5wYW5lbC1oZWFkaW5nIC5wYW5lbC10aXRsZSB7Ym9yZGVyLXdpZHRoOiAxcHggMXB4O31cclxuXHJcbi5wYW5lbC1ncm91cCAubGlzdC1ncm91cCAubGlzdC1ncm91cC1pdGVtIHtcdGJvcmRlci1yYWRpdXM6IDA7XHRcdGJvcmRlci1yaWdodDogbm9uZTsgYm9yZGVyLXdpZHRoOiAxcHggMXB4O31cclxuLnBhbmVsLWdyb3VwIC5saXN0LWdyb3VwIC5saXN0LWdyb3VwLWl0ZW0gYXtjb2xvcjojMjIyOyB9XHJcbi5wYW5lbC1ncm91cCAubGlzdC1ncm91cCAubGlzdC1ncm91cC1pdGVtOmxhc3QtY2hpbGQge1x0Ym9yZGVyLWJvdHRvbTogbm9uZTt9XHJcbiJdfQ== */");

/***/ }),

/***/ "./src/app/leftmenu/leftmenu.component.ts":
/*!************************************************!*\
  !*** ./src/app/leftmenu/leftmenu.component.ts ***!
  \************************************************/
/*! exports provided: LeftmenuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LeftmenuComponent", function() { return LeftmenuComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../auth/auth.service */ "./src/app/auth/auth.service.ts");



var LeftmenuComponent = /** @class */ (function () {
    function LeftmenuComponent(authservice) {
        this.authservice = authservice;
        this.isAuthenticated = false;
        this.user_role = -1;
    }
    LeftmenuComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.isAuthenticated = this.authservice.getAuthStatus();
        this.AuthSubcription = this.authservice
            .getAuthStatusListener()
            .subscribe(function (authData) {
            _this.isAuthenticated = authData.loginstatus;
            _this.user_role = authData.user_role;
            console.log("THE AUTH DATA IS : " +
                _this.user_role +
                "AUTH IS " +
                _this.isAuthenticated);
        });
    };
    LeftmenuComponent.prototype.onLogout = function () {
        this.authservice.logout();
    };
    LeftmenuComponent.prototype.ngOnDestroy = function () {
        this.AuthSubcription.unsubscribe();
    };
    LeftmenuComponent.ctorParameters = function () { return [
        { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] }
    ]; };
    LeftmenuComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: "app-leftmenu",
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./leftmenu.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/leftmenu/leftmenu.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./leftmenu.component.css */ "./src/app/leftmenu/leftmenu.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]])
    ], LeftmenuComponent);
    return LeftmenuComponent;
}());



/***/ }),

/***/ "./src/app/main-content/main-content.component.css":
/*!*********************************************************!*\
  !*** ./src/app/main-content/main-content.component.css ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21haW4tY29udGVudC9tYWluLWNvbnRlbnQuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/main-content/main-content.component.ts":
/*!********************************************************!*\
  !*** ./src/app/main-content/main-content.component.ts ***!
  \********************************************************/
/*! exports provided: MainContentComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainContentComponent", function() { return MainContentComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../auth/auth.service */ "./src/app/auth/auth.service.ts");



var MainContentComponent = /** @class */ (function () {
    function MainContentComponent(authservice) {
        this.authservice = authservice;
    }
    MainContentComponent.prototype.ngOnInit = function () {
        this.authservice.AutoAuthUser();
    };
    MainContentComponent.ctorParameters = function () { return [
        { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] }
    ]; };
    MainContentComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-main-content',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./main-content.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/main-content/main-content.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./main-content.component.css */ "./src/app/main-content/main-content.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]])
    ], MainContentComponent);
    return MainContentComponent;
}());



/***/ }),

/***/ "./src/app/patients/doctor-patient-list/doctor-patient-list.component.css":
/*!********************************************************************************!*\
  !*** ./src/app/patients/doctor-patient-list/doctor-patient-list.component.css ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".specialist> tbody > tr > td\r\n{\r\n  border: 2px solid #166119;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGF0aWVudHMvZG9jdG9yLXBhdGllbnQtbGlzdC9kb2N0b3ItcGF0aWVudC1saXN0LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7O0VBRUUseUJBQXlCO0FBQzNCIiwiZmlsZSI6InNyYy9hcHAvcGF0aWVudHMvZG9jdG9yLXBhdGllbnQtbGlzdC9kb2N0b3ItcGF0aWVudC1saXN0LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3BlY2lhbGlzdD4gdGJvZHkgPiB0ciA+IHRkXHJcbntcclxuICBib3JkZXI6IDJweCBzb2xpZCAjMTY2MTE5O1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "./src/app/patients/doctor-patient-list/doctor-patient-list.component.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/patients/doctor-patient-list/doctor-patient-list.component.ts ***!
  \*******************************************************************************/
/*! exports provided: DoctorPatientListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DoctorPatientListComponent", function() { return DoctorPatientListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var _patient_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../patient.service */ "./src/app/patients/patient.service.ts");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! angular2-flash-messages */ "./node_modules/angular2-flash-messages/__ivy_ngcc__/module/index.js");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(angular2_flash_messages__WEBPACK_IMPORTED_MODULE_4__);





var DoctorPatientListComponent = /** @class */ (function () {
    function DoctorPatientListComponent(fb, pservice, _flashMessagesService) {
        this.fb = fb;
        this.pservice = pservice;
        this._flashMessagesService = _flashMessagesService;
        // tslint:disable-next-line:variable-name
        this.patient_data = null;
    }
    DoctorPatientListComponent.prototype.ngOnInit = function () {
        this.myform = this.fb.group({
            'inputPuid': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])
        });
    };
    DoctorPatientListComponent.prototype.onSearch = function () {
        var _this = this;
        this.patient_data = null;
        this.pservice.searchPatientDetailsforDcotor(this.myform.value.inputPuid)
            .subscribe(function (result) {
            console.log(result);
            _this.patient_data = result.pdata[0];
            var updatemprecords = [];
            _this.patient_data.mprecords.forEach(function (element) {
                var newfilesset = [];
                _this.patient_data.mpfiles.forEach(function (file) {
                    if (file.inputRid === element._id) {
                        newfilesset.push({ inputFilename: file.inputFilename,
                            inputUrl: file.inputURL });
                    }
                });
                element.files = newfilesset;
                updatemprecords.push(element);
            });
            _this.patient_data.mprecords = updatemprecords;
            _this.patient_data.mpfiles = null;
        });
    };
    DoctorPatientListComponent.ctorParameters = function () { return [
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
        { type: _patient_service__WEBPACK_IMPORTED_MODULE_3__["PatientService"] },
        { type: angular2_flash_messages__WEBPACK_IMPORTED_MODULE_4__["FlashMessagesService"] }
    ]; };
    DoctorPatientListComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-doctor-patient-list',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./doctor-patient-list.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/patients/doctor-patient-list/doctor-patient-list.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./doctor-patient-list.component.css */ "./src/app/patients/doctor-patient-list/doctor-patient-list.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _patient_service__WEBPACK_IMPORTED_MODULE_3__["PatientService"], angular2_flash_messages__WEBPACK_IMPORTED_MODULE_4__["FlashMessagesService"]])
    ], DoctorPatientListComponent);
    return DoctorPatientListComponent;
}());



/***/ }),

/***/ "./src/app/patients/patient-create/patient-create.component.css":
/*!**********************************************************************!*\
  !*** ./src/app/patients/patient-create/patient-create.component.css ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhdGllbnRzL3BhdGllbnQtY3JlYXRlL3BhdGllbnQtY3JlYXRlLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/patients/patient-create/patient-create.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/patients/patient-create/patient-create.component.ts ***!
  \*********************************************************************/
/*! exports provided: PatientCreateComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PatientCreateComponent", function() { return PatientCreateComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var _patient_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../patient.service */ "./src/app/patients/patient.service.ts");
/* harmony import */ var _errors_custom_validator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../errors/custom-validator */ "./src/app/errors/custom-validator.ts");





var PatientCreateComponent = /** @class */ (function () {
    function PatientCreateComponent(fb, pservice) {
        this.fb = fb;
        this.pservice = pservice;
    }
    PatientCreateComponent.prototype.ngOnInit = function () {
        this.myform = this.fb.group({
            'inputPuid': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputFname': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(3)]),
            'inputLname': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(3)]),
            'inputAid': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputPhone': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(10), _errors_custom_validator__WEBPACK_IMPORTED_MODULE_4__["CustomValidators"].apptelephoneNumbers]),
            'inputEmail': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email]),
            'inputAge': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputGender': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputAddress': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])
        });
    };
    PatientCreateComponent.prototype.onSubmit = function () {
        this.pservice.addnewPatient(this.myform.value);
        this.myform.reset();
    };
    PatientCreateComponent.ctorParameters = function () { return [
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
        { type: _patient_service__WEBPACK_IMPORTED_MODULE_3__["PatientService"] }
    ]; };
    PatientCreateComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-patient-create',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./patient-create.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/patients/patient-create/patient-create.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./patient-create.component.css */ "./src/app/patients/patient-create/patient-create.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _patient_service__WEBPACK_IMPORTED_MODULE_3__["PatientService"]])
    ], PatientCreateComponent);
    return PatientCreateComponent;
}());



/***/ }),

/***/ "./src/app/patients/patient-details/patient-details.component.css":
/*!************************************************************************!*\
  !*** ./src/app/patients/patient-details/patient-details.component.css ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhdGllbnRzL3BhdGllbnQtZGV0YWlscy9wYXRpZW50LWRldGFpbHMuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/patients/patient-details/patient-details.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/patients/patient-details/patient-details.component.ts ***!
  \***********************************************************************/
/*! exports provided: PatientDetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PatientDetailsComponent", function() { return PatientDetailsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _patient_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../patient.service */ "./src/app/patients/patient.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js");




var PatientDetailsComponent = /** @class */ (function () {
    function PatientDetailsComponent(routes, patientservice) {
        this.routes = routes;
        this.patientservice = patientservice;
        this.isLoading = false;
    }
    PatientDetailsComponent.prototype.ngOnInit = function () {
        var _this = this;
        console.log('Hello');
        this.isLoading = true;
        this.routes.paramMap.subscribe(function (parammap) {
            if (parammap.has('pid')) {
                _this.pid = parammap.get('pid');
                console.log(_this.pid);
                _this.patientservice.getSinglePatientDetails(_this.pid)
                    .subscribe(function (resultd) {
                    _this.patientdetails = resultd.pdata;
                    console.log(_this.patientdetails);
                    _this.isLoading = false;
                });
            }
        });
    };
    PatientDetailsComponent.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
        { type: _patient_service__WEBPACK_IMPORTED_MODULE_2__["PatientService"] }
    ]; };
    PatientDetailsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-patient-details',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./patient-details.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/patients/patient-details/patient-details.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./patient-details.component.css */ "./src/app/patients/patient-details/patient-details.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], _patient_service__WEBPACK_IMPORTED_MODULE_2__["PatientService"]])
    ], PatientDetailsComponent);
    return PatientDetailsComponent;
}());



/***/ }),

/***/ "./src/app/patients/patient-list/patient-list.component.css":
/*!******************************************************************!*\
  !*** ./src/app/patients/patient-list/patient-list.component.css ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhdGllbnRzL3BhdGllbnQtbGlzdC9wYXRpZW50LWxpc3QuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/patients/patient-list/patient-list.component.ts":
/*!*****************************************************************!*\
  !*** ./src/app/patients/patient-list/patient-list.component.ts ***!
  \*****************************************************************/
/*! exports provided: PatientListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PatientListComponent", function() { return PatientListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _patient_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../patient.service */ "./src/app/patients/patient.service.ts");
/* harmony import */ var angular2_flash_messages_module_flash_messages_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! angular2-flash-messages/module/flash-messages.service */ "./node_modules/angular2-flash-messages/module/flash-messages.service.js");
/* harmony import */ var angular2_flash_messages_module_flash_messages_service__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(angular2_flash_messages_module_flash_messages_service__WEBPACK_IMPORTED_MODULE_3__);




var PatientListComponent = /** @class */ (function () {
    // tslint:disable-next-line:variable-name
    function PatientListComponent(pservice, _flashMessagesService) {
        this.pservice = pservice;
        this._flashMessagesService = _flashMessagesService;
        this.PatientList = [];
    }
    PatientListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.pservice.getPatientList();
        this.PListSubcriber = this.pservice.patientListObservable()
            .subscribe(function (listdata) {
            _this.PatientList = listdata;
        });
    };
    PatientListComponent.prototype.deletePatient = function (iid) {
        var _this = this;
        if (confirm('Are You Sure Do U want to Delete Submission')) {
            this.pservice.deletePatient(iid)
                .subscribe(function (result) {
                _this.pservice.getPatientList();
                _this._flashMessagesService.show('Patient Deleted !', { cssClass: 'alert-success', timeout: 5000 });
            });
        }
    };
    PatientListComponent.ctorParameters = function () { return [
        { type: _patient_service__WEBPACK_IMPORTED_MODULE_2__["PatientService"] },
        { type: angular2_flash_messages_module_flash_messages_service__WEBPACK_IMPORTED_MODULE_3__["FlashMessagesService"] }
    ]; };
    PatientListComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-patient-list',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./patient-list.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/patients/patient-list/patient-list.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./patient-list.component.css */ "./src/app/patients/patient-list/patient-list.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_patient_service__WEBPACK_IMPORTED_MODULE_2__["PatientService"], angular2_flash_messages_module_flash_messages_service__WEBPACK_IMPORTED_MODULE_3__["FlashMessagesService"]])
    ], PatientListComponent);
    return PatientListComponent;
}());



/***/ }),

/***/ "./src/app/patients/patient.service.ts":
/*!*********************************************!*\
  !*** ./src/app/patients/patient.service.ts ***!
  \*********************************************/
/*! exports provided: PatientService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PatientService", function() { return PatientService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/http.js");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! angular2-flash-messages */ "./node_modules/angular2-flash-messages/__ivy_ngcc__/module/index.js");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");






var PatientService = /** @class */ (function () {
    // tslint:disable-next-line:variable-name
    function PatientService(httpc, _flashMessagesService) {
        this.httpc = httpc;
        this._flashMessagesService = _flashMessagesService;
        // tslint:disable-next-line:variable-name
        this.patient_list = [];
        // tslint:disable-next-line:variable-name
        this.patient_fetched_event_emitter = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
    }
    PatientService.prototype.addnewPatient = function (formdata) {
        var _this = this;
        this.httpc
            .post(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + "/patients", formdata)
            .subscribe(function (result) {
            _this._flashMessagesService.show("Patient Added Successfully", {
                cssClass: "alert-success",
                timeout: 5000
            });
        });
    };
    PatientService.prototype.patientListObservable = function () {
        return this.patient_fetched_event_emitter.asObservable();
    };
    PatientService.prototype.getPatientList = function () {
        var _this = this;
        this.httpc
            .get(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + "/patients")
            .subscribe(function (resultdata) {
            _this.patient_list = resultdata.plist;
            _this.patient_fetched_event_emitter.next(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__spreadArrays"])(_this.patient_list));
        });
    };
    PatientService.prototype.deletePatient = function (id) {
        return this.httpc.delete(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + "/patients/" + id);
    };
    PatientService.prototype.getSinglePatientDetails = function (pid) {
        return this.httpc.get(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + "/patients/" + pid);
    };
    PatientService.prototype.searchPatientDetails = function (patient_auid) {
        return this.httpc.get(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + "/patients/search/" + patient_auid);
    };
    PatientService.prototype.searchPatientDetailsforDcotor = function (patient_auid) {
        return this.httpc.get(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + "/patients/search/doctors/" + patient_auid);
    };
    PatientService.prototype.addPatientrecord = function (formdata) {
        console.log(formdata);
        return this.httpc.post(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + "/patients/precords", formdata);
    };
    PatientService.prototype.addSpecialistPatientrecord = function (formdata) {
        console.log(formdata);
        return this.httpc.post(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + "/patients/precords/specialist", formdata);
    };
    PatientService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
        { type: angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__["FlashMessagesService"] }
    ]; };
    PatientService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: "root"
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
            angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__["FlashMessagesService"]])
    ], PatientService);
    return PatientService;
}());



/***/ }),

/***/ "./src/app/precords/precord-create/precord-create.component.css":
/*!**********************************************************************!*\
  !*** ./src/app/precords/precord-create/precord-create.component.css ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3ByZWNvcmRzL3ByZWNvcmQtY3JlYXRlL3ByZWNvcmQtY3JlYXRlLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/precords/precord-create/precord-create.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/precords/precord-create/precord-create.component.ts ***!
  \*********************************************************************/
/*! exports provided: PrecordCreateComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrecordCreateComponent", function() { return PrecordCreateComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var src_app_patients_patient_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/patients/patient.service */ "./src/app/patients/patient.service.ts");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! angular2-flash-messages */ "./node_modules/angular2-flash-messages/__ivy_ngcc__/module/index.js");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(angular2_flash_messages__WEBPACK_IMPORTED_MODULE_4__);





var PrecordCreateComponent = /** @class */ (function () {
    function PrecordCreateComponent(fb, pservice, _flashMessagesService) {
        this.fb = fb;
        this.pservice = pservice;
        this._flashMessagesService = _flashMessagesService;
        this.patient_data = null;
        this.filesToUpload = [];
    }
    PrecordCreateComponent.prototype.ngOnInit = function () {
        this.myform = this.fb.group({
            'inputPuid': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])
        });
        this.myform1 = this.fb.group({
            'inputChospital': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputCdoctor': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputDescription': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
        });
    };
    PrecordCreateComponent.prototype.onSearch = function () {
        var _this = this;
        this.patient_data = null;
        this.pservice.searchPatientDetails(this.myform.value.inputPuid)
            .subscribe(function (result) {
            console.log(result);
            _this.patient_data = result.pdata[0];
        });
    };
    PrecordCreateComponent.prototype.fileChangeEvent = function (fileInput) {
        this.filesToUpload = fileInput.target.files;
    };
    PrecordCreateComponent.prototype.onFormSubmit = function () {
        var _this = this;
        var userdata = new FormData();
        console.log(this.patient_data._id);
        userdata.append('pid', this.patient_data._id);
        userdata.append('inputChospital', this.myform1.value.inputChospital);
        userdata.append('inputCdoctor', this.myform1.value.inputCdoctor);
        userdata.append('inputDescription', this.myform1.value.inputDescription);
        console.log(userdata);
        var files = this.filesToUpload;
        for (var i = 0; i < files.length; i++) {
            userdata.append("uploads[]", files[i], files[i]['name']);
        }
        console.log(userdata.toString());
        this.pservice.addPatientrecord(userdata)
            .subscribe(function (result) {
            _this._flashMessagesService.show('Patient Record Added Successfully', { cssClass: 'alert-success', timeout: 5000 });
            _this.myform1.reset();
            _this.patient_id = null;
            _this.patient_data = null;
            _this.filesToUpload = [];
            _this.myform.reset();
        });
    };
    PrecordCreateComponent.ctorParameters = function () { return [
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
        { type: src_app_patients_patient_service__WEBPACK_IMPORTED_MODULE_3__["PatientService"] },
        { type: angular2_flash_messages__WEBPACK_IMPORTED_MODULE_4__["FlashMessagesService"] }
    ]; };
    PrecordCreateComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-precord-create',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./precord-create.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/precords/precord-create/precord-create.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./precord-create.component.css */ "./src/app/precords/precord-create/precord-create.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            src_app_patients_patient_service__WEBPACK_IMPORTED_MODULE_3__["PatientService"],
            angular2_flash_messages__WEBPACK_IMPORTED_MODULE_4__["FlashMessagesService"]])
    ], PrecordCreateComponent);
    return PrecordCreateComponent;
}());



/***/ }),

/***/ "./src/app/precords/spec-prerecord-create/spec-prerecord-create.component.css":
/*!************************************************************************************!*\
  !*** ./src/app/precords/spec-prerecord-create/spec-prerecord-create.component.css ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3ByZWNvcmRzL3NwZWMtcHJlcmVjb3JkLWNyZWF0ZS9zcGVjLXByZXJlY29yZC1jcmVhdGUuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/precords/spec-prerecord-create/spec-prerecord-create.component.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/precords/spec-prerecord-create/spec-prerecord-create.component.ts ***!
  \***********************************************************************************/
/*! exports provided: SpecPrerecordCreateComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SpecPrerecordCreateComponent", function() { return SpecPrerecordCreateComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var src_app_patients_patient_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/patients/patient.service */ "./src/app/patients/patient.service.ts");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! angular2-flash-messages */ "./node_modules/angular2-flash-messages/__ivy_ngcc__/module/index.js");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(angular2_flash_messages__WEBPACK_IMPORTED_MODULE_4__);





var SpecPrerecordCreateComponent = /** @class */ (function () {
    function SpecPrerecordCreateComponent(fb, pservice, _flashMessagesService) {
        this.fb = fb;
        this.pservice = pservice;
        this._flashMessagesService = _flashMessagesService;
        this.patient_data = null;
        this.filesToUpload = [];
    }
    SpecPrerecordCreateComponent.prototype.ngOnInit = function () {
        this.myform = this.fb.group({
            'inputPuid': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])
        });
        this.myform1 = this.fb.group({
            'inputChospital': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputCdoctor': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputDescription': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
        });
    };
    SpecPrerecordCreateComponent.prototype.onSearch = function () {
        var _this = this;
        this.patient_data = null;
        this.pservice.searchPatientDetails(this.myform.value.inputPuid)
            .subscribe(function (result) {
            console.log(result);
            _this.patient_data = result.pdata[0];
        });
    };
    SpecPrerecordCreateComponent.prototype.fileChangeEvent = function (fileInput) {
        this.filesToUpload = fileInput.target.files;
    };
    SpecPrerecordCreateComponent.prototype.onFormSubmit = function () {
        var _this = this;
        var userdata = new FormData();
        console.log(this.patient_data._id);
        userdata.append('pid', this.patient_data._id);
        userdata.append('inputChospital', this.myform1.value.inputChospital);
        userdata.append('inputCdoctor', this.myform1.value.inputCdoctor);
        userdata.append('inputDescription', this.myform1.value.inputDescription);
        console.log(userdata);
        var files = this.filesToUpload;
        for (var i = 0; i < files.length; i++) {
            userdata.append("uploads[]", files[i], files[i]['name']);
        }
        console.log(userdata.toString());
        this.pservice.addSpecialistPatientrecord(userdata)
            .subscribe(function (result) {
            _this._flashMessagesService.show('Patient Record Added Successfully', { cssClass: 'alert-success', timeout: 5000 });
            _this.myform1.reset();
            _this.patient_id = null;
            _this.patient_data = null;
            _this.filesToUpload = [];
            _this.myform.reset();
        });
    };
    SpecPrerecordCreateComponent.ctorParameters = function () { return [
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
        { type: src_app_patients_patient_service__WEBPACK_IMPORTED_MODULE_3__["PatientService"] },
        { type: angular2_flash_messages__WEBPACK_IMPORTED_MODULE_4__["FlashMessagesService"] }
    ]; };
    SpecPrerecordCreateComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-spec-prerecord-create',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./spec-prerecord-create.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/precords/spec-prerecord-create/spec-prerecord-create.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./spec-prerecord-create.component.css */ "./src/app/precords/spec-prerecord-create/spec-prerecord-create.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            src_app_patients_patient_service__WEBPACK_IMPORTED_MODULE_3__["PatientService"],
            angular2_flash_messages__WEBPACK_IMPORTED_MODULE_4__["FlashMessagesService"]])
    ], SpecPrerecordCreateComponent);
    return SpecPrerecordCreateComponent;
}());



/***/ }),

/***/ "./src/app/receptionists/receptionist-create/receptionist-create.component.css":
/*!*************************************************************************************!*\
  !*** ./src/app/receptionists/receptionist-create/receptionist-create.component.css ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JlY2VwdGlvbmlzdHMvcmVjZXB0aW9uaXN0LWNyZWF0ZS9yZWNlcHRpb25pc3QtY3JlYXRlLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/receptionists/receptionist-create/receptionist-create.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/receptionists/receptionist-create/receptionist-create.component.ts ***!
  \************************************************************************************/
/*! exports provided: ReceptionistCreateComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReceptionistCreateComponent", function() { return ReceptionistCreateComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var _receptionist_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../receptionist.service */ "./src/app/receptionists/receptionist.service.ts");
/* harmony import */ var _errors_custom_validator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../errors/custom-validator */ "./src/app/errors/custom-validator.ts");





var ReceptionistCreateComponent = /** @class */ (function () {
    function ReceptionistCreateComponent(fb, rservice) {
        this.fb = fb;
        this.rservice = rservice;
    }
    ReceptionistCreateComponent.prototype.ngOnInit = function () {
        this.myform = this.fb.group({
            'inputFname': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputLname': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(3)]),
            'inputEmail': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email]),
            'inputPass': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(10)]),
            'inputPhone': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(10), _errors_custom_validator__WEBPACK_IMPORTED_MODULE_4__["CustomValidators"].apptelephoneNumbers]),
            'inputAddress': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])
        });
    };
    ReceptionistCreateComponent.prototype.onSubmit = function () {
        this.rservice.addnewReceptionist(this.myform.value);
        this.myform.reset();
    };
    ReceptionistCreateComponent.ctorParameters = function () { return [
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
        { type: _receptionist_service__WEBPACK_IMPORTED_MODULE_3__["ReceptionistService"] }
    ]; };
    ReceptionistCreateComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-receptionist-create',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./receptionist-create.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/receptionists/receptionist-create/receptionist-create.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./receptionist-create.component.css */ "./src/app/receptionists/receptionist-create/receptionist-create.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _receptionist_service__WEBPACK_IMPORTED_MODULE_3__["ReceptionistService"]])
    ], ReceptionistCreateComponent);
    return ReceptionistCreateComponent;
}());



/***/ }),

/***/ "./src/app/receptionists/receptionist-list/receptionist-list.component.css":
/*!*********************************************************************************!*\
  !*** ./src/app/receptionists/receptionist-list/receptionist-list.component.css ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JlY2VwdGlvbmlzdHMvcmVjZXB0aW9uaXN0LWxpc3QvcmVjZXB0aW9uaXN0LWxpc3QuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/receptionists/receptionist-list/receptionist-list.component.ts":
/*!********************************************************************************!*\
  !*** ./src/app/receptionists/receptionist-list/receptionist-list.component.ts ***!
  \********************************************************************************/
/*! exports provided: ReceptionistListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReceptionistListComponent", function() { return ReceptionistListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _receptionist_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../receptionist.service */ "./src/app/receptionists/receptionist.service.ts");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! angular2-flash-messages */ "./node_modules/angular2-flash-messages/__ivy_ngcc__/module/index.js");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__);




var ReceptionistListComponent = /** @class */ (function () {
    // tslint:disable-next-line:variable-name
    function ReceptionistListComponent(rservice, _flashMessagesService) {
        this.rservice = rservice;
        this._flashMessagesService = _flashMessagesService;
        this.ReceptionistList = [];
    }
    ReceptionistListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.rservice.getReceptionistList();
        this.RListSubcriber = this.rservice.receptionistListObservable()
            .subscribe(function (listdata) {
            _this.ReceptionistList = listdata;
        });
    };
    ReceptionistListComponent.prototype.deleteReceptionist = function (iid) {
        var _this = this;
        if (confirm('Are You Sure Do U want to Delete Submission')) {
            this.rservice.deleteReceptionist(iid)
                .subscribe(function (result) {
                _this.rservice.getReceptionistList();
                _this._flashMessagesService.show('Receptionist Deleted !', { cssClass: 'alert-success', timeout: 5000 });
            });
        }
    };
    ReceptionistListComponent.ctorParameters = function () { return [
        { type: _receptionist_service__WEBPACK_IMPORTED_MODULE_2__["ReceptionistService"] },
        { type: angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__["FlashMessagesService"] }
    ]; };
    ReceptionistListComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-receptionist-list',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./receptionist-list.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/receptionists/receptionist-list/receptionist-list.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./receptionist-list.component.css */ "./src/app/receptionists/receptionist-list/receptionist-list.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_receptionist_service__WEBPACK_IMPORTED_MODULE_2__["ReceptionistService"], angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__["FlashMessagesService"]])
    ], ReceptionistListComponent);
    return ReceptionistListComponent;
}());



/***/ }),

/***/ "./src/app/receptionists/receptionist.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/receptionists/receptionist.service.ts ***!
  \*******************************************************/
/*! exports provided: ReceptionistService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReceptionistService", function() { return ReceptionistService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/http.js");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! angular2-flash-messages */ "./node_modules/angular2-flash-messages/__ivy_ngcc__/module/index.js");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");






var ReceptionistService = /** @class */ (function () {
    // tslint:disable-next-line:variable-name
    function ReceptionistService(httpc, _flashMessagesService) {
        this.httpc = httpc;
        this._flashMessagesService = _flashMessagesService;
        // tslint:disable-next-line:variable-name
        this.receptionist_list = [];
        // tslint:disable-next-line:variable-name
        this.receptionist_fetched_event_emitter = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
    }
    ReceptionistService.prototype.addnewReceptionist = function (formdata) {
        var _this = this;
        this.httpc.post(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + '/receptionists', formdata)
            .subscribe(function (result) {
            _this._flashMessagesService.show('Receptionist Added Successfully', { cssClass: 'alert-success', timeout: 5000 });
        });
    };
    ReceptionistService.prototype.receptionistListObservable = function () {
        return this.receptionist_fetched_event_emitter.asObservable();
    };
    ReceptionistService.prototype.getReceptionistList = function () {
        var _this = this;
        this.httpc.get(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + '/receptionists')
            .subscribe(function (resultdata) {
            _this.receptionist_list = resultdata.rlist;
            _this.receptionist_fetched_event_emitter.next(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__spreadArrays"])(_this.receptionist_list));
        });
    };
    ReceptionistService.prototype.deleteReceptionist = function (id) {
        return this.httpc.delete(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + '/receptionists/' + id);
    };
    ReceptionistService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
        { type: angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__["FlashMessagesService"] }
    ]; };
    ReceptionistService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__["FlashMessagesService"]])
    ], ReceptionistService);
    return ReceptionistService;
}());



/***/ }),

/***/ "./src/app/slides/slides.component.css":
/*!*********************************************!*\
  !*** ./src/app/slides/slides.component.css ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".item{\r\n  background: #333;\r\n  text-align: center;\r\n\r\n}\r\n.carousel{\r\n  margin-top: 2px;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2xpZGVzL3NsaWRlcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGtCQUFrQjs7QUFFcEI7QUFDQTtFQUNFLGVBQWU7QUFDakIiLCJmaWxlIjoic3JjL2FwcC9zbGlkZXMvc2xpZGVzLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaXRlbXtcclxuICBiYWNrZ3JvdW5kOiAjMzMzO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHJcbn1cclxuLmNhcm91c2Vse1xyXG4gIG1hcmdpbi10b3A6IDJweDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "./src/app/slides/slides.component.ts":
/*!********************************************!*\
  !*** ./src/app/slides/slides.component.ts ***!
  \********************************************/
/*! exports provided: SlidesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SlidesComponent", function() { return SlidesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");


var SlidesComponent = /** @class */ (function () {
    function SlidesComponent() {
    }
    SlidesComponent.prototype.ngOnInit = function () {
    };
    SlidesComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-slides',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./slides.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/slides/slides.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./slides.component.css */ "./src/app/slides/slides.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [])
    ], SlidesComponent);
    return SlidesComponent;
}());



/***/ }),

/***/ "./src/app/specialists/specialist-create/specialist-create.component.css":
/*!*******************************************************************************!*\
  !*** ./src/app/specialists/specialist-create/specialist-create.component.css ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NwZWNpYWxpc3RzL3NwZWNpYWxpc3QtY3JlYXRlL3NwZWNpYWxpc3QtY3JlYXRlLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/specialists/specialist-create/specialist-create.component.ts":
/*!******************************************************************************!*\
  !*** ./src/app/specialists/specialist-create/specialist-create.component.ts ***!
  \******************************************************************************/
/*! exports provided: SpecialistCreateComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SpecialistCreateComponent", function() { return SpecialistCreateComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var _stypes_stype_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../stypes/stype.service */ "./src/app/stypes/stype.service.ts");
/* harmony import */ var _specialist_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../specialist.service */ "./src/app/specialists/specialist.service.ts");
/* harmony import */ var _errors_custom_validator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../errors/custom-validator */ "./src/app/errors/custom-validator.ts");
/* harmony import */ var _angular_google_maps__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/google-maps */ "./node_modules/@angular/google-maps/__ivy_ngcc__/fesm5/google-maps.js");







var SpecialistCreateComponent = /** @class */ (function () {
    function SpecialistCreateComponent(fb, elementRef, stypeservice, sservice) {
        this.fb = fb;
        this.elementRef = elementRef;
        this.stypeservice = stypeservice;
        this.sservice = sservice;
        this.markers = [];
        this.zoom = 17;
        this.options = {
            mapTypeId: 'hybrid',
            zoomControl: true,
            scrollwheel: false,
            disableDoubleClickZoom: true,
            maxZoom: 15,
            minZoom: 4,
        };
        this.slist = [];
    }
    SpecialistCreateComponent.prototype.ngOnInit = function () {
        var _this = this;
        navigator.geolocation.getCurrentPosition(function (position) {
            _this.center = {
                lat: -37.814703,
                lng: 144.965723
            };
        });
        this.stypeservice.getallstype();
        this.slist_reciever = this.stypeservice.stypeListObservable()
            .subscribe(function (slist) {
            _this.slist = slist;
        });
        this.myform = this.fb.group({
            'inputFname': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputLname': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(1)]),
            'inputUname': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(4)]),
            'inputPass': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(4)]),
            'inputPhone': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(10), _errors_custom_validator__WEBPACK_IMPORTED_MODULE_5__["CustomValidators"].apptelephoneNumbers]),
            'inputEmail': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email]),
            'inputGender': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputStype': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputQualification': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputLatitude': this.fb.control(''),
            'inputLongitude': this.fb.control('')
        });
    };
    SpecialistCreateComponent.prototype.click = function (event) {
        this.markers = [];
        console.log(event.latLng.lat().toFixed(4));
        console.log(event.latLng.lng().toFixed(4));
        this.myform.patchValue({ 'inputLatitude': event.latLng.lat().toFixed(4) });
        this.myform.get('inputLatitude').updateValueAndValidity();
        this.myform.patchValue({ 'inputLongitude': event.latLng.lng().toFixed(4) });
        this.myform.get('inputLongitude').updateValueAndValidity();
        this.markers.push({
            position: event.latLng,
            label: {
                color: 'red',
            },
            title: 'Your Location ' + (this.markers.length + 1),
            options: { animation: google.maps.Animation.BOUNCE },
        });
        //this.addMarker();
    };
    SpecialistCreateComponent.prototype.ngOnDestroy = function () {
        this.slist_reciever.unsubscribe();
    };
    SpecialistCreateComponent.prototype.onSubmit = function () {
        this.sservice.addnewSpecialist(this.myform.value);
        this.myform.reset();
    };
    SpecialistCreateComponent.ctorParameters = function () { return [
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"] },
        { type: _stypes_stype_service__WEBPACK_IMPORTED_MODULE_3__["StypeService"] },
        { type: _specialist_service__WEBPACK_IMPORTED_MODULE_4__["SpecialistService"] }
    ]; };
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_google_maps__WEBPACK_IMPORTED_MODULE_6__["GoogleMap"], { static: false }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", _angular_google_maps__WEBPACK_IMPORTED_MODULE_6__["GoogleMap"])
    ], SpecialistCreateComponent.prototype, "map", void 0);
    SpecialistCreateComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-specialist-create',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./specialist-create.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/specialists/specialist-create/specialist-create.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./specialist-create.component.css */ "./src/app/specialists/specialist-create/specialist-create.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"],
            _stypes_stype_service__WEBPACK_IMPORTED_MODULE_3__["StypeService"], _specialist_service__WEBPACK_IMPORTED_MODULE_4__["SpecialistService"]])
    ], SpecialistCreateComponent);
    return SpecialistCreateComponent;
}());



/***/ }),

/***/ "./src/app/specialists/specialist-list/specialist-list.component.css":
/*!***************************************************************************!*\
  !*** ./src/app/specialists/specialist-list/specialist-list.component.css ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NwZWNpYWxpc3RzL3NwZWNpYWxpc3QtbGlzdC9zcGVjaWFsaXN0LWxpc3QuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/specialists/specialist-list/specialist-list.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/specialists/specialist-list/specialist-list.component.ts ***!
  \**************************************************************************/
/*! exports provided: SpecialistListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SpecialistListComponent", function() { return SpecialistListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _specialist_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../specialist.service */ "./src/app/specialists/specialist.service.ts");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! angular2-flash-messages */ "./node_modules/angular2-flash-messages/__ivy_ngcc__/module/index.js");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__);




var SpecialistListComponent = /** @class */ (function () {
    // tslint:disable-next-line:variable-name
    function SpecialistListComponent(sservice, _flashMessagesService) {
        this.sservice = sservice;
        this._flashMessagesService = _flashMessagesService;
        this.SpecialisttList = [];
    }
    SpecialistListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.sservice.getSpecialistList();
        this.SListSubcriber = this.sservice.specialistListObservable()
            .subscribe(function (listdata) {
            _this.SpecialisttList = listdata;
        });
    };
    SpecialistListComponent.prototype.deleteSpecialist = function (iid) {
        var _this = this;
        if (confirm('Are You Sure Do U want to Delete Submission')) {
            this.sservice.deleteSpecialist(iid)
                .subscribe(function (result) {
                _this.sservice.getSpecialistList();
                _this._flashMessagesService.show('Specialist Deleted !', { cssClass: 'alert-success', timeout: 5000 });
            });
        }
    };
    SpecialistListComponent.ctorParameters = function () { return [
        { type: _specialist_service__WEBPACK_IMPORTED_MODULE_2__["SpecialistService"] },
        { type: angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__["FlashMessagesService"] }
    ]; };
    SpecialistListComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-specialist-list',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./specialist-list.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/specialists/specialist-list/specialist-list.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./specialist-list.component.css */ "./src/app/specialists/specialist-list/specialist-list.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_specialist_service__WEBPACK_IMPORTED_MODULE_2__["SpecialistService"], angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__["FlashMessagesService"]])
    ], SpecialistListComponent);
    return SpecialistListComponent;
}());



/***/ }),

/***/ "./src/app/specialists/specialist.service.ts":
/*!***************************************************!*\
  !*** ./src/app/specialists/specialist.service.ts ***!
  \***************************************************/
/*! exports provided: SpecialistService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SpecialistService", function() { return SpecialistService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/http.js");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! angular2-flash-messages */ "./node_modules/angular2-flash-messages/__ivy_ngcc__/module/index.js");
/* harmony import */ var angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");






var SpecialistService = /** @class */ (function () {
    // tslint:disable-next-line:variable-name
    function SpecialistService(httpc, _flashMessagesService) {
        this.httpc = httpc;
        this._flashMessagesService = _flashMessagesService;
        // tslint:disable-next-line:variable-name
        this.specialist_list = [];
        // tslint:disable-next-line:variable-name
        this.specialist_fetched_event_emitter = new rxjs__WEBPACK_IMPORTED_MODULE_4__["Subject"]();
    }
    SpecialistService.prototype.addnewSpecialist = function (formdata) {
        var _this = this;
        this.httpc.post(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + '/specialists', formdata)
            .subscribe(function (result) {
            _this._flashMessagesService.show('Specialist Added Successfully', { cssClass: 'alert-success', timeout: 5000 });
        });
    };
    SpecialistService.prototype.specialistListObservable = function () {
        return this.specialist_fetched_event_emitter.asObservable();
    };
    SpecialistService.prototype.getSpecialistList = function () {
        var _this = this;
        this.httpc.get(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + '/specialists')
            .subscribe(function (resultdata) {
            _this.specialist_list = resultdata.slist;
            _this.specialist_fetched_event_emitter.next(Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__spreadArrays"])(_this.specialist_list));
        });
    };
    SpecialistService.prototype.getSpecialistListForMap = function () {
        return this.httpc.get(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + '/specialists');
    };
    SpecialistService.prototype.deleteSpecialist = function (id) {
        return this.httpc.delete(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url + '/specialists/' + id);
    };
    SpecialistService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
        { type: angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__["FlashMessagesService"] }
    ]; };
    SpecialistService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], angular2_flash_messages__WEBPACK_IMPORTED_MODULE_3__["FlashMessagesService"]])
    ], SpecialistService);
    return SpecialistService;
}());



/***/ }),

/***/ "./src/app/stypes/stype.service.ts":
/*!*****************************************!*\
  !*** ./src/app/stypes/stype.service.ts ***!
  \*****************************************/
/*! exports provided: StypeService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StypeService", function() { return StypeService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm5/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");





var StypeService = /** @class */ (function () {
    function StypeService(httpc) {
        this.httpc = httpc;
        this.stypeemitter = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
    }
    StypeService.prototype.stypeListObservable = function () {
        return this.stypeemitter.asObservable();
    };
    StypeService.prototype.getallstype = function () {
        var _this = this;
        this.httpc.get(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url + '/stypes')
            .subscribe(function (result) {
            _this.stypeemitter.next(result.slist);
        });
    };
    StypeService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
    ]; };
    StypeService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], StypeService);
    return StypeService;
}());



/***/ }),

/***/ "./src/app/top-menus/top-menus.component.css":
/*!***************************************************!*\
  !*** ./src/app/top-menus/top-menus.component.css ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RvcC1tZW51cy90b3AtbWVudXMuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/top-menus/top-menus.component.ts":
/*!**************************************************!*\
  !*** ./src/app/top-menus/top-menus.component.ts ***!
  \**************************************************/
/*! exports provided: TopMenusComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TopMenusComponent", function() { return TopMenusComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");


var TopMenusComponent = /** @class */ (function () {
    function TopMenusComponent() {
    }
    TopMenusComponent.prototype.ngOnInit = function () {
    };
    TopMenusComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-top-menus',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./top-menus.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/top-menus/top-menus.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./top-menus.component.css */ "./src/app/top-menus/top-menus.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [])
    ], TopMenusComponent);
    return TopMenusComponent;
}());



/***/ }),

/***/ "./src/app/top-navigation/top-navigation.component.css":
/*!*************************************************************!*\
  !*** ./src/app/top-navigation/top-navigation.component.css ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".navigation {background:#D4C3C8;}\r\n.navigation ul.sf-menu {margin:0;}\r\n.navigation ul.sf-menu li {background:none;border:0;}\r\n.navigation ul.sf-menu li a:hover{ text-decoration: none;\tbackground:#D4C3C8;\tcolor:#fff;}\r\n.navigation ul.sf-menu li a{background:none;border:0;padding:1em 1.3em;color:#000;font-size:1.3em;text-transform:uppercase;font-weight:700;letter-spacing: 1px;}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdG9wLW5hdmlnYXRpb24vdG9wLW5hdmlnYXRpb24uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxhQUFhLGtCQUFrQixDQUFDO0FBQ2hDLHdCQUF3QixRQUFRLENBQUM7QUFDakMsMkJBQTJCLGVBQWUsQ0FBQyxRQUFRLENBQUM7QUFDcEQsbUNBQW1DLHFCQUFxQixFQUFFLGtCQUFrQixFQUFFLFVBQVUsQ0FBQztBQUN6Riw0QkFBNEIsZUFBZSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLHdCQUF3QixDQUFDLGVBQWUsQ0FBQyxtQkFBbUIsQ0FBQyIsImZpbGUiOiJzcmMvYXBwL3RvcC1uYXZpZ2F0aW9uL3RvcC1uYXZpZ2F0aW9uLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubmF2aWdhdGlvbiB7YmFja2dyb3VuZDojRDRDM0M4O31cclxuLm5hdmlnYXRpb24gdWwuc2YtbWVudSB7bWFyZ2luOjA7fVxyXG4ubmF2aWdhdGlvbiB1bC5zZi1tZW51IGxpIHtiYWNrZ3JvdW5kOm5vbmU7Ym9yZGVyOjA7fVxyXG4ubmF2aWdhdGlvbiB1bC5zZi1tZW51IGxpIGE6aG92ZXJ7IHRleHQtZGVjb3JhdGlvbjogbm9uZTtcdGJhY2tncm91bmQ6I0Q0QzNDODtcdGNvbG9yOiNmZmY7fVxyXG4ubmF2aWdhdGlvbiB1bC5zZi1tZW51IGxpIGF7YmFja2dyb3VuZDpub25lO2JvcmRlcjowO3BhZGRpbmc6MWVtIDEuM2VtO2NvbG9yOiMwMDA7Zm9udC1zaXplOjEuM2VtO3RleHQtdHJhbnNmb3JtOnVwcGVyY2FzZTtmb250LXdlaWdodDo3MDA7bGV0dGVyLXNwYWNpbmc6IDFweDt9XHJcbiJdfQ== */");

/***/ }),

/***/ "./src/app/top-navigation/top-navigation.component.ts":
/*!************************************************************!*\
  !*** ./src/app/top-navigation/top-navigation.component.ts ***!
  \************************************************************/
/*! exports provided: TopNavigationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TopNavigationComponent", function() { return TopNavigationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../auth/auth.service */ "./src/app/auth/auth.service.ts");



var TopNavigationComponent = /** @class */ (function () {
    function TopNavigationComponent(authservice) {
        this.authservice = authservice;
        this.isAuthenticated = false;
        this.user_role = -1;
    }
    TopNavigationComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.isAuthenticated = this.authservice.getAuthStatus();
        this.AuthSubcription = this.authservice.getAuthStatusListener()
            .subscribe(function (authData) {
            _this.isAuthenticated = authData.loginstatus;
            _this.user_role = authData.user_role;
        });
    };
    TopNavigationComponent.prototype.ngOnDestroy = function () {
        this.AuthSubcription.unsubscribe();
    };
    TopNavigationComponent.prototype.onLogout = function () {
        this.authservice.logout();
    };
    TopNavigationComponent.ctorParameters = function () { return [
        { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] }
    ]; };
    TopNavigationComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-top-navigation',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./top-navigation.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/top-navigation/top-navigation.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./top-navigation.component.css */ "./src/app/top-navigation/top-navigation.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]])
    ], TopNavigationComponent);
    return TopNavigationComponent;
}());



/***/ }),

/***/ "./src/app/users/user-create/user-create.component.css":
/*!*************************************************************!*\
  !*** ./src/app/users/user-create/user-create.component.css ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3VzZXJzL3VzZXItY3JlYXRlL3VzZXItY3JlYXRlLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/users/user-create/user-create.component.ts":
/*!************************************************************!*\
  !*** ./src/app/users/user-create/user-create.component.ts ***!
  \************************************************************/
/*! exports provided: UserCreateComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserCreateComponent", function() { return UserCreateComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/auth/auth.service */ "./src/app/auth/auth.service.ts");




var UserCreateComponent = /** @class */ (function () {
    function UserCreateComponent(fb, aservice) {
        this.fb = fb;
        this.aservice = aservice;
    }
    UserCreateComponent.prototype.ngOnInit = function () {
        this.myform = this.fb.group({
            'inputFname': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputLname': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputUname': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputPass': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]),
            'inputEmail': this.fb.control('', [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email])
        });
    };
    UserCreateComponent.prototype.onSubmit = function () {
        this.aservice.addnewuser(this.myform.value);
        this.myform.reset();
    };
    UserCreateComponent.ctorParameters = function () { return [
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
        { type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] }
    ]; };
    UserCreateComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-user-create',
            template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./user-create.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/users/user-create/user-create.component.html")).default,
            styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./user-create.component.css */ "./src/app/users/user-create/user-create.component.css")).default]
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]])
    ], UserCreateComponent);
    return UserCreateComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false,
    // url: 'http://localhost:3000/api'
    url: 'http://patientconfidentiality-env.eba-fhxapmig.us-east-1.elasticbeanstalk.com/api'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/__ivy_ngcc__/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\Projects2019\PatientConfidentialityWithEncryption\PatientConfidentiality\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map