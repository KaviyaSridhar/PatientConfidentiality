export const environment = {
  production: false,
  url: 'http://patientconfidentiality-env.2x8g2gfvgn.us-east-2.elasticbeanstalk.com/api'
};
