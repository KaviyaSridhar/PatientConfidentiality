import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpecPrerecordCreateComponent } from './spec-prerecord-create.component';

describe('SpecPrerecordCreateComponent', () => {
  let component: SpecPrerecordCreateComponent;
  let fixture: ComponentFixture<SpecPrerecordCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpecPrerecordCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpecPrerecordCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
