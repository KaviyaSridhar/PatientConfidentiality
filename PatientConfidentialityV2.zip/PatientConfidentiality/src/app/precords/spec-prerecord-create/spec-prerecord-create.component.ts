import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PatientService } from 'src/app/patients/patient.service';
import { FlashMessagesService } from 'angular2-flash-messages';

@Component({
  selector: 'app-spec-prerecord-create',
  templateUrl: './spec-prerecord-create.component.html',
  styleUrls: ['./spec-prerecord-create.component.css']
})
export class SpecPrerecordCreateComponent implements OnInit {

  constructor(private fb: FormBuilder,
    private pservice: PatientService,
    private _flashMessagesService: FlashMessagesService) { }

myform: FormGroup;

myform1: FormGroup;

patient_id:string;

patient_data:any=null;

filesToUpload: Array<File> = [];

ngOnInit() {

this.myform = this.fb.group({
'inputPuid': this.fb.control('', [Validators.required])


});



this.myform1 = this.fb.group({
'inputChospital': this.fb.control('', [Validators.required]),
'inputCdoctor': this.fb.control('', [Validators.required]),
'inputDescription':this.fb.control('', [Validators.required]),
});

}

onSearch() {
this.patient_data=null;
this.pservice.searchPatientDetails(this.myform.value.inputPuid)
       .subscribe(result=>{
         console.log(result);
         this.patient_data=result.pdata[0];
       })

}

fileChangeEvent(fileInput: any) {
this.filesToUpload = <Array<File>>fileInput.target.files;
}

onFormSubmit(){
const userdata = new FormData();
console.log(this.patient_data._id);
userdata.append('pid', this.patient_data._id);
userdata.append('inputChospital', this.myform1.value.inputChospital);
userdata.append('inputCdoctor', this.myform1.value.inputCdoctor);
userdata.append('inputDescription', this.myform1.value.inputDescription);
console.log(userdata);
const files: Array<File> = this.filesToUpload;
for(let i =0; i < files.length; i++){
userdata.append("uploads[]", files[i], files[i]['name']);
}
console.log(userdata.toString());
this.pservice.addSpecialistPatientrecord(userdata)
       .subscribe((result)=>{
        this._flashMessagesService.show('Patient Record Added Successfully', { cssClass: 'alert-success', timeout: 5000 });
        this.myform1.reset();
        this.patient_id = null;
        this.patient_data = null;
        this.filesToUpload = [];
        this.myform.reset();
       })
}

}
