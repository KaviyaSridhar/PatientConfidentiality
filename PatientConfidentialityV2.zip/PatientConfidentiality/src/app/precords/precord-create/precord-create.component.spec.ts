import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrecordCreateComponent } from './precord-create.component';

describe('PrecordCreateComponent', () => {
  let component: PrecordCreateComponent;
  let fixture: ComponentFixture<PrecordCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrecordCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrecordCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
