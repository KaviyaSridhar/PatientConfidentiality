import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Auth } from './auth.model';
import { Subject } from 'rxjs';
import { Router } from '@angular/router';
import {environment} from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {


  private token;
  private userid;
  private user_role:number;
  private tokenexptimer: any;
  private isAuthenticated = false;
  public AuthStatusEmitter = new Subject<{loginstatus:boolean,user_role:number}>();

  constructor(private httpc: HttpClient,
              private _flashMessagesService: FlashMessagesService,
              private router: Router) { }


  getAuthStatus() {
    return this.isAuthenticated;
  }

  getToken() {
    return this.token;
  }

  getUserId() {
    return this.userid;
  }

  getAuthStatusListener() {
    return this.AuthStatusEmitter.asObservable();
  }


  addnewuser(formdata: any) {

    this.httpc.post<{message: string,userid: string}>(environment.url + '/users', formdata)
    .subscribe((result) => {
                this._flashMessagesService.show('User Added Successfully', { cssClass: 'alert-success', timeout: 5000 });

    });

  }

  userlogin(username: string, password: string,ltype:string) {
    const authdata: any = {
      username : username,
      password : password,
      ltype:ltype
    };
    this.httpc.post<{token: string, expiresIn: number, userid: string,user_role:number}>(environment.url + '/users/login', authdata)
   .subscribe((result) => {
               console.log(result);
               this._flashMessagesService.show('User Login Successfull', { cssClass: 'alert-success', timeout: 5000 });
               if (result) {
                 this.token = result.token;
                 this.user_role = result.user_role;
                 const timervalue = result.expiresIn;
                 this.setAuthotimer(timervalue);
                 this.isAuthenticated = true;
                 const current_date = new Date();
                 const exp_date = new Date(current_date.getTime() + timervalue * 1000);
                 this.userid = result.userid;
                 this.saveAuthDataLocal(this.token , exp_date, this.userid,this.user_role);
                 this.AuthStatusEmitter.next(
                                {
                                  loginstatus:true,
                                  user_role:this.user_role
                                });
                 this.router.navigate(['/']);
               }
    },
    error=>{
     this.AuthStatusEmitter.next({
      loginstatus:false,
      user_role:-1
    });
    });
  }

  AutoAuthUser() {
    const AuthLocalData = this.getAuthData();
    const now = new Date();

    if (AuthLocalData) {
      const expiresIn = AuthLocalData.expIntime.getTime() - now.getTime();
      if (expiresIn > 0 ) {
        this.token = AuthLocalData.token;
        this.isAuthenticated = true;
        console.log("THE IS AUTHIS "+this.isAuthenticated);
        this.user_role = parseInt(AuthLocalData.user_role);
        this.setAuthotimer(expiresIn / 1000);
        this.AuthStatusEmitter.next(
          {
            loginstatus:true,
            user_role:this.user_role
          });
      }
    }

  }

  private saveAuthDataLocal(token: string, expiresInDate: Date, userid: string,user_role:number) {
    localStorage.setItem('token', token);
    localStorage.setItem('userid', userid);
    localStorage.setItem('user_role', user_role.toString());
    localStorage.setItem('expirationDate', expiresInDate.toISOString());
  }

  private getAuthData() {
    const token = localStorage.getItem('token');
    const expIntime = localStorage.getItem('expirationDate');
    const userid = localStorage.getItem('userid');
    const user_role = localStorage.getItem('user_role');
    if (!token || !expIntime) {
      return;
    }
    return {
      token: token,
      expIntime : new Date(expIntime),
      userid : userid,
      user_role : user_role
    };
  }

  private clearAuthData() {
    localStorage.removeItem('token');
    localStorage.removeItem('userid');
    localStorage.removeItem('expirationDate');
    localStorage.removeItem('user_role');
  }

  private setAuthotimer(duration: number) {
    setTimeout(() => {
      this.logout();
    }, duration * 1000);
  }

  logout() {
     this.isAuthenticated = false;
     this.token = null;
     this.userid = null;
     this.AuthStatusEmitter.next({
      loginstatus:false,
      user_role:-1
     });
     clearTimeout(this.tokenexptimer);
     this.clearAuthData();
     this.router.navigate(['/login']);
  }




}
