import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private fb: FormBuilder,
              private authservice: AuthService) { }

  myform: FormGroup;

  ngOnInit() {
    this.myform = this.fb.group({
      'inputUsername' : this.fb.control('',[Validators.required]),
      'inputPassword' : this.fb.control('',[Validators.required]),
      'inputStype' : this.fb.control('',[Validators.required]),
    });
  }

  onLogin() {
    if (this.myform.invalid) {
      return;
    }
    this.authservice.userlogin(this.myform.value.inputUsername, this.myform.value.inputPassword,this.myform.value.inputStype);
  }

}
