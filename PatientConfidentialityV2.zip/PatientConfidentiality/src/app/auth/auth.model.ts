export interface Auth {
  username : string;
  password : string;
  role : number;
}
