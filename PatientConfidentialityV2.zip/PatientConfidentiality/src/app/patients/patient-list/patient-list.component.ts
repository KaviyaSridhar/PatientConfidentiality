import { Component, OnInit } from '@angular/core';
import { PatientService } from '../patient.service';
import { FlashMessagesService } from 'angular2-flash-messages/module/flash-messages.service';
import { Patient } from './patient.model';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-patient-list',
  templateUrl: './patient-list.component.html',
  styleUrls: ['./patient-list.component.css']
})
export class PatientListComponent implements OnInit {

  // tslint:disable-next-line:variable-name
  constructor(private pservice: PatientService, private _flashMessagesService: FlashMessagesService) { }

  PatientList: Patient[] = [];

  PListSubcriber: Subscription;

  ngOnInit() {
    this.pservice.getPatientList();
    this.PListSubcriber = this.pservice.patientListObservable()
                                       .subscribe((listdata) => {
                                          this.PatientList = listdata;
                                       });


  }

  deletePatient(iid: string) {
    if (confirm('Are You Sure Do U want to Delete Submission')) {
       this.pservice.deletePatient(iid)
                    .subscribe((result) => {
                        this.pservice.getPatientList();
                        this._flashMessagesService.show('Patient Deleted !', { cssClass: 'alert-success', timeout: 5000 });

                     });
    }
  }

}
