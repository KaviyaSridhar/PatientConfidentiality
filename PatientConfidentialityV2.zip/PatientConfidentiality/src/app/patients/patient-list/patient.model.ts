export interface Patient {
  _id: string;
  inputFname: string;
  inputLname: string;
  inputAid: string;
  inputPhone: string;
  inputEmail: string;
  inputAge: string;
  inputGender: string;
  inputAddress: string;
  }
