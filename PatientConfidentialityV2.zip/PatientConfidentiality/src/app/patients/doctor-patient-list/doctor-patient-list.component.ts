import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PatientService } from '../patient.service';
import { FlashMessagesService } from 'angular2-flash-messages';

@Component({
  selector: 'app-doctor-patient-list',
  templateUrl: './doctor-patient-list.component.html',
  styleUrls: ['./doctor-patient-list.component.css']
})
export class DoctorPatientListComponent implements OnInit {

  constructor(private fb: FormBuilder, private pservice: PatientService, private _flashMessagesService: FlashMessagesService) { }
  myform: FormGroup;

  // tslint:disable-next-line:variable-name
  patient_id: string;

// tslint:disable-next-line:variable-name
patient_data: any = null;


  ngOnInit() {
    this.myform = this.fb.group({
      'inputPuid': this.fb.control('', [Validators.required])
      });


  }

  onSearch() {
    this.patient_data = null;
    this.pservice.searchPatientDetailsforDcotor(this.myform.value.inputPuid)
           .subscribe(result => {
             console.log(result);
             this.patient_data = result.pdata[0];
             var updatemprecords=[];
             this.patient_data.mprecords.forEach(element => {
               let newfilesset = [];
               this.patient_data.mpfiles.forEach(file => {
                 if(file.inputRid===element._id){
                  newfilesset.push({inputFilename:file.inputFilename,
                                    inputUrl:file.inputURL});
                 }
               });
               element.files=newfilesset;
               updatemprecords.push(element);
             });
             this.patient_data.mprecords = updatemprecords;
             this.patient_data.mpfiles = null;
           });

}

}
