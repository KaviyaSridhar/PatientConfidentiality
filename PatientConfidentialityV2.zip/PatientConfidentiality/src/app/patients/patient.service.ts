import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { FlashMessagesService } from "angular2-flash-messages";
import { Patient } from "./patient-list/patient.model";
import { Subject } from "rxjs";
import { environment } from "../../environments/environment";

@Injectable({
  providedIn: "root"
})
export class PatientService {
  // tslint:disable-next-line:variable-name
  constructor(
    private httpc: HttpClient,
    private _flashMessagesService: FlashMessagesService
  ) {}

  // tslint:disable-next-line:variable-name
  patient_list: Patient[] = [];

  // tslint:disable-next-line:variable-name
  patient_fetched_event_emitter = new Subject<Patient[]>();

  addnewPatient(formdata: any) {
    this.httpc
      .post<{ message: string; _id: string }>(
        environment.url + "/patients",
        formdata
      )
      .subscribe(result => {
        this._flashMessagesService.show("Patient Added Successfully", {
          cssClass: "alert-success",
          timeout: 5000
        });
      });
  }

  patientListObservable() {
    return this.patient_fetched_event_emitter.asObservable();
  }

  getPatientList() {
    this.httpc
      .get<{ message: string; plist: Patient[] }>(environment.url + "/patients")
      .subscribe(resultdata => {
        this.patient_list = resultdata.plist;
        this.patient_fetched_event_emitter.next([...this.patient_list]);
      });
  }

  deletePatient(id: string) {
    return this.httpc.delete<{ message: string }>(
      environment.url + "/patients/" + id
    );
  }

  getSinglePatientDetails(pid: string) {
    return this.httpc.get<{ message: string; pdata: any }>(
      environment.url + "/patients/" + pid
    );
  }

  searchPatientDetails(patient_auid: string) {
    return this.httpc.get<{ message: string; pdata: any }>(
      environment.url + "/patients/search/" + patient_auid
    );
  }

  searchPatientDetailsforDcotor(patient_auid: string) {
    return this.httpc.get<{ message: string; pdata: any }>(
      environment.url + "/patients/search/doctors/" + patient_auid
    );
  }

  addPatientrecord(formdata:any) {
    console.log(formdata);
    return this.httpc.post<{ message: string; pdata: any }>(
      environment.url + "/patients/precords", formdata
    );
  }

  addSpecialistPatientrecord(formdata:any) {
    console.log(formdata);
    return this.httpc.post<{ message: string; pdata: any }>(
      environment.url + "/patients/precords/specialist", formdata
    );
  }

}
