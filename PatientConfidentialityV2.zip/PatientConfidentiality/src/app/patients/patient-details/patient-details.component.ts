import { Component, OnInit } from '@angular/core';
import { PatientView } from './patient.model';
import { PatientService } from '../patient.service';
import { ParamMap, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-patient-details',
  templateUrl: './patient-details.component.html',
  styleUrls: ['./patient-details.component.css']
})
export class PatientDetailsComponent implements OnInit {

  constructor( public routes: ActivatedRoute, private patientservice: PatientService) { }

  pid: string;
  patientdetails: any ;
  isLoading = false;

  ngOnInit() {
    console.log('Hello');
    this.isLoading = true;
    this.routes.paramMap.subscribe((parammap: ParamMap) => {
      if (parammap.has('pid')) {
        this.pid = parammap.get('pid');
        console.log(this.pid);
        this.patientservice.getSinglePatientDetails(this.pid)
                         .subscribe((resultd) => {

                          this.patientdetails = resultd.pdata;
                          console.log(this.patientdetails);
                          this.isLoading = false;
                        });
                      }
                    });

  }

}
