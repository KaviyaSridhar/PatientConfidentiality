export interface PatientView {
  inputFname: string;
  inputLname: string;
  inputAid: string;
  inputPhone: string;
  inputEmail: string;
  inputAge: string;
  inputGender: string;
  inputAddress: string;

}
