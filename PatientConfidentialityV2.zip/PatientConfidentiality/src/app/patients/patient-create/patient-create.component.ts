import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup, } from '@angular/forms';
import { PatientService } from '../patient.service';
import { CustomValidators } from '../../errors/custom-validator';


@Component({
  selector: 'app-patient-create',
  templateUrl: './patient-create.component.html',
  styleUrls: ['./patient-create.component.css']
})
export class PatientCreateComponent implements OnInit {

  constructor(private fb: FormBuilder, private pservice: PatientService) { }

  myform: FormGroup;

  ngOnInit() {


    this.myform = this.fb.group({
      'inputPuid' : this.fb.control('', [Validators.required]),
      'inputFname': this.fb.control('', [Validators.required, Validators.minLength(3)]),
      'inputLname' : this.fb.control('', [Validators.required, Validators.minLength(3)]),
      'inputAid' : this.fb.control('', [Validators.required]),
      'inputPhone' : this.fb.control('', [Validators.required, Validators.minLength(10), CustomValidators.apptelephoneNumbers]),
      'inputEmail' : this.fb.control('', [Validators.required, Validators.email]),
      'inputAge' : this.fb.control('', [Validators.required]),
      'inputGender' : this.fb.control('', [Validators.required]),
      'inputAddress' : this.fb.control('', [Validators.required])
    });
  }

  onSubmit() {
    this.pservice.addnewPatient(this.myform.value);
    this.myform.reset();
   }


}
