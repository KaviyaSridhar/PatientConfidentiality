import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {PatientCreateComponent} from './patients/patient-create/patient-create.component';
import { UserCreateComponent } from './users/user-create/user-create.component';
import { ReceptionistCreateComponent } from './receptionists/receptionist-create/receptionist-create.component';
import { PrecordCreateComponent } from './precords/precord-create/precord-create.component';
import { DoctorCreateComponent } from './doctors/doctor-create/doctor-create.component';
import { SpecialistCreateComponent } from './specialists/specialist-create/specialist-create.component';
import { DoctorListComponent } from './doctors/doctor-list/doctor-list.component';
import { PatientListComponent } from './patients/patient-list/patient-list.component';
import { ReceptionistListComponent } from './receptionists/receptionist-list/receptionist-list.component';
import { SpecialistListComponent } from './specialists/specialist-list/specialist-list.component';
import { PatientDetailsComponent } from './patients/patient-details/patient-details.component';
import { LoginComponent } from './auth/login/login.component';
import { SpecPrerecordCreateComponent } from './precords/spec-prerecord-create/spec-prerecord-create.component';
import { DoctorPatientListComponent } from './patients/doctor-patient-list/doctor-patient-list.component';
import { AboutProjectComponent } from './doctors/pages/about-project/about-project.component';
import { AboutUsComponent } from './doctors/pages/about-us/about-us.component';
import { ContactUsComponent } from './doctors/pages/contact-us/contact-us.component';
import { MapviewComponent } from './doctors/pages/mapview/mapview.component';

const routes: Routes = [

    {path: 'patients', component: PatientCreateComponent},
    {path: 'users', component: UserCreateComponent},
    {path: 'receptionists', component: ReceptionistCreateComponent},
    {path: 'precords', component: PrecordCreateComponent},
    {path: 'doctors', component: DoctorCreateComponent},
    {path: 'specialists', component: SpecialistCreateComponent},
    {path: 'doctors-list', component : DoctorListComponent},
    {path: 'patients-list', component: PatientListComponent},
    {path: 'receptionists-list', component: ReceptionistListComponent},
    {path: 'specialists-list', component: SpecialistListComponent},
    {path: 'patientdetails/:pid', component: PatientDetailsComponent},
    {path: 'login', component: LoginComponent},
    {path: 'specialist-precords', component: SpecPrerecordCreateComponent},
    {path: 'doctor-patient-list', component: DoctorPatientListComponent},
    {path: 'about-project', component: AboutProjectComponent},
    {path: 'about-us', component: AboutUsComponent},
    {path: 'mapview', component: MapviewComponent},
    {path: 'contact-us', component: ContactUsComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
