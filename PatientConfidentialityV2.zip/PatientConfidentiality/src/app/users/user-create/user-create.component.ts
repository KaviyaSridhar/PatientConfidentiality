import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/auth/auth.service';

@Component({
  selector: 'app-user-create',
  templateUrl: './user-create.component.html',
  styleUrls: ['./user-create.component.css']
})
export class UserCreateComponent implements OnInit {

  constructor(private fb: FormBuilder, private aservice: AuthService) { }

  myform: FormGroup;

  ngOnInit() {
    this.myform = this.fb.group({
      'inputFname': this.fb.control('', [Validators.required]),
      'inputLname' : this.fb.control('', [Validators.required]),
      'inputUname' : this.fb.control('', [Validators.required]),
      'inputPass' : this.fb.control('', [Validators.required]),
      'inputEmail' : this.fb.control('', [Validators.required, Validators.email])

    });
  }

  onSubmit() {
    this.aservice.addnewuser(this.myform.value);
    this.myform.reset();
   }
}
