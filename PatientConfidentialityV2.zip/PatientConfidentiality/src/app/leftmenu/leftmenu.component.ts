import { Component, OnInit, OnDestroy } from "@angular/core";
import { Subscription } from "rxjs";
import { AuthService } from "../auth/auth.service";

@Component({
  selector: "app-leftmenu",
  templateUrl: "./leftmenu.component.html",
  styleUrls: ["./leftmenu.component.css"]
})
export class LeftmenuComponent implements OnInit, OnDestroy {
  isAuthenticated: boolean = false;
  user_role = -1;
  AuthSubcription: Subscription;

  constructor(private authservice: AuthService) {}

  ngOnInit() {
    this.isAuthenticated = this.authservice.getAuthStatus();
    this.AuthSubcription = this.authservice
      .getAuthStatusListener()
      .subscribe(authData => {
        this.isAuthenticated = authData.loginstatus;
        this.user_role = authData.user_role;
        console.log(
          "THE AUTH DATA IS : " +
            this.user_role +
            "AUTH IS " +
            this.isAuthenticated
        );
      });
  }

  onLogout() {
    this.authservice.logout();
  }

  ngOnDestroy() {
    this.AuthSubcription.unsubscribe();
  }
}
