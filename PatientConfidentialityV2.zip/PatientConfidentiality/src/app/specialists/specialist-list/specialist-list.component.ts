import { Component, OnInit } from '@angular/core';
import { SpecialistService } from '../specialist.service';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Specialist } from './specialist.model';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-specialist-list',
  templateUrl: './specialist-list.component.html',
  styleUrls: ['./specialist-list.component.css']
})
export class SpecialistListComponent implements OnInit {

  // tslint:disable-next-line:variable-name
  constructor(private sservice: SpecialistService, private _flashMessagesService: FlashMessagesService) { }

  SpecialisttList: Specialist[] = [];

  SListSubcriber: Subscription;

  ngOnInit() {

    this.sservice.getSpecialistList();
    this.SListSubcriber = this.sservice.specialistListObservable()
                                       .subscribe((listdata) => {
                                          this.SpecialisttList = listdata;
                                       });
  }

  deleteSpecialist(iid: string) {
    if (confirm('Are You Sure Do U want to Delete Submission')) {
       this.sservice. deleteSpecialist(iid)
                    .subscribe((result) => {
                        this.sservice.getSpecialistList();
                        this._flashMessagesService.show('Specialist Deleted !', { cssClass: 'alert-success', timeout: 5000 });

                     });
    }
  }

}
