export interface Specialist {
  _id: string;
  inputFname: string;
  inputLname: string;
  inputUname: string;
  inputPhone: string;
  inputEmail: string;
  inputGender: string;
  inputStype: string;
  inputQualification: string;

  }
