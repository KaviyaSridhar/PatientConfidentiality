import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder,  FormGroup, Validators } from '@angular/forms';
import { StypeService } from '../../stypes/stype.service';
import { Subscription } from 'rxjs';
import { SpecialistService } from '../specialist.service';
import { CustomValidators } from '../../errors/custom-validator';
import { GoogleMap } from '@angular/google-maps';

@Component({
  selector: 'app-specialist-create',
  templateUrl: './specialist-create.component.html',
  styleUrls: ['./specialist-create.component.css']
})
export class SpecialistCreateComponent implements OnInit, OnDestroy {
  @ViewChild(GoogleMap, { static: false }) map: GoogleMap
  constructor(private fb: FormBuilder, 
              private elementRef:ElementRef,
              private stypeservice: StypeService, private sservice: SpecialistService) { }


              markers = [];

              zoom = 17;
              center: google.maps.LatLngLiteral;
              options: google.maps.MapOptions = {
                mapTypeId: 'hybrid',
                zoomControl: true,
                scrollwheel: false,
                disableDoubleClickZoom: true,
                maxZoom: 15,
                minZoom: 4,
              }
  myform: FormGroup;

  slist = [];

  // tslint:disable-next-line:variable-name
  slist_reciever: Subscription;

  ngOnInit() {

    navigator.geolocation.getCurrentPosition(position => {
      this.center = {
        lat: -37.814703, 
        lng: 144.965723
      }
    })

  this.stypeservice.getallstype();

  this.slist_reciever = this.stypeservice.stypeListObservable()
                                         .subscribe((slist) => {
                                           this.slist = slist;
                                         });

  this.myform = this.fb.group({
      'inputFname': this.fb.control('', [Validators.required]),
      'inputLname' : this.fb.control('', [Validators.required, Validators.minLength(1)]),
      'inputUname' : this.fb.control('', [Validators.required, Validators.minLength(4)]),
      'inputPass' : this.fb.control('', [Validators.required, Validators.minLength(4)]),
      'inputPhone' : this.fb.control('', [Validators.required, Validators.minLength(10), CustomValidators.apptelephoneNumbers]),
      'inputEmail' : this.fb.control('', [Validators.required, Validators.email]),
      'inputGender' : this.fb.control('', [Validators.required]),
      'inputStype' : this.fb.control('', [Validators.required]),
      'inputQualification' : this.fb.control('', [Validators.required]),
      'inputLatitude' : this.fb.control(''),
      'inputLongitude' : this.fb.control('')
    });



  }

  click(event: google.maps.MouseEvent) {
    this.markers = [];
    console.log(event.latLng.lat().toFixed(4));
    console.log(event.latLng.lng().toFixed(4));
    this.myform.patchValue({'inputLatitude': event.latLng.lat().toFixed(4)});
    this.myform.get('inputLatitude').updateValueAndValidity();
    this.myform.patchValue({'inputLongitude': event.latLng.lng().toFixed(4)});
    this.myform.get('inputLongitude').updateValueAndValidity();
    this.markers.push({
      position: event.latLng
      ,
      label: {
        color: 'red',
        
      },
      title: 'Your Location ' + (this.markers.length + 1),
      options: { animation: google.maps.Animation.BOUNCE },
    })
    //this.addMarker();
  }

  ngOnDestroy() {
    this.slist_reciever.unsubscribe();
  }

  onSubmit() {
    this.sservice.addnewSpecialist(this.myform.value);
    this.myform.reset();
   }

}
