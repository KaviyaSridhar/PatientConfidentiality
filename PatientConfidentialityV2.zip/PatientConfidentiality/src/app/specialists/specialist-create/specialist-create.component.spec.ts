import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpecialistCreateComponent } from './specialist-create.component';

describe('SpecialistCreateComponent', () => {
  let component: SpecialistCreateComponent;
  let fixture: ComponentFixture<SpecialistCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpecialistCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpecialistCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
