import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Specialist } from './specialist-list/specialist.model';
import { Subject } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SpecialistService {

  // tslint:disable-next-line:variable-name
  constructor(private httpc: HttpClient, private _flashMessagesService: FlashMessagesService) { }

   // tslint:disable-next-line:variable-name
   specialist_list: Specialist[] = [];

   // tslint:disable-next-line:variable-name
   specialist_fetched_event_emitter = new Subject<Specialist[]>();

  addnewSpecialist(formdata: any) {
    this.httpc.post<{message: string, _id: string}>(environment.url + '/specialists', formdata)
             .subscribe((result) => {

               this._flashMessagesService.show('Specialist Added Successfully', { cssClass: 'alert-success', timeout: 5000 });

             });

           }
           specialistListObservable() {
            return this.specialist_fetched_event_emitter.asObservable();
          }

          getSpecialistList() {
            this.httpc.get<{ message: string, slist: Specialist[]}>(environment.url + '/specialists')
                      .subscribe((resultdata) => {
                        this.specialist_list = resultdata.slist;
                        this.specialist_fetched_event_emitter.next([...this.specialist_list]);

                      });
          }

          getSpecialistListForMap() {
            return this.httpc.get<{ message: string, slist: Specialist[]}>(environment.url + '/specialists')
                      
          }

          deleteSpecialist(id: string) {
            return this.httpc.delete<{ message: string}>(environment.url + '/specialists/' + id);
           }

}
