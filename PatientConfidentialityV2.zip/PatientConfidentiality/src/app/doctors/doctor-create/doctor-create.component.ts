import { Component, OnInit, ElementRef ,ViewChild} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DoctorService } from '../doctor.service';
import { CustomValidators } from '../../errors/custom-validator';
import { MapInfoWindow, MapMarker, GoogleMap } from '@angular/google-maps'

@Component({
  selector: 'app-doctor-create',
  templateUrl: './doctor-create.component.html',
  styleUrls: ['./doctor-create.component.css']
})
export class DoctorCreateComponent implements OnInit {
  @ViewChild(GoogleMap, { static: false }) map: GoogleMap
  constructor(private elementRef:ElementRef,private fb: FormBuilder, private dservice: DoctorService) { }

  myform: FormGroup;

  markers = [];

  zoom = 17;
  center: google.maps.LatLngLiteral;
  options: google.maps.MapOptions = {
    mapTypeId: 'hybrid',
    zoomControl: true,
    scrollwheel: false,
    disableDoubleClickZoom: true,
    maxZoom: 15,
    minZoom: 4,
  }


  
  addMarker() {
    this.markers.push({
      position: {
        lat: this.center.lat + ((Math.random() - 0.5) * 2) / 10,
        lng: this.center.lng + ((Math.random() - 0.5) * 2) / 10,
      },
      label: {
        color: 'red',
        text: 'Marker label ' + (this.markers.length + 1),
      },
      title: 'Marker title ' + (this.markers.length + 1),
      options: { animation: google.maps.Animation.BOUNCE },
    })
  }

  ngOnInit() {

    navigator.geolocation.getCurrentPosition(position => {
      this.center = {
        lat: -37.814703, 
        lng: 144.965723
      }
    })

    this.myform = this.fb.group({
      'inputFname': this.fb.control('', [Validators.required]),
      'inputLname' : this.fb.control('', [Validators.required, Validators.minLength(1)]),
      'inputUname' : this.fb.control('', [Validators.required, Validators.minLength(5)]),
      'inputPass' : this.fb.control('', [Validators.required, Validators.minLength(5)]),
      'inputPhone' : this.fb.control('', [Validators.required, Validators.minLength(10), CustomValidators.apptelephoneNumbers]),
      'inputEmail' : this.fb.control('', [Validators.required, Validators.email]),
      'inputGender' : this.fb.control('', [Validators.required]),
      'inputQualification' : this.fb.control('', [Validators.required]),
      'inputLatitude' : this.fb.control(''),
      'inputLongitude' : this.fb.control('')
    });

  }

  click(event: google.maps.MouseEvent) {
    this.markers = [];
    console.log(event.latLng.lat().toFixed(4));
    console.log(event.latLng.lng().toFixed(4));
    this.myform.patchValue({'inputLatitude': event.latLng.lat().toFixed(4)});
    this.myform.get('inputLatitude').updateValueAndValidity();
    this.myform.patchValue({'inputLongitude': event.latLng.lng().toFixed(4)});
    this.myform.get('inputLongitude').updateValueAndValidity();
    this.markers.push({
      position: event.latLng
      ,
      label: {
        color: 'red',
        
      },
      title: 'Your Location ' + (this.markers.length + 1),
      options: { animation: google.maps.Animation.BOUNCE },
    })
    //this.addMarker();
  }

  onSubmit() {
    console.log(this.myform.value);
   
    this.dservice.addnewDoctor(this.myform.value);
    this.myform.reset();
   }
}
