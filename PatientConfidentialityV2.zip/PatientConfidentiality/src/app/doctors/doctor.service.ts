import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Subject } from 'rxjs';
import { Doctor } from './doctor-list/doctor.model';
import {environment} from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})

export class DoctorService {

  // tslint:disable-next-line:variable-name
  constructor(private httpc: HttpClient, private _flashMessagesService: FlashMessagesService) { }

  // tslint:disable-next-line:variable-name
  doctor_list: Doctor[] = [];

  // tslint:disable-next-line:variable-name
  doctor_fetched_event_emitter = new Subject<Doctor[]>();

  addnewDoctor(formdata: any) {
     this.httpc.post<{message: string, _id: string}>(environment.url + '/doctors', formdata)
              .subscribe((result) => {

                this._flashMessagesService.show('Doctor Added Successfully', { cssClass: 'alert-success', timeout: 5000 });

              });

            }

            doctorListObservable() {
              return this.doctor_fetched_event_emitter.asObservable();
            }

            getDoctorList() {
              this.httpc.get<{ message: string, dlist: Doctor[]}>(environment.url + '/doctors')
                        .subscribe((resultdata) => {
                          this.doctor_list = resultdata.dlist;
                          this.doctor_fetched_event_emitter.next([...this.doctor_list]);

                        });
            }

            getDoctorListForMap() {
               return this.httpc.get<{ message: string, dlist: Doctor[]}>(environment.url + '/doctors');
                        
            }

            deleteDoctor(id: string) {
              return this.httpc.delete<{ message: string}>(environment.url + '/doctors/' + id);
             }

}
