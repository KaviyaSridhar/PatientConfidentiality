export interface Doctor {
  _id: string;
  inputFname: string;
  inputLname: string;
  inputUname: string;
  inputPhone: string;
  inputEmail: string;
  inputGender: string;
  inputQualification: string;
  inputLatitude: string;
  inputLongitude: string;
  }
