import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { FlashMessagesService } from 'angular2-flash-messages';
import { DoctorService } from '../doctor.service';
import { Doctor } from './doctor.model';

@Component({
  selector: 'app-doctor-list',
  templateUrl: './doctor-list.component.html',
  styleUrls: ['./doctor-list.component.css']
})
export class DoctorListComponent implements OnInit {

  // tslint:disable-next-line:variable-name
  constructor(private dservice: DoctorService, private _flashMessagesService: FlashMessagesService) { }


  DoctorList: Doctor[] = [];

  DListSubcriber: Subscription;

  ngOnInit() {
    this.dservice.getDoctorList();
    this.DListSubcriber = this.dservice.doctorListObservable()
                                       .subscribe((listdata) => {
                                          this.DoctorList = listdata;
                                       });

  }

  deleteDoctor(iid: string) {
    if (confirm('Are You Sure Do U want to Delete Submission')) {
       this.dservice.deleteDoctor(iid)
                    .subscribe((result) => {
                        this.dservice.getDoctorList();
                        this._flashMessagesService.show('Doctor Deleted !', { cssClass: 'alert-success', timeout: 5000 });

                     });
    }
  }

}
