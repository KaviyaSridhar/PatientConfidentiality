import { Component, OnInit,ElementRef ,ViewChild } from '@angular/core';
import { MapInfoWindow, MapMarker, GoogleMap } from '@angular/google-maps'
import { SpecialistService } from 'src/app/specialists/specialist.service';
import { DoctorService } from '../../doctor.service';
@Component({
  selector: 'app-mapview',
  templateUrl: './mapview.component.html',
  styleUrls: ['./mapview.component.css']
})
export class MapviewComponent implements OnInit {
  @ViewChild(GoogleMap, { static: false }) map: GoogleMap

  doc_list:Array<any>=[];
  specalist_list:Array<any>=[];

  constructor(private elementRef:ElementRef,
              private dservice: DoctorService,private spservice:SpecialistService) { }
  
              markers = [];

              zoom = 4;
              center: google.maps.LatLngLiteral;
              options: google.maps.MapOptions = {
                mapTypeId: 'hybrid',
                zoomControl: true,
                scrollwheel: false,
                disableDoubleClickZoom: true,
               
              }
            

  ngOnInit(): void {

    navigator.geolocation.getCurrentPosition(position => {
      this.center = {
        lat: -37.814703, 
        lng: 144.965723
      }
    })
    
    this.dservice.getDoctorListForMap()
                 .subscribe(resultdata=>{
                  this.doc_list = resultdata.dlist;
                  this.spservice.getSpecialistListForMap()
                                .subscribe(resultdata=>{
                                  this.markers=[];
                                  this.specalist_list = resultdata.slist;
                                  this.specalist_list.forEach(element => {
                                    let latlon = new google.maps.LatLng(element.inputLatitude,element.inputLongitude)
                                    this.markers.push({
                                        position: latlon,                                       
                                        label: {
                                          color: 'red',
                                          
                                        },
                                        title: element.inputFname+" "+element.inputLname+" ("+element.inputQualification+")",
                                        options: { animation: google.maps.Animation.BOUNCE },
                                      })
                                      console.log(element);
                                  });
                                  this.doc_list.forEach(element => {
                                    let latlon = new google.maps.LatLng(element.inputLatitude,element.inputLongitude)
                                    this.markers.push({
                                        position: latlon,                                       
                                        label: {
                                          color: 'red',
                                          
                                        },
                                        title: element.inputFname+" "+element.inputLname+" ("+element.inputQualification+")",
                                        options: { animation: google.maps.Animation.BOUNCE },
                                      })
                                      console.log(element);
                                  });
                                })
                 })
                 

  }

}
