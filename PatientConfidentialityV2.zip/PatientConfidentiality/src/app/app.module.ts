import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { AddressComponent } from './header/address/address.component';
import { LogoComponent } from './header/logo/logo.component';
import { TopNavigationComponent } from './top-navigation/top-navigation.component';
import { LeftmenuComponent } from './leftmenu/leftmenu.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { SlidesComponent } from './slides/slides.component';
import { MainContentComponent } from './main-content/main-content.component';
import { FooterComponent } from './footer/footer.component';
import { FlashMessagesModule } from 'angular2-flash-messages';
import { PatientCreateComponent } from './patients/patient-create/patient-create.component';
import { UserCreateComponent } from './users/user-create/user-create.component';
import { ReceptionistCreateComponent } from './receptionists/receptionist-create/receptionist-create.component';
import { PrecordCreateComponent } from './precords/precord-create/precord-create.component';
import { DoctorCreateComponent } from './doctors/doctor-create/doctor-create.component';
import { SpecialistCreateComponent } from './specialists/specialist-create/specialist-create.component';
import { TopMenusComponent } from './top-menus/top-menus.component';
import { ShowErrorsComponent } from './errors/show-errors/show-errors.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { DoctorListComponent } from './doctors/doctor-list/doctor-list.component';
import { PatientListComponent } from './patients/patient-list/patient-list.component';
import { ReceptionistListComponent } from './receptionists/receptionist-list/receptionist-list.component';
import { SpecialistListComponent } from './specialists/specialist-list/specialist-list.component';
import { PatientDetailsComponent } from './patients/patient-details/patient-details.component';
import { LoginComponent } from './auth/login/login.component';
import { AuthInterceptor } from './auth/auth-interceptor';
import { SpecPrerecordCreateComponent } from './precords/spec-prerecord-create/spec-prerecord-create.component';
import { DoctorPatientListComponent } from './patients/doctor-patient-list/doctor-patient-list.component';
import { LocationStrategy,PathLocationStrategy } from '@angular/common';
import { AboutUsComponent } from './doctors/pages/about-us/about-us.component';
import { ContactUsComponent } from './doctors/pages/contact-us/contact-us.component';
import { AboutProjectComponent } from './doctors/pages/about-project/about-project.component';
import { GoogleMapsModule } from '@angular/google-maps';
import { MapviewComponent } from './doctors/pages/mapview/mapview.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    AddressComponent,
    LogoComponent,
    TopNavigationComponent,
    LeftmenuComponent,
    SlidesComponent,
    MainContentComponent,
    FooterComponent,
    PatientCreateComponent,
    UserCreateComponent,
    ReceptionistCreateComponent,
    PrecordCreateComponent,
    DoctorCreateComponent,
    SpecialistCreateComponent,
    TopMenusComponent,
    ShowErrorsComponent,
    DoctorListComponent,
    PatientListComponent,
    ReceptionistListComponent,
    SpecialistListComponent,
    PatientDetailsComponent,
    LoginComponent,
    SpecPrerecordCreateComponent,
    DoctorPatientListComponent,
    AboutUsComponent,
    ContactUsComponent,
    AboutProjectComponent,
    MapviewComponent

     ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    GoogleMapsModule,
    FlashMessagesModule.forRoot(),
    
   
  ],
  providers: [{provide : HTTP_INTERCEPTORS, useClass : AuthInterceptor, multi : true},
    {provide: LocationStrategy, useClass: PathLocationStrategy}],
  bootstrap: [AppComponent]
})
export class AppModule { }
