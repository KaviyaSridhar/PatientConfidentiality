import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class StypeService {

  constructor(private httpc: HttpClient) { }

  stypeemitter = new Subject<any>();


  stypeListObservable() {
    return this.stypeemitter.asObservable();
  }



  getallstype() {
  this.httpc.get<{message: string, slist: any}>(environment.url +'/stypes')
                     .subscribe((result) => {
                         this.stypeemitter.next(result.slist);
                     });
   }


}
