import { TestBed } from '@angular/core/testing';

import { StypeService } from './stype.service';

describe('StypeService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: StypeService = TestBed.get(StypeService);
    expect(service).toBeTruthy();
  });
});
