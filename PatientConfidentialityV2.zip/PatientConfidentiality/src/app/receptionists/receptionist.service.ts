import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Receptionist } from './receptionist-list/receptionist.model';
import { Subject } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ReceptionistService {

  // tslint:disable-next-line:variable-name
  constructor(private httpc: HttpClient, private _flashMessagesService: FlashMessagesService) { }

   // tslint:disable-next-line:variable-name
   receptionist_list: Receptionist[] = [];

   // tslint:disable-next-line:variable-name
   receptionist_fetched_event_emitter = new Subject<Receptionist[]>();


  addnewReceptionist(formdata: any) {
    this.httpc.post<{message: string, _id: string}>(environment.url + '/receptionists', formdata)
             .subscribe((result) => {

               this._flashMessagesService.show('Receptionist Added Successfully', { cssClass: 'alert-success', timeout: 5000 });

             });

           }

           receptionistListObservable() {
            return this.receptionist_fetched_event_emitter.asObservable();
          }
          getReceptionistList() {
            this.httpc.get<{ message: string, rlist: Receptionist[]}>(environment.url + '/receptionists')
                      .subscribe((resultdata) => {
                        this.receptionist_list = resultdata.rlist;
                        this.receptionist_fetched_event_emitter.next([...this.receptionist_list]);

                      });
          }

          deleteReceptionist(id: string) {
            return this.httpc.delete<{ message: string}>(environment.url + '/receptionists/' + id);
           }
}
