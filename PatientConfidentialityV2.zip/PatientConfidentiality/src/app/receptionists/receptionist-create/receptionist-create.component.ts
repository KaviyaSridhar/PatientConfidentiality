import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReceptionistService } from '../receptionist.service';
import { CustomValidators } from '../../errors/custom-validator';

@Component({
  selector: 'app-receptionist-create',
  templateUrl: './receptionist-create.component.html',
  styleUrls: ['./receptionist-create.component.css']
})
export class ReceptionistCreateComponent implements OnInit {

  constructor(private fb: FormBuilder, private rservice: ReceptionistService) { }

  myform: FormGroup;

  ngOnInit() {

    this.myform = this.fb.group({
      'inputFname': this.fb.control('', [Validators.required]),
      'inputLname' : this.fb.control('', [Validators.required, Validators.minLength(3)]),
      'inputEmail' : this.fb.control('', [Validators.required, Validators.email]),
      'inputPass' : this.fb.control('', [Validators.required, Validators.minLength(10)]),
      'inputPhone' : this.fb.control('', [Validators.required, Validators.minLength(10), CustomValidators.apptelephoneNumbers]),
      'inputAddress' : this.fb.control('', [Validators.required])

    });

  }

  onSubmit() {
    this.rservice.addnewReceptionist(this.myform.value);
    this.myform.reset();
   }

}
