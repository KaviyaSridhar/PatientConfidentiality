import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReceptionistCreateComponent } from './receptionist-create.component';

describe('ReceptionistCreateComponent', () => {
  let component: ReceptionistCreateComponent;
  let fixture: ComponentFixture<ReceptionistCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReceptionistCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReceptionistCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
