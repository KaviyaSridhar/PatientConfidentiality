import { Component, OnInit } from '@angular/core';
import { Receptionist } from './receptionist.model';
import { Subscription } from 'rxjs';
import { ReceptionistService } from '../receptionist.service';
import { FlashMessagesService } from 'angular2-flash-messages';

@Component({
  selector: 'app-receptionist-list',
  templateUrl: './receptionist-list.component.html',
  styleUrls: ['./receptionist-list.component.css']
})
export class ReceptionistListComponent implements OnInit {

  // tslint:disable-next-line:variable-name
  constructor(private rservice: ReceptionistService, private _flashMessagesService: FlashMessagesService) { }

  ReceptionistList: Receptionist[] = [];

  RListSubcriber: Subscription;

  ngOnInit() {
    this.rservice.getReceptionistList();
    this.RListSubcriber = this.rservice.receptionistListObservable()
                                       .subscribe((listdata) => {
                                          this.ReceptionistList = listdata;
                                       });

  }

  deleteReceptionist(iid: string) {
    if (confirm('Are You Sure Do U want to Delete Submission')) {
       this.rservice.deleteReceptionist(iid)
                    .subscribe((result) => {
                        this.rservice.getReceptionistList();
                        this._flashMessagesService.show('Receptionist Deleted !', { cssClass: 'alert-success', timeout: 5000 });

                     });
    }
  }

}
