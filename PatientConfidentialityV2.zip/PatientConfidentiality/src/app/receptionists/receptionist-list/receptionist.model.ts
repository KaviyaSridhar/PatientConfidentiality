export interface Receptionist {
  _id: string;
  inputFname: string;
  inputLname: string;
  inputEmail: string;


  }
