import { FormControl, ValidationErrors, FormGroup } from '@angular/forms';

export class CustomValidators {
  static apptelephoneNumbers(c: FormControl): ValidationErrors {
    const isValidPhoneNumber = /^[7-9]{1}[0-9]{9}$/.test(c.value);
    const message = {
      telephoneNumber: {
        message:
          'The phone number must contain only numbers'
      }
    };
    return isValidPhoneNumber ? null : message;
  }

  static numberValidate(c: FormControl): ValidationErrors {
    const numValue = Number(c.value);
    const isValid = !isNaN(numValue);
    const message = {
      number: {
        message: 'Enter a Valid Number'
      }
    };
    return isValid ? null : message;
  }

  static filevalidate(c: FormControl): ValidationErrors {
    const isValid = c.value != null && c.value.length !== 0;
    const message = {
      reqfile: {
        message: 'Please Select a File'
      }
    };
    return isValid ? null : message;
  }

  static filetypevalidate(control: FormControl): ValidationErrors {
    const message = {
      pdfWord: {
        message: 'Invalid Document Type Provided'
      }
    };
    let isValid = false;
    const file = control.value;
    if (control.value == null) {
      return isValid ? null : message;
    }
    // console.log(file);
    // console.log(typeof(file));
    let ext = '';
    if (typeof file === 'string') {
      ext = file.split('.').pop();
    } else {
      ext = file.name.split('.').pop();
    }
    const type = file.type;
    if (ext === 'pdf' || ext === 'docx' || ext === 'doc') {
      // if ( type === 'application/pdf' || ext === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ) {
      isValid = true;
    }
    return isValid ? null : message;
  }
}
