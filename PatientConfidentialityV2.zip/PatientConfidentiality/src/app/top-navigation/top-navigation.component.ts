import { Component, OnInit, OnDestroy } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-top-navigation',
  templateUrl: './top-navigation.component.html',
  styleUrls: ['./top-navigation.component.css']
})
export class TopNavigationComponent implements OnInit,OnDestroy {

  isAuthenticated: boolean = false;
  user_role = -1;
  AuthSubcription:Subscription;

  constructor(private authservice: AuthService) { }

  ngOnInit() {
    this.isAuthenticated = this.authservice.getAuthStatus();
    this.AuthSubcription = this.authservice.getAuthStatusListener()
    .subscribe(authData => {
        this.isAuthenticated = authData.loginstatus;
        this.user_role = authData.user_role;
      });
  }

  ngOnDestroy() {
    this.AuthSubcription.unsubscribe();
  }

  onLogout() {
    this.authservice.logout();
  }

}
