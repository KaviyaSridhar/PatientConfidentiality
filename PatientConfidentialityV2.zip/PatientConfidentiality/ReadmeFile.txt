Patient Confidentiality
   Angular Js (FrontEnd using boostrap framework)
      ---will be hosted on a s3 aws storage as a website front end
   
   Nodejs(Express Js) As backend server working on REST API using json medium of communication
      --will be hosted using Elastic bean nodejs Aws storage
	  --separate ec2 instances will be crated for it
	  
   
   Mongodb(WildTiger AWS Cloud server) Database to save users data
        ---separate Databse storage AWS itself
   
   Google Map Api to display all doctors and specialist location on gmaps
       ----it is alreday setuuped on cloud ,will rgister here and get api key to access gmaps 
	   
   Crypto package will be used
   
  
  
WORKING DETAILS

Main Medical Association(Super Admin)
     --add doctor
	 --add specialist doctor
Doctor Section
    Add Recipetionist
	View any patient details using his patient id
Recipetionist Section
    Add new Patient details
Specialist Section
    View Patient basic details and special test details perfomed on his patients	
	 
AES 256 Bit Encryption ECB based method

Cypto package ffrom google library in th project
